/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package org.magnum.mobilecloud.video;

import java.io.IOException;
import java.security.Principal;
import java.util.Collection;

import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.repository.Video;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;

@Controller
public class VideoController {
	
	/**
	 * You will need to create one or more Spring controllers to fulfill the
	 * requirements of the assignment. If you use this file, please rename it
	 * to something other than "AnEmptyController"
	 * 
	 * 
		 ________  ________  ________  ________          ___       ___  ___  ________  ___  __       
		|\   ____\|\   __  \|\   __  \|\   ___ \        |\  \     |\  \|\  \|\   ____\|\  \|\  \     
		\ \  \___|\ \  \|\  \ \  \|\  \ \  \_|\ \       \ \  \    \ \  \\\  \ \  \___|\ \  \/  /|_   
		 \ \  \  __\ \  \\\  \ \  \\\  \ \  \ \\ \       \ \  \    \ \  \\\  \ \  \    \ \   ___  \  
		  \ \  \|\  \ \  \\\  \ \  \\\  \ \  \_\\ \       \ \  \____\ \  \\\  \ \  \____\ \  \\ \  \ 
		   \ \_______\ \_______\ \_______\ \_______\       \ \_______\ \_______\ \_______\ \__\\ \__\
		    \|_______|\|_______|\|_______|\|_______|        \|_______|\|_______|\|_______|\|__| \|__|
                                                                                                                                                                                                                                                                        
	 * 
	 */
	
//	@RequestMapping(value="/go",method=RequestMethod.GET)
//	public @ResponseBody String goodLuck(){
//		return "Good Luck!";
//	}
	
	private static final String VIDEO_SVC_PATH_ID = VideoSvcApi.VIDEO_SVC_PATH + "/{id}";
	
	private static final String VIDEO_SVC_PATH_LIKE = VIDEO_SVC_PATH_ID + "/like";
	
	private static final String VIDEO_SVC_PATH_UNLIKE = VIDEO_SVC_PATH_ID + "/unlike";
	
	private static final String VIDEO_SVC_PATH_LIKED_BY = VIDEO_SVC_PATH_ID + "/likedby";
	
	private static final String ID_PARAMETER = "id";
	
	@Autowired
	private VideoRepository videoRepository;
	
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH, method = RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList() {
		return Lists.newArrayList(videoRepository.findAll());
	}
	
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH, method = RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video v, Principal p) {
		Video video = videoRepository.findByName(v.getName());
		if (video != null) {
			if (video.getOwner().equals(p.getClass())) {
				video.setUrl(v.getUrl());
				video.setDuration(v.getDuration());
				video.setLikes(v.getLikes());
				video.setLikedby(v.getLikedby());
				videoRepository.save(video);
			}
			return video;
		} else {
			v.setOwner(p.getName());
			videoRepository.save(v);
			return videoRepository.findByName(v.getName());
		}
	}
	
	@RequestMapping(value = VIDEO_SVC_PATH_ID, method = RequestMethod.GET)
	public @ResponseBody Video getVideoById(@PathVariable(ID_PARAMETER) long id, 
			HttpServletResponse response) throws IOException {
		Video video = videoRepository.findOne(id);
		if (video == null) {
			response.sendError(HttpStatus.NOT_FOUND.value());
			return null;
		}
		return video;
	}
	
	@RequestMapping(value = VIDEO_SVC_PATH_LIKE, method = RequestMethod.POST)
	public void likeVideo(@PathVariable(ID_PARAMETER) long id, Principal p, 
			HttpServletResponse response) throws IOException {
		Video video = videoRepository.findOne(id);
		if (video == null) {
			response.sendError(HttpStatus.NOT_FOUND.value());
		} else {
			if (video.getLikedby().contains(p.getName())) {
				response.sendError(HttpStatus.BAD_REQUEST.value());
			} else {
				video.getLikedby().add(p.getName());
				video.setLikes(video.getLikes() + 1);
				videoRepository.save(video);
			}
		}
	}
	
	@RequestMapping(value = VIDEO_SVC_PATH_UNLIKE, method = RequestMethod.POST)
	public void unlikeVideo(@PathVariable(ID_PARAMETER) long id, Principal p, 
			HttpServletResponse response) throws IOException {
		Video video = videoRepository.findOne(id);
		if (video == null) {
			response.sendError(HttpStatus.NOT_FOUND.value());
		} else {
			if (!video.getLikedby().contains(p.getName())) {
				response.sendError(HttpStatus.BAD_REQUEST.value());
			} else {
				video.getLikedby().remove(p.getName());
				video.setLikes(video.getLikes() - 1);
				videoRepository.save(video);
			}
		}
	}
	
	@RequestMapping(value = VIDEO_SVC_PATH_LIKED_BY, method = RequestMethod.GET)
	public @ResponseBody Collection<String> getUsersWhoLikedVideo(
			@PathVariable(ID_PARAMETER) long id, HttpServletResponse response) 
					throws IOException {
		Video video = videoRepository.findOne(id);
		if (video == null) {
			response.sendError(HttpStatus.NOT_FOUND.value());
			return null;
		} else {
			return Lists.newArrayList(video.getLikedby());
		}
	}
	
}
