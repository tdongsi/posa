package org.magnum.mobilecloud.video.repository;

import org.springframework.data.repository.CrudRepository;

public interface VideoRepository extends CrudRepository<Video, Long> {
	
	Video findByName(String title);

}
