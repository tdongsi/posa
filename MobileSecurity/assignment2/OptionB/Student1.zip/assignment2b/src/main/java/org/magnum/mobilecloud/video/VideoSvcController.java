package org.magnum.mobilecloud.video;

import java.io.IOException;
import java.security.Principal;
import java.util.Collection;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.repository.Video;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import com.google.common.collect.Lists;

@Controller
public class VideoSvcController {

	@Autowired
	private VideoRepository videos;
	
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList(){
		populateVideoList();
		return Lists.newArrayList(videos.findAll());
	}

	@PreAuthorize("hasRole(user)")
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.POST)
	public @ResponseBody Video addVideo(
			Principal p,
			@RequestBody Video v,
			HttpServletResponse response) throws IOException{
		
		String username = p.getName();
		
		// After much deliberation and no comment from course staff, I decided to use
		// the video id to determine if video uniqueness. This makes the most sense
		// when implementing the client in Assignment 3.
		
		/* Method 1: Uniqueness using equals method criteria */
		/* Collection<Video> matches =
				videos.findByNameAndUrlAndDuration(v.getName(), v.getUrl(), v.getDuration());
		
		if (matches.contains(v)) {
			Video match = matches.iterator().next();	
			if (match.getOwner().equals(username)) {
				//Override Id so JPA Updates instead of Insert
				v.setId(match.getId());
			}
			else 
				response.sendError(400, "Unable to update video.");
		} */

		/* Method 2: Uniqueness using video name */
		/* Collection<Video> matches = 
				videos.findByName(v.getName());
		
		if (!matches.isEmpty()) {
			Video match = matches.iterator().next();	
			if (match.getOwner().equals(username)) {
				//Override Id so JPA Updates instead of Insert
				v.setId(match.getId());
			}
			else 
				response.sendError(400, "Unable to update video.");
		} */
		
		/* Method 3: Uniqueness using video id */

		if (videos.exists(v.getId())) {
			Video curVideo = videos.findOne(v.getId());
			
			if (curVideo.getOwner().equals(username)) {
				//Override Id so JPA Updates instead of Insert
				v.setId(curVideo.getId());
				return videos.save(v);
			}
			else 
				response.sendError(400, "Unable to update video.");
		}
		else
		{
			v.setOwner(username);
			return videos.save(v);
		}
		
		return v; // Appease compiler, return without saving
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}", method=RequestMethod.GET)
	public @ResponseBody Video getVideoById(
			@PathVariable("id") Long id,
			HttpServletResponse response) throws IOException  {
		Video curVideo = new Video();
		
		if (! videos.exists(id)) {
			response.sendError(404, "Unable to locate video id.");
		}
		else {
			curVideo = videos.findOne(id);
		}
		return curVideo;
	}
	
	@PreAuthorize("hasRole(user)")
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/like", method=RequestMethod.POST)
	public void likeVideo(
			@PathVariable("id") Long id,
			Principal p,
			HttpServletResponse response) throws IOException  {
		Video curVideo = new Video();
		Set<String> likesUsernames;
		String username = p.getName();
		
		if (! videos.exists(id)) {
			response.sendError(404, "Unable to locate video id.");
		}
		else {
			curVideo = videos.findOne(id);
		}
		
		likesUsernames = curVideo.getLikesUsernames();
		
		if (likesUsernames.contains(username)) {
			response.sendError(400, "Already liked video.");
		}
		else {
			likesUsernames.add(username);
			curVideo.setLikesUsernames(likesUsernames);
			curVideo.setLikes(likesUsernames.size());
			videos.save(curVideo);
		}
	}

	@PreAuthorize("hasRole(user)")
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/unlike", method=RequestMethod.POST)
	public void unlikeVideo(
			@PathVariable("id") Long id,
			Principal p,
			HttpServletResponse response) throws IOException  {
		Video curVideo = new Video();
		Set<String> likesUsernames;
		String username = p.getName();
		
		if (! videos.exists(id)) {
			response.sendError(404, "Unable to locate video id.");
		}
		else {
			curVideo = videos.findOne(id);
		}
		
		likesUsernames = curVideo.getLikesUsernames();
		
		if (! likesUsernames.contains(username)) {
			response.sendError(400, "User has not previously liked video.");
		}
		else {
			likesUsernames.remove(username);
			curVideo.setLikesUsernames(likesUsernames);
			curVideo.setLikes(likesUsernames.size());
			videos.save(curVideo);
		}
	}

	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/likedby", method=RequestMethod.GET)
	public @ResponseBody Collection<String> getUsersWhoLikedVideo(
			@PathVariable("id") Long id,
			HttpServletResponse response) throws IOException  {
		Video curVideo = new Video();
		Set<String> likesUsernames;
		
		if (! videos.exists(id)) {
			response.sendError(404, "Unable to locate video id.");
		}
		else {
			curVideo = videos.findOne(id);
		}
		
		likesUsernames = curVideo.getLikesUsernames();
		return likesUsernames;
	}	
	
	
	/**
	 * Helper method for testing /video Get
	 */
	private void populateVideoList(){
		String id = UUID.randomUUID().toString();
		String title = "Video-"+id;
		String url = "http://coursera.org/some/video-"+id;
		long duration = 60 * (int)Math.rint(Math.random() * 60) * 1000; // random time up to 1hr
		videos.save(new Video(title, url, duration, 0));		
	}
	
}
