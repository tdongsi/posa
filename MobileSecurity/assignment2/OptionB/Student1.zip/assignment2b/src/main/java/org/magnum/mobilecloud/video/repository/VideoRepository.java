package org.magnum.mobilecloud.video.repository;

import java.util.Collection;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VideoRepository extends CrudRepository<Video, Long>{

	public Collection<Video> findByName(String name);
	
	// Find all videos with a matching Name, Url and Duration
	// Per Video.equals() method, this criteria ensures uniqueness
	
	public Collection<Video> findByNameAndUrlAndDuration(String name, String url, long duration);
	
}