/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package org.magnum.mobilecloud.video;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.repository.Video;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Objects;

import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.POST;
import retrofit.http.Path;

@Controller
public class VideoController {
	private static final AtomicLong currentId = new AtomicLong(0L); // copied from hint section
	private Map<Long,Video> videos = new HashMap<Long, Video>(); // copied from hint section
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.GET)
    public @ResponseBody Collection<Video> getVideoList() {
		return videos.values();
	}
	
	@RequestMapping(value="/video/{id}", method=RequestMethod.GET)
	public @ResponseBody Video getVideoById(@PathVariable("id") long id, HttpServletResponse response) {
		Video v = videos.get(id);
		if (v == null) {
			// set state to appropriate HTTP error status
			response.setStatus(404);
		}
		
		return v;
	}
	
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH, method = RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video v, Principal p) {
		boolean addVideo = true;
		for (Video vIt : videos.values()) {
			if (vIt.equals(v)) {
				if (!Objects.equal(vIt.getOwner(), v.getOwner())) {
					// If a Video already exists, it should not be overwritten unless the 
					// name of the authenticated Principal matches the name of the owner of the Video
					addVideo = false;
				}
				break;
			}
		}
		
		Video video;
		if (addVideo) {
			video = new Video(v.getName(), v.getUrl(), v.getDuration(), v.getLikes(), p.getName());
			video = save(video);
		} else {
			video = v;
		}
		
		return video;
	}
	
	public Video save(Video entity) {
		checkAndSetId(entity);
        videos.put(entity.getId(), entity);
        return entity;
    }

    private void checkAndSetId(Video entity) {
        if(entity.getId() == 0) {
            entity.setId(currentId.incrementAndGet());
        }
	}
    
    @RequestMapping(value = "/video/{id}/like", method = RequestMethod.POST)
	public @ResponseBody void likeVideo(@PathVariable("id") long id, Principal p, HttpServletResponse response) {
		if (videos.containsKey(id)) {
			Video v = videos.get(id);
			if (v == null) {
				// set state to appropriate HTTP error status
				response.setStatus(404);
			} else {
				// return 400 if user already liked the video
				if (v.userLikes.contains(p.getName())) {
					response.setStatus(400);
				} else {
					v.userLikes.add(p.getName());
					long likes = v.getLikes() + 1; 
					v.setLikes(likes);
				}
			} 
		}
		else {
			// set state to appropriate HTTP error status
			response.setStatus(404);
		}
    }
    
    @RequestMapping(value = "/video/{id}/unlike", method = RequestMethod.POST)
	public @ResponseBody void unlikeVideo(@PathVariable("id") long id, Principal p, HttpServletResponse response) {
		if (videos.containsKey(id)) {
			Video v = videos.get(id);
			if (v == null) {
				// set state to appropriate HTTP error status
				response.setStatus(404);
			} else {
				// return 400 if user has not already liked the video
				if (!v.userLikes.contains(p.getName())) {
					response.setStatus(400);
				} else {
					long likes = v.getLikes() - 1;
					v.setLikes(likes);
					v.userLikes.remove(p.getName());
				}
			} 
		}
		else {
			// set state to appropriate HTTP error status
			response.setStatus(404);
		}
    }
	
	@RequestMapping(value="/video/{id}/likedby", method=RequestMethod.GET)
	public @ResponseBody Collection<String> getUsersWhoLikedVideo(@PathVariable("id") long id, HttpServletResponse response) {
		Collection<String> likedby = new ArrayList<String>();
		
		if (videos.containsKey(id)) {
			Video v = videos.get(id);
			likedby = v.userLikes;
		}
		else {
			response.setStatus(404);
		}
		
		return likedby;
	}	
}
