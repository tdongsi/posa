package org.magnum.mobilecloud.video;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.repository.Video;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Controller
public class VideoController {
	
	@Autowired
	private VideoRepository videoRepository;

	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList() {
		final List<Video> videos = new ArrayList<>();
		for (Video v : videoRepository.findAll()) {
			videos.add(v);
		}
		return videos;
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}", method=RequestMethod.GET)
	public @ResponseBody Video getVideoById(@PathVariable long id) {
		return findVideoById(id);
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video v, Principal p) {
		// video update
		if (v.getId() != 0) {
			Video found = findVideoById(v.getId());
			if (found != null && found.getOwner().equals(p.getName())) {
				// to avoid cheating on likes count :)
				v.setLikes(found.getLikes());
				return videoRepository.save(v);
			} else {
				throw new ForbiddenActionException();
			}
		}
		// video first save
		v.setId(0);
		v.setLikes(0);
		v.setOwner(p.getName());
		return videoRepository.save(v);
	}

	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/like", method=RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void likeVideo(@PathVariable long id, Principal p) {
		Video v = findVideoById(id);
		if (v.getLikers().contains(p.getName())) {
			throw new BadRequestException();
		} else {
			v.getLikers().add(p.getName());
			v.setLikes(v.getLikers().size());
			videoRepository.save(v);
		}
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/unlike", method=RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void unlikeVideo(@PathVariable long id, Principal p) {
		Video v = findVideoById(id);
		if (v.getLikers().contains(p.getName())) {
			v.getLikers().remove(p.getName());
			v.setLikes(v.getLikers().size());
			videoRepository.save(v);
		} else {
			throw new BadRequestException();
		}
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/likedby", method=RequestMethod.GET)
	public @ResponseBody Collection<String> getUsersWhoLikedVideo(@PathVariable long id) {
		return findVideoById(id).getLikers();
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_TITLE_SEARCH_PATH, method = RequestMethod.GET)
	public @ResponseBody Collection<Video> findByName(@Param(value = VideoSvcApi.TITLE_PARAMETER) String title) {
		return videoRepository.findByName(title);
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_DURATION_SEARCH_PATH, method = RequestMethod.GET)
	public @ResponseBody Collection<Video> findByDurationLessThan(
			@Param(value = VideoSvcApi.DURATION_PARAMETER) Long duration) {
		return videoRepository.findByDurationLessThan(duration);
	}
	
	private Video findVideoById(Long id) {
		Video v = videoRepository.findOne(id);
		if (v == null) {
			throw new VideoNotFoundException();
		}
		return v;
	}
}
