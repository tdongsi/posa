/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package org.magnum.mobilecloud;

import java.io.IOException;
import java.security.Principal;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.model.Video;
import org.magnum.mobilecloud.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;

@Controller
public class VideoController {
	
    private static final String VIDEO_SVC_PATH = "/video";
    private static final String VIDEO_DATA_PATH = VIDEO_SVC_PATH + "/{id}";
    private static final String ID_PARAMETER = "id";
    private static final String VIDEO_LIKE_PATH = VIDEO_SVC_PATH + "/{id}/like";
    private static final String VIDEO_UNLIKE_PATH = VIDEO_SVC_PATH + "/{id}/unlike";
    private static final String VIDEO_LIKEDBY_PATH = VIDEO_SVC_PATH + "/{id}/likedby";
    
    @Autowired
    private VideoRepository Videos;
	
    // getVideoList 
	@RequestMapping(VIDEO_SVC_PATH)
    public @ResponseBody Collection<Video> getVideoList(){
        return Lists.newArrayList(Videos.findAll());
    } 
	
	// addVideo
    @RequestMapping(value = VIDEO_SVC_PATH, method = RequestMethod.POST)
    public @ResponseBody Video addVideo(@RequestBody Video video, Principal p){
        
        video.setOwner(p.getName());
        
        Videos.save(video);
         
        // Iterator<Video> vs = Videos.findAll().iterator();
        
        // while (vs.hasNext()) {
        //     Video v = vs.next();
        //     System.out.println("ID: " + v.getId());
        //     System.out.println("NAME: " + v.getName());
        //     System.out.println("URL: " + v.getUrl());
        //     System.out.println("OWNER: " + v.getOwner());
        //     System.out.println("DURATION: " + v.getDuration());
        //     System.out.println("LIKES: " + v.getLikes());
        // }
         
        return video;
    }
    
    // getVideoById
    @RequestMapping(VIDEO_DATA_PATH)
    public @ResponseBody Video getVideoById(
            
        @PathVariable(ID_PARAMETER) long id,
        HttpServletResponse response
        
    ) throws IOException {
        Video video = Videos.findOne(id);
        if (video == null){
            throw new ResourceNotFoundException();
        } else {             
            return video;      
        }
    } 
    
    // likeVideo
    @RequestMapping(value = VIDEO_LIKE_PATH, method = RequestMethod.POST)
    public @ResponseBody ResponseEntity<?> likeVideo(
        @PathVariable(ID_PARAMETER) long id, 
        Principal p
    ) throws IOException {      
        
        Video video = Videos.findOne(id);
        if (video == null){
            throw new ResourceNotFoundException();
        } else {
            String user = p.getName();
            if (!video.getLikedbyUsers().contains(user)){
                video.addUserToLikedby(user);
                video.setLikes(video.getLikes() + 1L); 
                Videos.save(video);            
                return new ResponseEntity<>(video, HttpStatus.OK);  
            } else {
                return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
            }
        }
    }  
    
    // unlikeVideo
    @RequestMapping(value = VIDEO_UNLIKE_PATH, method = RequestMethod.POST)
    public @ResponseBody ResponseEntity<?> unlikeVideo(            
        @PathVariable(ID_PARAMETER) long id, 
        Principal p
    ) throws IOException {      
        
        Video video = Videos.findOne(id);
        if (video == null){
            throw new ResourceNotFoundException();
        } else {  
            String user = p.getName();
            if (video.getLikedbyUsers().contains(user)){
                video.removeUserFromLikedby(user);
                video.setLikes(video.getLikes() - 1L);
                Videos.save(video);            
                return new ResponseEntity<>(video, HttpStatus.OK);
            } else {
                return new ResponseEntity<String>(HttpStatus.BAD_REQUEST); 
            }
        }
    } 
    
    // getUsersWhoLikedVideo
    @RequestMapping(value = VIDEO_LIKEDBY_PATH)
    public @ResponseBody Collection<String> getUsersWhoLikedVideo(            
        @PathVariable(ID_PARAMETER) long id
    ) throws IOException {      
        
        Video video = Videos.findOne(id);
        if (video == null){
            throw new ResourceNotFoundException();
        } else {                                   
            return video.getLikedbyUsers();    
        }
    }    
}
