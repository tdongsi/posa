/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.magnum.dataup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.magnum.dataup.controller.VideoFileManager;
import org.magnum.dataup.model.Video;
import org.magnum.dataup.model.VideoStatus;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class MyController {
    private static final AtomicLong currentId = new AtomicLong(0L); // copied from hint section
    private Map<Long, Video> videos = new HashMap<Long, Video>(); // copied from hint section
    private Map<Long, ArrayList<Integer>> ratings = new HashMap<Long, ArrayList<Integer>>();
    VideoFileManager vMgr; // Use to read/write videos to a file per hints

    // #1: GET /video
    @RequestMapping(value = "/video", method = RequestMethod.GET)
    public @ResponseBody
    Collection<Video> doGetVideos() {
        return videos.values();
    }

    // #2: POST /video
    @RequestMapping(value = "/video", method = RequestMethod.POST)
    public @ResponseBody
    Video doPostVideo(@RequestBody Video v) {
        // Use readme 'POST /video' for hints on implementation detail..
        if (v == null) {
            throw new ResourceNotFoundException();
        }

        Video newVideo = Video.create().withContentType(v.getContentType()).withDuration(v.getDuration())
                .withSubject(v.getSubject()).withTitle(v.getTitle()).build();
        newVideo.setLocation(v.getLocation());
        checkAndSetId(newVideo);
        newVideo.setUrl(getUrl(newVideo.getId()));
        videos.put(newVideo.getId(), newVideo);
        ratings.put(newVideo.getId(), new ArrayList<Integer>());
        return newVideo;
    }

    // #3: POST /video/{id}/data
    @RequestMapping(value = "/video/{id}/data", method = RequestMethod.POST)
    public @ResponseBody
    VideoStatus doPostVideoData(@PathVariable(VideoSvcApi.ID_PARAMETER) long id,
            @RequestParam(VideoSvcApi.DATA_PARAMETER) MultipartFile videoData) throws IOException {
        if (videos.get(id) == null) {
            throw new ResourceNotFoundException();
        }
        vMgr = VideoFileManager.get();
        vMgr.saveVideoData(videos.get(id), videoData.getInputStream());
        return new VideoStatus(VideoStatus.VideoState.READY);
    }

    //#4: GET /video/{id}/data
    @RequestMapping(value = "/video/{id}/data", method = RequestMethod.GET)
    public void doGetData(@PathVariable(VideoSvcApi.ID_PARAMETER) long id, HttpServletResponse response)
            throws IOException {
        if (videos.get(id) == null) {
            throw new ResourceNotFoundException();
        }
        serveSomeVideo(videos.get(id), response);
    }

    //#5: POST /video/{id}/{rating}
    @RequestMapping(value = "/video/{id}/{rating}", method = RequestMethod.POST)
    public @ResponseBody
    void doPostVideoData(@PathVariable(VideoSvcApi.ID_PARAMETER) long id,
            @PathVariable(VideoSvcApi.RATING_PARAMETER) int rating) throws IOException {
        if (videos.get(id) == null) {
            throw new ResourceNotFoundException();
        }
        ratings.get(id).add(rating);
        videos.get(id).setRating(getAverageRating(ratings.get(id)));
    }

    // HELPERS
    private String getUrl(long videoId) {
        String url = getUrlBaseForLocalServer() + "/video/" + videoId + "/data";
        return url;
    }

    private String getUrlBaseForLocalServer() {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
                .getRequest();
        String base = "http://" + request.getServerName()
                + ((request.getServerPort() != 80) ? ":" + request.getServerPort() : "");
        return base;
    }

    public Video save(Video entity) {
        checkAndSetId(entity);
        videos.put(entity.getId(), entity);
        return entity;
    }

    private void checkAndSetId(Video entity) {
        if (entity.getId() == 0) {
            entity.setId(currentId.incrementAndGet());
        }
    }

    public void serveSomeVideo(Video v, HttpServletResponse response) throws IOException {
        response.setHeader("Content-Type", "video/mp4");
        vMgr.copyVideoData(v, response.getOutputStream());
    }

    private int getAverageRating(ArrayList<Integer> ratings) {
        if (ratings.size() == 0)
            return 0;

        int sum = 0;
        for (int rating : ratings) {
            sum += rating;
        }

        return Math.round(sum / ratings.size());
    }
}