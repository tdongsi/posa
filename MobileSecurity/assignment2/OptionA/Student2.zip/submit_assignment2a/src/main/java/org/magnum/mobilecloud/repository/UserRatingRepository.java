package org.magnum.mobilecloud.repository;

import java.util.Collection;

import org.magnum.mobilecloud.video.model.UserVideoRating;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * An interface for a repository that can store Video
 * objects and allow them to be searched by title.
 *
 */
@Repository
public interface UserRatingRepository extends CrudRepository<UserVideoRating, Long>{
	
	public Collection<UserVideoRating> findByVideoId(long videoId);
	public Collection<UserVideoRating> findByUser(String user);
	public Collection<UserVideoRating> findByUserAndVideoId(String user, long videoId);
}
