package org.magnum.mobilecloud.video.controller;

import org.apache.http.util.TextUtils;
import org.magnum.mobilecloud.repository.UserRatingRepository;
import org.magnum.mobilecloud.repository.VideoRepository;
import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.model.AverageVideoRating;
import org.magnum.mobilecloud.video.model.UserVideoRating;
import org.magnum.mobilecloud.video.model.Video;
import org.magnum.mobilecloud.video.model.VideoStatus;
import org.magnum.mobilecloud.video.model.VideoStatus.VideoState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;

import retrofit.client.Header;
import retrofit.client.Response;
import retrofit.http.GET;
import retrofit.http.Path;

import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class VideoController {
	
	@Autowired
	private VideoRepository videos;
	@Autowired
	private UserRatingRepository ratings;
	
    private VideoFileManager fileManager;
    
    {
    	try {
			fileManager = new VideoFileManager();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }

    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.POST)
    public @ResponseBody Video addVideo(@RequestBody Video v, Principal principal) {
    	Video video = videos.findOne(v.getId());
    	// if it is new video - save it
    	// if this video exist and this operation tries owner - update video
    	// if video exist and not owner of video try to do it - ignore request
    	if (video == null || video.getOwner().equals(principal.getName()) ) {
    		v.setOwner(principal.getName());
    		video = save(v); 	
    	}
        return video;
    }
    
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}", method=RequestMethod.GET)
    public @ResponseBody Video getVideoById(@PathVariable(VideoSvcApi.ID_PARAMETER) long id,
    		HttpServletResponse response) throws IOException {
    	Video video = videos.findOne(id);
        if (video == null) {
        	response.sendError(HttpStatus.NOT_FOUND.value());
        }
        return video;
    }

    // Receives GET requests to /video and returns the current
    // list of videos in memory. Spring automatically converts
    // the list of videos to JSON because of the @ResponseBody
    // annotation.
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method= RequestMethod.GET)
    public @ResponseBody
    Collection<Video> getVideoList() {
    	return Lists.newArrayList(videos.findAll());
    }
    
    @RequestMapping(value=VideoSvcApi.VIDEO_DATA_PATH, method=RequestMethod.POST)
    public @ResponseBody VideoStatus setVideoData(@PathVariable(VideoSvcApi.ID_PARAMETER) long id,
    		@RequestParam(VideoSvcApi.DATA_PARAMETER) 
    org.springframework.web.multipart.MultipartFile videoData,
    		HttpServletResponse response, Principal principal) throws IOException {
    	VideoStatus videoStatus = null;
    	Video video = videos.findOne(id);
        if (video != null) {
        	if (principal.getName().equals(video.getOwner())) {
        		saveMultipartVideo(video, videoData);
            	videoStatus = new VideoStatus(VideoState.READY);
        	} else {
        		response.sendError(HttpStatus.FORBIDDEN.value());
        	}
        } else {
				response.sendError(HttpStatus.NOT_FOUND.value());
        }
        return videoStatus;
    }

    @RequestMapping(value=VideoSvcApi.VIDEO_DATA_PATH, method=RequestMethod.GET)
    public void getVideoData(@PathVariable(VideoSvcApi.ID_PARAMETER) long id,
    		HttpServletResponse response) throws IOException {
    	Video video = videos.findOne(id);
        if (video != null) {
        	setVideoToResponse(video, response);
        } else {
        	response.sendError(HttpStatus.NOT_FOUND.value());
        }
    }
    
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH_RATE, method=RequestMethod.GET)
    public @ResponseBody AverageVideoRating getVideoRating(@PathVariable(VideoSvcApi.ID_PARAMETER) long id,
    		HttpServletResponse response) throws IOException {
    	AverageVideoRating videoRating = null; 
    	Video video = videos.findOne(id);
    	
        if (video != null) {
        	videoRating = new AverageVideoRating(video.getAverageRate(),
        			video.getId(), video.getRateCount());
        } else {
        	response.sendError(HttpStatus.NOT_FOUND.value());
        }
        
        return videoRating;
    }
    
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH_RATE_SET, method=RequestMethod.POST)
    @ResponseBody AverageVideoRating rateVideo(@PathVariable(VideoSvcApi.ID_PARAMETER) long id,
    		@PathVariable(VideoSvcApi.RATING_PARAMETER) int rating,
    		HttpServletResponse response, Principal principal) throws IOException {
    	AverageVideoRating videoRating = null;
    	Video video = videos.findOne(id);
    	if (!isRateValid(rating)) {
    		response.sendError(HttpStatus.PRECONDITION_FAILED.value());
    	} else if (video == null) {
        	response.sendError(HttpStatus.NOT_FOUND.value());
        } else {
        	UserVideoRating userRating;
        	int rateCount = video.getRateCount();
        	double averageRate;
        	Collection<UserVideoRating> rates = ratings.findByUserAndVideoId(principal.getName(), video.getId());
        	
        	if (rates != null && !rates.isEmpty()) {
        		userRating = (UserVideoRating) rates.toArray()[0];
        		averageRate = (video.getAverageRate() * rateCount - userRating.getRating() + rating) / rateCount;
        		userRating.setRating(averageRate);
        	} else {
        		averageRate = (video.getAverageRate() * rateCount + rating) / ++rateCount;
        		video.setRateCount(rateCount);
        		userRating = new UserVideoRating(video.getId(), averageRate, principal.getName());
        	}
 
        	video.setAverageRate(averageRate);
        	videoRating = new AverageVideoRating(averageRate, video.getId(), rateCount);
        	ratings.save(userRating);
        	videos.save(video);
        }
    	return videoRating;
    }
    
    private boolean isRateValid(float rate) {
    	return rate >= 1 && rate <= 5 && rate % 0.5 == 0;
    }
    
    private String getDataUrl(long videoId){
        String url = getUrlBaseForLocalServer() + "/video/" + videoId + "/data";
        return url;
    }

    private String getUrlBaseForLocalServer() {
       HttpServletRequest request = 
           ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
       String base = 
          "https://"+request.getServerName() + ":8443";
       return base;
    }
    
    private Video save(Video entity) {
    	Video savedVideo = videos.save(entity);
    	if (TextUtils.isEmpty(savedVideo.getUrl())) {
    		savedVideo.setUrl(getDataUrl(savedVideo.getId()));
    		videos.save(savedVideo);
    	}
        return savedVideo;
    }
    
    public void saveMultipartVideo(Video video, MultipartFile videoData) throws IOException {
    	fileManager.saveVideoData(video, videoData.getInputStream());
    }

    public void setVideoToResponse(Video video, HttpServletResponse response) throws IOException {
    	fileManager.copyVideoData(video, response.getOutputStream());
    }
}
