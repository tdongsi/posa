/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.magnum.mobilecloud.video;

import java.io.IOException;
import java.io.OutputStream;
import java.security.Principal;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.controller.VideoFileManager;
import org.magnum.mobilecloud.video.model.AverageVideoRating;
import org.magnum.mobilecloud.video.model.UserVideoRating;
import org.magnum.mobilecloud.video.model.Video;
import org.magnum.mobilecloud.video.model.VideoStatus;
import org.magnum.mobilecloud.video.model.VideoStatus.VideoState;
import org.magnum.mobilecloud.video.repository.UserVideoRatingRepository;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;

@Controller
public class VideoController {

	public static final String DATA_PARAMETER = "data";
	
	public static final String RATE_PARAMETER = "rating";

	public static final String ID_PARAMETER = "id";

	public static final String VIDEO_SVC_PATH = "/video";
	
	public static final String VIDEO_DATA_PATH = VIDEO_SVC_PATH + "/{id}/data";
	
	public static final String VIDEO_RATE_PATH = VIDEO_SVC_PATH + "/{id}/rating";
	
	@Autowired
	private VideoRepository videos;
	
	@Autowired
	private UserVideoRatingRepository videoRatings;
	
	private static final AtomicLong currentId = new AtomicLong(0L);
	
	@RequestMapping (value=VIDEO_SVC_PATH, method=RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideos(){
		return Lists.newArrayList(videos.findAll());
	}
	
	@RequestMapping (value=VIDEO_SVC_PATH, method=RequestMethod.POST)
	public @ResponseBody Video setVideo(@RequestBody Video video, Principal principal){
		
		if(video.getId()==0){
			video.setLocation(getDataUrl(currentId.get()));
			video.setOwner(principal.getName());
		}
		videos.save(video);
		return video;
	}
	
	@RequestMapping (value=VIDEO_DATA_PATH, method=RequestMethod.POST)
	public @ResponseBody VideoStatus setVideoData(@PathVariable(ID_PARAMETER) long id,
            @RequestPart(DATA_PARAMETER) MultipartFile videoData,
            HttpServletResponse response, Principal principal)throws IOException{
		
		VideoFileManager videoFileManager = new VideoFileManager();
		
		VideoStatus videoStatus = new VideoStatus(VideoState.PROCESSING);
		Video video = videos.findOne(id);
		if(video != null){
			if(video.getOwner().equals(principal.getName())){
				videoFileManager.saveVideoData(video, videoData.getInputStream());
				videoStatus.setState(VideoState.READY);
				response.setStatus(200);
			}else{
				response.setStatus(403);
			}
		}else{
			response.setStatus(404);
		}
		
		return videoStatus;
	}
	
	@RequestMapping (value=VIDEO_SVC_PATH+"/{id}/rating/{rating}", method=RequestMethod.POST)
	public @ResponseBody AverageVideoRating setVideoRate(@PathVariable(ID_PARAMETER) long id,
			@PathVariable("rating") int rate, HttpServletResponse response, Principal principal){
		
		Video video = videos.findOne(id);
		if(video!=null){
			UserVideoRating userVideoRating = videoRatings.findByVideoIdAndUser(id, principal.getName());
			if(userVideoRating !=null){
				userVideoRating.setRating(rate);
				videoRatings.save(userVideoRating);
			}else{
				videoRatings.save(new UserVideoRating(id,rate, principal.getName()));
			}
			response.setStatus(200);
			return getAverageVideoRating(id);
		}else{
			response.setStatus(404);
			return new AverageVideoRating(0,id,0);
		}
	}
	
	@RequestMapping (value=VIDEO_RATE_PATH, method=RequestMethod.GET)
	public @ResponseBody AverageVideoRating getAverageVideoRate(@PathVariable(ID_PARAMETER) long id,
            HttpServletResponse response){
		
		if(videoRatings.findAllByVideoId(id)!=null){
			response.setStatus(200);
			return getAverageVideoRating(id);
		}else{
			response.setStatus(404);
			return null;
		}
	}
	
	private AverageVideoRating getAverageVideoRating(Long id){
		List<UserVideoRating> userRatings = Lists.newArrayList(videoRatings.findAllByVideoId(id));
		double totalRatings = 0;
		for (UserVideoRating userVideoRating : userRatings) {
		    totalRatings += userVideoRating.getRating();
		}
		return new AverageVideoRating(totalRatings/userRatings.size(),id,userRatings.size());
		
	}
	
	@RequestMapping (value=VIDEO_DATA_PATH, method=RequestMethod.GET)
	public void getVideoData(@PathVariable(ID_PARAMETER) long id,
            HttpServletResponse response)throws IOException{
		VideoFileManager videoFileManager = new VideoFileManager();
		OutputStream out = response.getOutputStream();
		Video video = videos.findOne(id);
		if(video != null && videoFileManager.hasVideoData(video)){
			videoFileManager.copyVideoData(video, out);
			response.setStatus(200);
		}else{
			response.setStatus(404);
		}
		
	}
	
	
	
	
	private String getDataUrl(long id){
        String url = getUrlBaseForLocalServer() + "/video/" + id + "/data";
        return url;
    }

    private String getUrlBaseForLocalServer() {
       HttpServletRequest request = 
           ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
       String base = 
          "http://"+request.getServerName() 
          + ((request.getServerPort() != 80) ? ":"+request.getServerPort() : "");
       return base;
    }
    
    
}
