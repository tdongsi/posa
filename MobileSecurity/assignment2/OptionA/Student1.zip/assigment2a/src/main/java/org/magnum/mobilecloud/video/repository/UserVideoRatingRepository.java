package org.magnum.mobilecloud.video.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;

import org.magnum.mobilecloud.video.model.UserVideoRating;

@Repository
public interface UserVideoRatingRepository extends CrudRepository<UserVideoRating,Long>{
	Collection<UserVideoRating> findAllByVideoId(Long videoId);
	UserVideoRating findByVideoIdAndUser(Long videoId, String user);
}
