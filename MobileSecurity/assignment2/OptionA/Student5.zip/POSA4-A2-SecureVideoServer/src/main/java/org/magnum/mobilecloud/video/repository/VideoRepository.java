package org.magnum.mobilecloud.video.repository;

import org.magnum.mobilecloud.video.model.User;
import org.magnum.mobilecloud.video.model.Video;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * An interface for a repository that can store Video
 * objects and allow them to be searched by title.
 * 
 * @author Eugene
 *
 */
@Repository
public interface VideoRepository extends CrudRepository<Video, Long>{

	// Find all videos with a matching title (e.g., Video.title)
	public Collection<Video> findByTitle(String title);

    // Find all videos with a matching title and owner
    public Collection<Video> findByTitleAndOwner(String title, User owner);

}
