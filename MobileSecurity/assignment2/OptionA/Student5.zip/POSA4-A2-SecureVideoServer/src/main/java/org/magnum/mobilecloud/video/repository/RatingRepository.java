package org.magnum.mobilecloud.video.repository;

import org.magnum.mobilecloud.video.model.*;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * An interface for a repository that can store UserVideoRating objects.
 * 
 * @author Eugene
 *
 */
@Repository
public interface RatingRepository extends CrudRepository<UserVideoRating, Long>{

    // Find all ratings with a matching video (e.g., UserVideoRating.video)
    public Collection<UserVideoRating> findByVideo(Video video);

    // Find rating that matches video and owner
    public Collection<UserVideoRating> findByVideoAndOwner(Video video, User owner);

}
