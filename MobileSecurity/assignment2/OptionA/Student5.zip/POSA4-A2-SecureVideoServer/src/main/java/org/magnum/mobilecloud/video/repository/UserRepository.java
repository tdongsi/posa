package org.magnum.mobilecloud.video.repository;

import org.magnum.mobilecloud.video.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * An interface for a repository that can store User objects.
 * 
 * @author Eugene
 *
 */
@Repository
public interface UserRepository extends CrudRepository<User, String>{

}
