/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.magnum.mobilecloud.video.controller;

import com.google.common.collect.Lists;
import javassist.NotFoundException;
import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.model.*;
import org.magnum.mobilecloud.video.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.Principal;
import java.security.acl.NotOwnerException;
import java.util.*;

/**
 * This simple VideoSvc allows clients to send HTTP POST requests with
 * videos that are stored in memory using a list. Clients can send HTTP GET
 * requests to receive a JSON listing of the videos that have been sent to
 * the controller so far. Stopping the controller will cause it to lose the history of
 * videos that have been sent to it because they are stored in memory.
 *
 * Notice how much simpler this VideoSvc is than the original VideoServlet?
 * Spring allows us to dramatically simplify our service. Another important
 * aspect of this version is that we have defined a VideoSvcApi that provides
 * strong typing on both the client and service interface to ensure that we
 * don't send the wrong parameters, etc.
 *
 * @author eugene karasev
 *
 */

// Tell Spring that this class is a Controller that should
// handle certain HTTP requests for the DispatcherServlet
@Controller
public class VideoSvc {

    // The VideoRepository that we are going to store our videos
    // in. We don't explicitly construct a VideoRepository, but
    // instead mark this object as a dependency that needs to be
    // injected by Spring. Our Application class has a method
    // annotated with @Bean that determines what object will end
    // up being injected into this member variable.
    @Autowired
    private VideoRepository videos;

    @Autowired
    private UserRepository users;

    @Autowired
    private RatingRepository ratings;

    // Receives GET requests to /video and returns the current
    // list of videos. Spring automatically converts
    // the list of videos to JSON because of the @ResponseBody
    // annotation.
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.GET)
    public @ResponseBody Collection<Video> getVideoList(){
        return Lists.newArrayList(videos.findAll());
    }

    // Receives POST requests to /video and converts the HTTP
    // request body, which should contain json, into a Video
    // object before adding it to the list. The @RequestBody
    // annotation on the Video parameter is what tells Spring
    // to interpret the HTTP request body as JSON and convert
    // it into a Video object to pass into the method. The
    // @ResponseBody annotation tells Spring to convert the
    // return value from the method back into JSON and put
    // it into the body of the HTTP response to the client.
    //
    // The VIDEO_SVC_PATH is set to "/video" in the VideoSvcApi
    // interface. We use this constant to ensure that the
    // client and service paths for the VideoSvc are always
    // in sync.
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @RequestMapping(value= VideoSvcApi.VIDEO_SVC_PATH, method= RequestMethod.POST)
    public @ResponseBody Video addVideo(
                    @RequestBody Video entity,
                    Principal principal){

        // Looking for existing video with the same title
        List<Video> videoList =  new ArrayList(videos.findByTitle(entity.getTitle()));
        if (!videoList.isEmpty()) {
            // Looking for existing video with the same title
            // and the current user is owner of the existing video
            List<Video> userList =  new ArrayList(videos
                    .findByTitleAndOwner(entity.getTitle(), users.findOne(principal.getName())));
            if (!userList.isEmpty()) {
                // If current user is the owner then delete the current video (to replace with the new one)
                videos.delete(userList.get(0));
            } else {
                // If current user isn't the owner then return found video
                return videoList.get(0);
            }
        }
        // Check whether user exists, if doesn't create the new one
        if (!users.exists(principal.getName())) {
            users.save(new User(principal.getName()));
        }
        // Set video owner
        entity.setOwner(users.findOne(principal.getName()));

        //Add video to the repository to get videoId
        entity = videos.save(entity);

        // Set video url as location
        String location = getUrlBaseForLocalServer() + "/video/" + entity.getId() + "/data";
        entity.setLocation(location);

        //Update video entity (set location) in the repository
        entity = videos.save(entity);

        return entity;
    }

    // Receives POST requests to /video{id}/data and converts the HTTP
    // request body, which should contain json, into a multipart binary Video
    // object.
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @RequestMapping(value=VideoSvcApi.VIDEO_DATA_PATH, method= RequestMethod.POST)
    public @ResponseBody VideoStatus setVideoData (
            @PathVariable(VideoSvcApi.ID_PARAMETER) long videoId,
            @RequestParam(VideoSvcApi.DATA_PARAMETER) MultipartFile videoData,
            Principal principal)
            throws NotOwnerException, NotFoundException {
        // Set status into intermediate state
        VideoStatus status = new VideoStatus(VideoStatus.VideoState.PROCESSING);
        try {
            // Get stream suitable for getting binary data from HTTP request
            // and writing into the file
            InputStream inputStream = videoData.getInputStream();
            // Instantiate file manager to handle video files
            VideoFileManager fileManager = new VideoFileManager();
            // Check whether provided id is correct
            if(videos.exists(videoId)) {
                if (videos.findOne(videoId).getOwner().getUser().equals(principal.getName())) {
                    fileManager.saveVideoData(videos.findOne(videoId), inputStream);
                } else {
                    // Throw an exception if the user isn't owner
                    throw new AccessDeniedException("Binary video upload isn't possible, access denied");
            }
            } else {
                // Throw an exception if there is no video object for requested id
                throw new NotFoundException("Binary video upload isn't possible, parent object doesn't exists");
            }
            // Set status into final state
            status.setState(VideoStatus.VideoState.READY);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return status;
    }

    // Register exception handler to let Spring change HTTP response status to 403 as required
    // in case if exception was thrown. We use just empty method wrapped with Spring annotations
    @ExceptionHandler(NotOwnerException.class)
    @ResponseStatus(value = HttpStatus.FORBIDDEN, reason = "You are not allowed to upload this video data")
    public void handleNotOwnerException(NotOwnerException ex, HttpServletResponse response) {
    }

    // Receives GET requests to /video/{id} and returns the Video object
    // or a 404 if no video data has been set yet.
    // The URL scheme is the same as in the method above and assumes
    // that the client knows the ID of the Video object that it would
    // like to retrieve video data for.
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}", method=RequestMethod.GET)
    public @ResponseBody Video getVideo(
            @PathVariable(VideoSvcApi.ID_PARAMETER) long videoId,
            HttpServletResponse response)
            throws NotFoundException {

        return videos.findOne(videoId);
    }

    // Receives GET requests to /video/{id}/data and returns the video data
    // that has been associated with a Video object or a 404 if no video data
    // has been set yet. The URL scheme is the same as in the method above
    // and assumes that the client knows the ID of the Video object
    // that it would like to retrieve video data for.
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @RequestMapping(value=VideoSvcApi.VIDEO_DATA_PATH, method=RequestMethod.GET)
    public void getData (
            @PathVariable(VideoSvcApi.ID_PARAMETER) long videoId,
            HttpServletResponse response)
            throws NotFoundException {
        try {
            // Set HTTP response content type to save the video file
            // with appropriate extension/run browser video/mp4 plug-in
            response.setHeader("Content-Type", "video/mp4");
            // Get stream suitable for writing binary data in the response
            OutputStream outputStream = response.getOutputStream();
            // Instantiate file manager to handle video files
            VideoFileManager fileManager = new VideoFileManager();
            // Check whether provided id is correct
            if (videos.exists(videoId) && fileManager.hasVideoData(videos.findOne(videoId))) {
                fileManager.copyVideoData(videos.findOne(videoId), outputStream);
            } else {
                // Throw an exception if there is no video object or video files
                // for requested id
                throw new NotFoundException("The requested video doesn't exists");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Register exception handler to let Spring change HTTP response status to 404 as required
    // in case if exception was thrown. We use just empty method wrapped with Spring annotations
    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "The requested video doesn't exists")
    public void handleNotFoundException(NotFoundException ex, HttpServletResponse response) {
    }

    // Receives POST requests to /video{id}/rating and converts the HTTP
    // request body, which should contain json, into an integer rating.
    // Returns average rating calculated on the base of ratings available.
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @RequestMapping(value= VideoSvcApi.RATING_SET_PATH, method= RequestMethod.POST)
    public @ResponseBody AverageVideoRating addRating(
            @PathVariable(VideoSvcApi.ID_PARAMETER) long videoId,
            @PathVariable(VideoSvcApi.RATING_PARAMETER) int rating,
            Principal principal)
            throws NotFoundException {

        // Check whether user exists, if doesn't create the new one
        if (!users.exists(principal.getName())) {
            users.save(new User(principal.getName()));
        }
        // Check whether video object exists, if doesn't throw an exception
        if (videos.exists(videoId)) {
            // Looking for existing rating of current user
            List<UserVideoRating> ratingsList =
                    new ArrayList(ratings.findByVideoAndOwner(
                            videos.findOne(videoId),
                            users.findOne(principal.getName())));
            // If the rating exists
            if (!ratingsList.isEmpty()) {
                // Deleting the current rating (to replace with the new one)
                ratings.delete(ratingsList);
            }
        } else {
            // Throw an exception if there is no video object for requested id
            throw new NotFoundException("The requested video doesn't exists");
        }
        // Add new rating entry
        ratings.save(new UserVideoRating(rating,
                videos.findOne(videoId),
                users.findOne(principal.getName())));

        // Calculate totals and return AverageVideoRating
        int totalRatings=0;
        double summaryRating=0;
        for (UserVideoRating videoRating : ratings.findByVideo(videos.findOne(videoId))) {
            summaryRating += videoRating.getRating();
            totalRatings++;
        }
        return new AverageVideoRating(summaryRating/totalRatings, videoId, totalRatings);
    }

    // Receives GET requests to /video/{id} and returns the Video object
    // or a 404 if no video data has been set yet.
    // The URL scheme is the same as in the method above and assumes
    // that the client knows the ID of the Video object that it would
    // like to retrieve video data for.
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @RequestMapping(value=VideoSvcApi.RATING_GET_PATH, method=RequestMethod.GET)
    public @ResponseBody AverageVideoRating getVideoRating(
                @PathVariable(VideoSvcApi.ID_PARAMETER) long videoId,
                HttpServletResponse response)
                throws NotFoundException {

        int totalRatings=0;
        double summaryRating=0;

        for (UserVideoRating videoRating : ratings.findByVideo(videos.findOne(videoId))) {
            summaryRating += videoRating.getRating();
            totalRatings++;
        }

        return new AverageVideoRating(summaryRating/totalRatings, videoId, totalRatings);
    }

    // This utility method returns complete URL to the server
    private String getUrlBaseForLocalServer() {
        HttpServletRequest request =
                ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String base =
                "http://"+request.getServerName()
                        + ((request.getServerPort() != 80) ? ":"+request.getServerPort() : "");
        return base;
    }

}
