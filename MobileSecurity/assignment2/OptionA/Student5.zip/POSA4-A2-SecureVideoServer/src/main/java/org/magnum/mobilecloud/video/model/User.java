package org.magnum.mobilecloud.video.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

import java.util.Collection;

@Entity
public class User {

    @Id
    private String name;

    // We ask Jackson to ignore this property when serializing
    // a Category to avoid the problem of circular references
    // in our JSON. Since this is a bi-directional relationship,
    // if we didn't ignore this property, Jackson would generate
    // a stack overflow by trying to serialize the Videos in the
    // User, which in turn refer back to the User, which
    // would refer back to the Videos, etc. creating an infinite
    // loop. By ignoring this property, we break the chain.
    @JsonIgnore
    @OneToMany(mappedBy="owner")
    private Collection<Video> videos;

    @JsonIgnore
    @OneToMany(mappedBy="owner")
    private Collection<UserVideoRating> ratings;

	public User() {
	}

	public User(String name) {
		super();
		this.name = name;
	}

	public String getUser() {
		return name;
	}

	public void setUser(String name) {
		this.name = name;
	}

    public Collection<Video> getVideos() {
        return videos;
    }

    public void setVideos(Collection<Video> videos) {
        this.videos = videos;
    }

    public Collection<UserVideoRating> getRatings() {
        return ratings;
    }

    public void setRatings(Collection<UserVideoRating> ratings) {
        this.ratings = ratings;
    }

}
