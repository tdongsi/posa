package org.magnum.mobilecloud.video.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity
public class UserVideoRating {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long ratingId;

    private int rating;

    @ManyToOne
    private User owner;

    @JsonIgnore
    @ManyToOne
    private Video video;

    public UserVideoRating() {
    }

	public UserVideoRating(int rating, Video video, User owner) {
		super();
		this.rating = rating;
		this.video = video;
		this.owner = owner;
	}

    public long getId() {
        return ratingId;
    }

    public User getRatingOwner() {
        return owner;
    }

    public void setRatingOwner(User owner) {
        this.owner = owner;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

	public int getRating() {
		return rating;
	}

    public void setVideo(Video video) {
        this.video = video;
    }

	public Video getVideo() {
		return video;
	}

}
