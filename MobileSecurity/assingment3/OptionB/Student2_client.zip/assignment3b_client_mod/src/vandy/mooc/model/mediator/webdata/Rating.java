package vandy.mooc.model.mediator.webdata;

public class Rating {
	private float rating;

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}
	
}
