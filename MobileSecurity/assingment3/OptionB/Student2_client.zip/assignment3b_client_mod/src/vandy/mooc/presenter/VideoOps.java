package vandy.mooc.presenter;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.List;

import android.R;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import vandy.mooc.common.ConfigurableOps;
import vandy.mooc.common.ContextView;
import vandy.mooc.common.GenericAsyncTask;
import vandy.mooc.common.GenericAsyncTaskOps;
import vandy.mooc.model.local.LocalVideo;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.model.services.DownloadVideoService;
import vandy.mooc.model.services.UploadVideoService;
import vandy.mooc.provider.OnVideoUpdatedCallback;
import vandy.mooc.provider.UpdateRatingAsyncTask;
import vandy.mooc.provider.UpdateVideoAsyncTask;
import vandy.mooc.provider.VideoContract.VideoEntry;
import vandy.mooc.provider.VideoProvider;
import vandy.mooc.view.VideoActivity;

public class VideoOps 
	implements ConfigurableOps<VideoOps.View>,
	GenericAsyncTaskOps<Video, Void, LocalVideo>,
	OnVideoUpdatedCallback,
	UpdateRatingAsyncTask.OnRatingUpdatedCallback
	{

	 /**
     * Debugging tag used by the Android logger.
     */
    private static final String TAG =
    		VideoOps.class.getSimpleName();
    
    private static final String INTENT_VIDEO_ID = "VIDEO_ID";
    private static final String INTENT_VIDEO_TITLE = "VIDEO_TITLE";
    private static final String INTENT_VIDEO_DURATION = "VIDEO_DURATION";    
    private static final String INTENT_VIDEO_CONTENT_TYPE = "VIDEO_CONTENT_TYPE";
    private static final String INTENT_VIDEO_DATA_URL = "VIDEO_DATA_URL";
    private static final String INTENT_VIDEO_RATING = "VIDEO_RATING";

    private Video mVideo;
    
    private LocalVideo mLocalVideo;
    
    private EditText mEditTextVideo = null;
    
    private VideoProvider mVideoProvider;
    
    /**
     * Store the context to allow access to application-specific
     * resources and classes.
     */
    private Context mContext;
    
    /**
     * Used to enable garbage collection.
     */
    private WeakReference<VideoOps.View> mVideoView;
    /**
     * The GenericAsyncTask used to expand an Video in a background
     * thread to a LocalVideo that wraps a remote Video.
     */
    private GenericAsyncTask<Video,
                             Void,
                             LocalVideo,
                             VideoOps> mAsyncTask;
    
    private UpdateVideoAsyncTask mVideoUpdaterTask;

    private UpdateRatingAsyncTask mRatingUpdaterTask;
    
	public interface View extends ContextView {
        /**
         * Finishes the Activity the VideoOps is
         * associated with.
         */
        void finish();    
        void updateDisplay(Video video);
        void updateDisplay(LocalVideo localVideo);
        void startAnActivity(Intent intent);
        void updateRating(float rating);
    }
	  /**
     * Default constructor that's needed by the GenericActivity
     * framework.
     */
    public VideoOps() {
    }
    
    /**
     * Called after a runtime configuration change occurs to finish
     * the initialisation steps.
     */
    
	@Override
	public void onConfiguration(View view, boolean firstTimeIn) {
		
		final String time =
	            firstTimeIn 
	            ? "first time" 
	            : "second+ time";
	        
	        Log.d(TAG,
	              "onConfiguration() called the "
	              + time
	              + " with view = "
	              + view);

	        // (Re)set the mVideoView WeakReference.
	        mVideoView =
	            new WeakReference<>(view);
	        
	        if (firstTimeIn) {
	        	
	        	mVideoProvider = new VideoProvider();
	        	
	        	mContext = view.getActivityContext();
	        	Log.i(
	        			TAG, 
	        			String.format(
	        					"context is null %s", mContext == null? true: false));	      
	        }    
	}
	
	 /**
     *	Factory Method to create an intent that VideoActivity can consume    
     */
	public static Intent makeVideoActivityIntent(Context context, Video video) {		
		
		Intent intent = new Intent(context, VideoActivity.class);		
	    intent.putExtra(INTENT_VIDEO_ID, video.getId());
		intent.putExtra(INTENT_VIDEO_TITLE, video.getTitle());
		intent.putExtra(INTENT_VIDEO_DURATION, video.getDuration());
		intent.putExtra(INTENT_VIDEO_CONTENT_TYPE, video.getContentType());
		intent.putExtra(INTENT_VIDEO_DATA_URL, video.getDataUrl());
		intent.putExtra(INTENT_VIDEO_RATING, video.getRating());
		
		return intent;
	}
	public static Video parseVideoFromIntent(Bundle bundle) {
		
		Video video = null;
		if (bundle != null) {
			
			video = new Video();
			video.setTitle(bundle.getString(INTENT_VIDEO_TITLE, ""));
			video.setId(bundle.getLong(INTENT_VIDEO_ID, 0));
			video.setDuration(bundle.getLong(INTENT_VIDEO_DURATION, 0));
			video.setContentType(bundle.getString(INTENT_VIDEO_CONTENT_TYPE,""));
			video.setDataUrl(bundle.getString(INTENT_VIDEO_DATA_URL, ""));
			video.setRating(bundle.getFloat(INTENT_VIDEO_RATING, 0));
			
		}
		
		return video;
	}
	public void setVideo(Video video) {
		mVideo = video;
	}
	
	public void updateDisplay() {
		
		mVideoView.get().updateDisplay(mVideo);
		
	}
	public void updateLocalDisplay() {
		mVideoView.get().updateDisplay(mLocalVideo);
	}
	
	public void getLocalVideo(Video video){
		
        mAsyncTask = new GenericAsyncTask<>(this);
        mAsyncTask.execute(video);
        
    }
	@Override
	public LocalVideo doInBackground(Video... params) {
		
		Video video = params[0];
		Log.i(TAG, String.format("doInBackground %s", video));
		LocalVideo localVideo = new LocalVideo(video);
		
		//now lookup video locally
		final String SELECTION_VIDEO =
                VideoEntry.COLUMN_EXTERNAL_ID
                        + " = ?";
		
		String[] selectionArgs = { String.valueOf(video.getId()) };
		Cursor cursor = null;
		try {
			cursor =
                    mContext.getContentResolver().query
                            (VideoEntry.CONTENT_URI,
                                    null,
                                    SELECTION_VIDEO,
                                    selectionArgs,
                                    null);
			if (!cursor.moveToFirst()) {
				Log.e(TAG, String.format("Video external_id %d  not found", video.getId()));
			}
			else {
				//cursor.moveToFirst();
			
				String title = cursor.getString(						
						cursor.getColumnIndex(
                                VideoEntry.COLUMN_TITLE));
				
				Log.i(TAG, String.format("Found external_id %d  title %s", video.getId(), title));
				
				Integer index = cursor.getColumnIndex(VideoEntry.COLUMN_ID);
				
				Long localId = (long) cursor.getInt(index);
				
				localVideo.setLocalId(localId);
						
				String localLocation = cursor.getString(
						cursor.getColumnIndex(VideoEntry.COLUMN_LOCAL_LOCATION));
				
				localVideo.setLocalLocation(localLocation);						
				
			}
              
			
		} catch(Exception ex) {
			Log.e(TAG, ex.getMessage());
			ex.printStackTrace();
			
		}
		finally{
			if (cursor != null) {
				cursor.close();		
			}
				
		}	
		
		return localVideo;
	}
	
	  /**
     * Display the results in the UI Thread.
     */
	@Override
	public void onPostExecute(LocalVideo localVideo) {
		
		Log.i(TAG, String.format("onPostExecute %s", localVideo));
		mLocalVideo = localVideo;
		updateLocalDisplay();
		
		
	}
	 /**
     * Start a service that Download the Video having given Id.
     *   
     * @param videoId
     */
    public void downloadVideo(){
    	
        // Sends an Intent command to the DownloadVideoService.

    	Log.i(TAG, String.format("downloadVideo: %d", mVideo.getId() ));
    		Intent downloadIntent = DownloadVideoService.makeIntent 
                    (mVideoView.get().getApplicationContext(),
                   		 mVideo.getId(),
                   		 mVideo.getTitle());
        	
            mVideoView.get().getApplicationContext().startService
                (downloadIntent);
    	
    }
    public void playVideo() {
    	
    	Log.i(TAG, "playing video ...");
    	Log.i(TAG, mLocalVideo.getLocalLocation());    	
    	Uri videoUri = Uri.fromFile(new File(mLocalVideo.getLocalLocation()));
    	if (videoUri != null) {
    	
    		Intent intent = new Intent();
    		intent.setAction(Intent.ACTION_VIEW);    	
    		intent.setDataAndType(videoUri, "video/*");
    		mVideoView.get().startAnActivity(intent);    		
    	}    
    	else {
    		Log.i(TAG, "unable to parse uri");
    	}
    }
    /*
     * start async task to store video locally, when complete refresh display
     * @param localPath
     * 
     */
    public void handleDownloadComplete(String localPath) {
    	
    	Log.i(TAG, String.format("handleDownloadComplete: %s", localPath ));
    	mVideoUpdaterTask = new UpdateVideoAsyncTask(mContext, this);
    	//store local path...
    	mLocalVideo.setLocalLocation(localPath);
    	mVideoUpdaterTask.execute(mLocalVideo);
    	
    }

	@Override
	public void OnUpdateComplete(Long videoId) {
		
		Log.i(TAG, String.format("OnUpdateComplete: %d", videoId ));
		
		updateLocalDisplay();
		
	}	
	
	public void updateRating(float rating) {
		
		Log.i(TAG, String.format("setRating: %f", rating ));
		mRatingUpdaterTask = new UpdateRatingAsyncTask(mContext, this);
		mVideo.setRating(rating);
    	
    	mRatingUpdaterTask.execute(mVideo);
//		submit post to service
//		get back rating,
//		update db
		
	}
	@Override
	public void OnRatingUpdateComplete(float rating) {
		
		Log.i(TAG, String.format("OnRatingUpdateComplete: %f", rating ));
		mVideo.setRating(rating);
		//updateLocalDisplay();
		mVideoView.get().updateRating(rating);
		
		
	}
	
}

