package vandy.mooc.provider;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import vandy.mooc.model.mediator.VideoDataMediator;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.provider.VideoContract.VideoEntry;

public class UpdateRatingAsyncTask extends  AsyncTask<Video, Void, Float>{

	private static final String TAG =
			UpdateRatingAsyncTask.class.getSimpleName();
	
	private Context mContext;
	private OnRatingUpdatedCallback mCallback;
	
	public UpdateRatingAsyncTask(Context context, OnRatingUpdatedCallback callback) {
		mContext = context;
		mCallback = callback;
	}
	
	@Override
	protected Float doInBackground(Video... params) {
		
		Video video = params[0];
		long videoId = video.getId();
		
		Log.i(TAG, String.format("doInBackground %s", video) );		
		float rating = video.getRating();		
		
		//pass rating up to server, returning new average
		VideoDataMediator mediator = new VideoDataMediator();
		float newRating = mediator.updateRating(video.getId(), rating);
		
		//update content provider with new value
		String[] selectionArgs = new String[] { String.valueOf(videoId) };
		Uri uri = VideoEntry.CONTENT_URI;				
		ContentValues cvs  = new ContentValues();
		String selectionClause = VideoEntry.COLUMN_EXTERNAL_ID + " = ? ";
		cvs.put(VideoEntry.COLUMN_AVG_RATING, newRating);
		
		int rowsUpdated = 
			mContext.getContentResolver().
				update(
						uri, 
						cvs, 
						selectionClause, 
						selectionArgs);
			
		Log.i(TAG, String.format("Rows Updated %d", rowsUpdated) );		
		return newRating;
	}
	
	@Override
	protected void onPostExecute(Float result) {
		
		mCallback.OnRatingUpdateComplete(result);
    }
	public interface OnRatingUpdatedCallback {
		
		public void OnRatingUpdateComplete(float rating);
		
	}

}
