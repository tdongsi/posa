package vandy.mooc.provider;

import android.content.ContentUris;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * This contract defines the metadata for the HobbitContentProvider,
 * including the provider's access URIs and its "database" constants.
 */
public class VideoContract {
    /**
     * This ContentProvider's unique identifier.
     */
    public static final String CONTENT_AUTHORITY =
        "vandy.mooc.videocontentprovider";

    /**
     * Use CONTENT_AUTHORITY to create the base of all URI's which
     * apps will use to contact the content provider.
     */
    public static final Uri BASE_CONTENT_URI =
        Uri.parse("content://"
                  + CONTENT_AUTHORITY);

    /*
     * Columns
     */

    /**
     * Possible paths (appended to base content URI for possible
     * URI's).  For instance, content://vandy.mooc/character_map/ is a
     * valid path for looking at Character data.  Conversely,
     * content://vandy.mooc/givemeroot/ will fail, as the
     * ContentProvider hasn't been given any information on what to do
     * with "givemeroot".
     */
    public static final String PATH_VIDEO =
    		VideoEntry.TABLE_NAME;

    /**
     * Inner class that defines the table contents of the Hobbit
     * table.
     */
    public static final class VideoEntry implements BaseColumns {
        /**
         * Use BASE_CONTENT_URI to create the unique URI for Acronym
         * Table that apps will use to contact the content provider.
         */
        public static final Uri CONTENT_URI = 
            BASE_CONTENT_URI.buildUpon()
            .appendPath(PATH_VIDEO).build();

        /**
         * When the Cursor returned for a given URI by the
         * ContentProvider contains 0..x items.
         */
        public static final String CONTENT_ITEMS_TYPE =
            "vnd.android.cursor.dir/"
            + CONTENT_AUTHORITY
            + "/" 
            + PATH_VIDEO;
            
        /**
         * When the Cursor returned for a given URI by the
         * ContentProvider contains 1 item.
         */
        public static final String CONTENT_ITEM_TYPE =
            "vnd.android.cursor.item/"
            + CONTENT_AUTHORITY
            + "/" 
            + PATH_VIDEO;

        /**
         * Name of the database table.
         */
        public static final String TABLE_NAME =
            "videos";

        /**
         * Selection clause to find rows with given acronym.
         */
        public static final String SELECTION_ID =
        		VideoEntry.COLUMN_ID
            + " = ?";
    	
        /**
         * Columns to store data.
         */
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_EXTERNAL_ID = "external_id";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_DURATION = "duration";
        public static final String COLUMN_SERVER_LOCATION = "server_location";
        public static final String COLUMN_LOCAL_LOCATION = "local_location";
        public static final String COLUMN_SUBJECT = "subject";
        public static final String COLUMN_CONTENT_TYPE = "content_type";
        public static final String COLUMN_AVG_RATING = "avg_rating";    	

        /**
         * Return a Uri that points to the row containing a given id.
         * 
         * @param id
         * @return Uri
         */
        public static Uri buildUri(Long id) {
            return ContentUris.withAppendedId(CONTENT_URI,
                                              id);
        }
    }
}
