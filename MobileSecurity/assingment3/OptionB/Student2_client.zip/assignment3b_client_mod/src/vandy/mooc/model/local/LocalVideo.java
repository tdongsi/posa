package vandy.mooc.model.local;

import vandy.mooc.model.mediator.webdata.Video;

public class LocalVideo {	
	
	private Video remoteVideo;
	private String localLocation;
	private Long localId;	

	public boolean existsLocally() {
		return localLocation != null;
	}	

	public Video getRemoteVideo() {
		return remoteVideo;
	}

	public void setRemoteVideo(Video remoteVideo) {
		this.remoteVideo = remoteVideo;
	}

	public String getLocalLocation() {
		return localLocation;
	}

	public void setLocalLocation(String localLocation) {
		this.localLocation = localLocation;
	}

	public Long getLocalId() {
		return localId;
	}

	public void setLocalId(Long localId) {
		this.localId = localId;
	}

	public LocalVideo (Video remoteVideo) {
		
		this.remoteVideo = remoteVideo;
	}
	
	@Override
    public String toString() {
        return "{" +
            "_Id: "+ localId + ", "+
            "localLocation: "+ localLocation + ", "+
            "Video: " + remoteVideo + 
            "}";
    }
}
