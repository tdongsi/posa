package vandy.mooc.view;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import vandy.mooc.R;
import vandy.mooc.common.GenericActivity;
import vandy.mooc.model.local.LocalVideo;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.model.services.DownloadVideoService;
import vandy.mooc.presenter.VideoOps;

public class VideoActivity
	extends GenericActivity<VideoOps.View, VideoOps>
	implements VideoOps.View 
{
	private EditText mEditTextVideo = null; 
	
	private Button mDownloadButton = null;	
	private Button mPlayButton = null;	
	private RatingBar mRatingBar = null;
	private boolean bFromOps = false;
	
	private Button mLikeButton = null;
	private Button mUnlikeButton = null;
	private Button mGetLikeList	= null;

	
	/**
     * The Broadcast Receiver that registers itself to receive the
     * result from UploadVideoService when a video upload completes.
     */
    private DownloadResultReceiver mDownloadResultReceiver;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		  // Initialize the default layout.
		//Log.i(TAG, String.format("savedInstanceState is null %d", savedInstanceState == null ? 1: 0) );
        setContentView(R.layout.video_activity);
		
        super.onCreate(savedInstanceState,
	        		VideoOps.class,
	                       this);
        
        mEditTextVideo = (EditText)findViewById(R.id.editTextVideo);
        //mDownloadButton = (Button)findViewById(R.id.buttonDownload);
        //mPlayButton = (Button)findViewById(R.id.buttonPlay);
        //mRatingBar = (RatingBar)findViewById(R.id.ratingBarVideo);
        mLikeButton = (Button)findViewById(R.id.buttonLike);
        mUnlikeButton = (Button)findViewById(R.id.buttonUnlike);
        mGetLikeList = (Button)findViewById(R.id.buttonGetLikeList);
        
        // Receiver for the notification.
        mDownloadResultReceiver = new DownloadResultReceiver();
        
        Intent intent = getIntent();
       // Log.i(TAG, String.format("intent is null %d", intent == null ? 1: 0) );
        if (intent != null) {
        	
        	Video video = VideoOps.parseVideoFromIntent(intent.getExtras());
        	getOps().setVideo(video);
        	getOps().updateDisplay();  
        	getOps().getLocalVideo(video);
        	Log.i(TAG,String.format("video: %s",video));
        	
        	mDownloadButton.setOnClickListener(new View.OnClickListener() {
        	    public void onClick(View v) {
        	        Log.i(TAG, "Download Pressed");
        	        getOps().downloadVideo();
        	    }
        	});
        	mPlayButton.setOnClickListener(new View.OnClickListener() {
        	    public void onClick(View v) {
        	    	Log.i(TAG, "Play Pressed");
        	    	getOps().playVideo();
        	    	
        	    }
        	});
        	mRatingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
				
				@Override
				public void onRatingChanged(RatingBar ratingBar, float rating,
						boolean fromUser) {
					if (bFromOps)
						return;
					Log.i(TAG, "onRatingChanged: " + rating);
					getOps().updateRating(rating);
					
				}
			});
        }  
        
        
	}
	 /**
     *  Hook method that is called when user resumes activity
     *  from paused state, onPause(). 
     */
    @Override
    protected void onResume() {
        // Call up to the superclass.
        super.onResume();

        // Register BroadcastReceiver that receives result from
        // DownloadVideoService when a video download completes.
        registerReceiver();
    }
    
    /**
     * Hook method that gives a final chance to release resources and
     * stop spawned threads. onDestroy() may not always be called-when
     * system kills hosting process
     */
    @Override
    protected void onPause() {
        // Call onPause() in superclass.
        super.onPause();
        
        // Unregister BroadcastReceiver.
        LocalBroadcastManager.getInstance(this)
          .unregisterReceiver(mDownloadResultReceiver);
    }
	public void updateDisplay(Video video) {
		
		mEditTextVideo.setText(video.getTitle());
		mRatingBar.setRating(video.getRating());
		
	}
	
	@Override
	public void updateDisplay(LocalVideo localVideo) {		
		
		mDownloadButton.setEnabled(!localVideo.existsLocally());
		mPlayButton.setEnabled(localVideo.existsLocally());
		
	}
	/**
     * Register a BroadcastReceiver that receives a result from the
     * DownloadVideoService when a video upload completes.
     */
    private void registerReceiver() {
        
        // Create an Intent filter that handles Intents from the
        // UploadVideoService.
        IntentFilter intentFilter =
            new IntentFilter(DownloadVideoService.ACTION_DOWNLOAD_SERVICE_RESPONSE);
        intentFilter.addCategory(Intent.CATEGORY_DEFAULT);

        // Register the BroadcastReceiver.
        LocalBroadcastManager.getInstance(this)
               .registerReceiver(mDownloadResultReceiver,
                                 intentFilter);
    }
    /**
     * The Broadcast Receiver that registers itself to receive result
     * from DownloadVideoService.
     */
    private class DownloadResultReceiver 
            extends BroadcastReceiver {
        /**
         * Hook method that's dispatched when the UploadService has
         * uploaded the Video.
         */
        @Override
        public void onReceive(Context context,
                              Intent intent) {
        	Log.i(TAG, "DownloadResultReceiver.onReceive");
        	String localPath = intent.getStringExtra(DownloadVideoService.INTENT_LOCAL_FILE);
        	if (localPath != null) {
        		Log.i(TAG, String.format("Local Path: %s", localPath));
        		getOps().handleDownloadComplete(localPath);
        		
        	} else {
        		Log.e(TAG, String.format("No Local Path %s!", ""));
        	}           
        }
    }
    
	@Override
	public void startAnActivity(Intent intent) {
	
		Log.d(TAG, "starting activity");
	
		startActivity(intent);
		
		
	}
	@Override
	public void updateRating(float rating) {
		
		bFromOps = true;
		mRatingBar.setEnabled(false);
		mRatingBar.setRating(rating);
		mRatingBar.setEnabled(true);
		bFromOps = false;
		
	}
}
