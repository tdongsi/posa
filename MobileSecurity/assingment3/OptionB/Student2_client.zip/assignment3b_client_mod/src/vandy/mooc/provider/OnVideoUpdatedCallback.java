package vandy.mooc.provider;

public interface OnVideoUpdatedCallback {
	
	public void OnUpdateComplete(Long videoId);
	
}
