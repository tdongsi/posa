package vandy.mooc.provider;

import vandy.mooc.model.local.LocalVideo;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.presenter.VideoListOps;
import vandy.mooc.provider.VideoContract.VideoEntry;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

public class UpdateVideoAsyncTask 
	extends AsyncTask<LocalVideo, Void, Long>{
	 /**
     * Debugging tag used by the Android logger.
     */
    private static final String TAG =
    		UpdateVideoAsyncTask.class.getSimpleName();
    
    private OnVideoUpdatedCallback mCallback;
    
    private Context mContext;
    
    public UpdateVideoAsyncTask(Context context, 
    		OnVideoUpdatedCallback callback) {
    	
    	mContext = context;
    	mCallback = callback;
    }
    
	@Override
	protected Long doInBackground(LocalVideo... params) {
		
		Long result = 0L;
		LocalVideo localVideo = params[0];
		Log.i(TAG, String.format("doInBackground %s", localVideo) );		
	
		Uri uri = VideoEntry.CONTENT_URI;
		
		ContentValues cvs  = new ContentValues();	
		Video video = localVideo.getRemoteVideo();
		
		cvs.put(VideoEntry.COLUMN_TITLE, video.getTitle());
		cvs.put(VideoEntry.COLUMN_EXTERNAL_ID, video.getId());
		cvs.put(VideoEntry.COLUMN_DURATION, video.getDuration());
		cvs.put(VideoEntry.COLUMN_SERVER_LOCATION, video.getDataUrl());
		cvs.put(VideoEntry.COLUMN_LOCAL_LOCATION, localVideo.getLocalLocation());
		cvs.put(VideoEntry.COLUMN_SUBJECT, video.getSubject());
		cvs.put(VideoEntry.COLUMN_CONTENT_TYPE, video.getContentType());
		//todo: implement rating
		cvs.put(VideoEntry.COLUMN_AVG_RATING, 0);
		
		Uri insertedUri = null;
		try {
			insertedUri = mContext.getContentResolver()
					.insert(
						uri, 
						cvs);				
				
			if (insertedUri != null) {
				result = ContentUris.parseId(insertedUri);
			}	
		} catch(Exception ex) {
			Log.e(TAG, ex.getMessage());
			ex.printStackTrace();
		}
		
		
		return result;
	}
	@Override
	protected void onPostExecute(Long result) {
		
		mCallback.OnUpdateComplete(result);
    }

}
