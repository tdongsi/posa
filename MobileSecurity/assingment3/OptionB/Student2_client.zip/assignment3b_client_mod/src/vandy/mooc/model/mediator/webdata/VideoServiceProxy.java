package vandy.mooc.model.mediator.webdata;

import java.util.Collection;

import retrofit.client.Response;
import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.Multipart;
import retrofit.http.POST;
import retrofit.http.Part;
import retrofit.http.Path;
import retrofit.http.Streaming;
import retrofit.mime.TypedFile;

/**
 * This interface defines an API for a Video Service web service.  The
 * interface is used to provide a contract for client/server
 * interactions.  The interface is annotated with Retrofit annotations
 * to send Requests and automatically convert the Video.
 */
public interface VideoServiceProxy {
    /**
     * Used as Request Parameter for Video data.
     */
    public static final String DATA_PARAMETER = "data";

    /**
     * Used as Request Parameter for VideoId.
     */
    public static final String ID_PARAMETER = "id";

    /**
     * The path where we expect the VideoSvc to live.
     */
    public static final String VIDEO_SVC_PATH = "/video";
	
    /**
     * The path where we expect the VideoSvc to live.
     */
    public static final String VIDEO_DATA_PATH = 
        VIDEO_SVC_PATH 
        + "/{"
        + VideoServiceProxy.ID_PARAMETER
        + "}/data";

    //-----------------------------------------------------------------
    // Reference the implementation of Assignment 2B, so as to have the 
    // following Retrofit APIs.
	/**
	 * Assignment 2, Option B
	 * https://github.com/juleswhite/mobilecloudsecurity-15/tree/master/assignments/assignment2b
	 * 
	 * The HTTP API that you must implement so that this test will pass is as follows:
	 * (1) POST /oauth/token
	 * (2) GET /video
	 * (3) POST /video
	 * (4) GET /video/{id}
	 * (5) POST /video/{id}/like
	 * (6) POST /video/{id}/unlike
	 * (7) GET /video/{id}/likedby
	 */
    
	/**
	 * Follow the API defined in the interface VideoSvcApi (in VideoSvcApi.java), 
	 * but not directly implement that interface.
	 * -- Need to implement all the following functions:
	 * (1) performOAuth() -- new
	 * (2) getVideoList()
	 * (3) addVideo()
	 * (4) getVideoById()
	 * (5) likeVideo()
	 * (6) unlikeVideo()
	 * (7) getLikesList() // getUsersWhoLikedVideo()
	 */       
    
    //-----------------------------------------------------------------
	/**
	 * (1) void performOAuth() -- new
	 * The access point for the OAuth 2.0 Password Grant flow.
	 * 
	 * In VideoSvcApi.java: add the following API
	 * @POST(TOKEN_PATH)
	 * public void performOAuth()
	 */
    //@POST(TOKEN_PATH)
	//public void performOAuth();
    //-----------------------------------------------------------------
    
    //-----------------------------------------------------------------
	/**
	 * (2) Collection<Video> getVideoList()
	 * @return
	 * 
	 * In VideoSvcApi.java:
	 * @GET(VIDEO_SVC_PATH)
	 * public Collection<Video> getVideoList();
	 */    
    
    /**
     * Sends a GET request to get the List of Videos from Video
     * Web service using a two-way Retrofit RPC call.
     */
    @GET(VIDEO_SVC_PATH)
    public Collection<Video> getVideoList();
    //-----------------------------------------------------------------      
    
    //-----------------------------------------------------------------
	/**
	 * (3) Video addVideo(Video v)
	 * @param v
	 * @return
	 * 
	 * In VideoSvcApi.java:
	 * @POST(VIDEO_SVC_PATH)
	 * public Video addVideo(@Body Video v);
	 */    
    
    /**
     * Sends a POST request to add the Video metadata to the Video 
     * Web service using a two-way Retrofit RPC call.
     *
     * @param video meta-data
     * @return Updated video meta-data returned from the Video Service.
     */
    @POST(VIDEO_SVC_PATH)
    public Video addVideo(@Body Video video);	
    //-----------------------------------------------------------------
    
    //-----------------------------------------------------------------
    // NOTE: setVideoData(), getData, getRating(), and addRating()
    // are for Assignment 3A, so they are not used in Assignment 3B.
    /**
     * Sends a POST request to Upload the Video data to the Video Web
     * service using a two-way Retrofit RPC call.  @Multipart is used
     * to transfer multiple content (i.e. several files in case of a
     * file upload to a server) within one request entity.  When doing
     * so, a REST client can save the overhead of sending a sequence
     * of single requests to the server, thereby reducing network
     * latency.
     * 
     * @param id
     * @param videoData
     * @return videoStatus indicating status of the uploaded video.
     */
    @Multipart
    @POST(VIDEO_DATA_PATH)
    public VideoStatus setVideoData(@Path(ID_PARAMETER) long id,
                                    @Part(DATA_PARAMETER) TypedFile videoData);
	
    /**
     * This method uses Retrofit's @Streaming annotation to indicate
     * that the method is going to access a large stream of data
     * (e.g., the mpeg video data on the server).  The client can
     * access this stream of data by obtaining an InputStream from the
     * Response as shown below:
     * 
     * VideoServiceProxy client = ... // use retrofit to create the client
     * Response response = client.getData(someVideoId); 
     * InputStream videoDataStream = response.getBody().in();
     * 
     * @param id
     * @return Response which contains the actual Video data.
     */
    @Streaming
    @GET(VIDEO_DATA_PATH)
    Response getData(@Path(ID_PARAMETER) long id);
    
    @GET("/video/{id}/rating")
    public float getRating(@Path(ID_PARAMETER) long id);
    
    /**
     * Sends a POST request to add the Video metadata to the Video 
     * Web service using a two-way Retrofit RPC call.
     *
     * @param video meta-data
     * @return Updated video meta-data returned from the Video Service.
     */
   // @FormUrlEncoded
    @POST("/video/{id}/rating")
    public float addRating(@Path ("id") long id, @Body Rating rating);
    
    //-----------------------------------------------------------------
     
 
    //-----------------------------------------------------------------  
    // NEW: Add code to handle "like" and "unlike" 
    
    //-----------------------------------------------------------------
	/**
	 * (4) Video getVideoById()
	 * Returns the video with the given id or 404 if the video is not found.
	 * 
	 * In VideoSvcApi.java:
	 * @GET(VIDEO_SVC_PATH + "/{id}")
	 * public Video getVideoById(@Path("id") long id);
	 */
    @GET(VIDEO_SVC_PATH + "/{id}")
	public Video getVideoById(@Path("id") long id);
    //-----------------------------------------------------------------
    
    //-----------------------------------------------------------------
    /**
     * (5) Void likeVideo()
     * Allows a user to like a video. 
     * Returns 200 Ok on success, 404 if the video is not found, 
     * or 400 if the user has already liked the video.
     * 
     * In VideoSvcApi.java:
     * @POST(VIDEO_SVC_PATH + "/{id}/like")
     * public Void likeVideo(@Path("id") long id);
     */    
    @POST(VIDEO_SVC_PATH + "/{id}/like")
    public Void likeVideo(@Path("id") long id);
    //-----------------------------------------------------------------
    
    //-----------------------------------------------------------------
    /**
     * (6) Void unlikeVideo()
     * Allows a user to unlike a video that he/she previously liked. 
     * Returns 200 OK on success, 404 if the video is not found, 
     * and a 400 if the user has not previously liked the specified video.
     * 
     * In VideoSvcApi.java:
     * @POST(VIDEO_SVC_PATH + "/{id}/unlike")
     * public Void unlikeVideo(@Path("id") long id);
     */        
    @POST(VIDEO_SVC_PATH + "/{id}/unlike")
    public Void unlikeVideo(@Path("id") long id);
    //-----------------------------------------------------------------
    
    //-----------------------------------------------------------------
    /**
     * (7) Collection<String> getLikesList
     * Returns a list of the string usernames of the users that have liked the 
     * specified video. If the video is not found, a 404 error should be generated.
     * 
     * In VideoSvcApi.java:
     * @GET(VIDEO_SVC_PATH + "/{id}/likedby")
     * public Collection<String> getLikesList(@Path("id") long id);
     */       
    @GET(VIDEO_SVC_PATH + "/{id}/likedby")
    public Collection<String> getLikesList(@Path("id") long id);
    //-----------------------------------------------------------------
    
    
}
