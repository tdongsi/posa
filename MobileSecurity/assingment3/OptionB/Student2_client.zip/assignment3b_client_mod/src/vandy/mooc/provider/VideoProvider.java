package vandy.mooc.provider;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

public class VideoProvider extends ContentProvider {
	/**
     * Logcat tag.
     */
    private final String TAG = 
        getClass().getCanonicalName();

    /**
     * Constant for the Weather Values table's name.
     */
    private static final String VIDEO_VALUES_TABLE_NAME =
        VideoContract.VideoEntry.TABLE_NAME;

    /**
     * UriMatcher code for the Weather Values table.
     */
    private static final int VIDEO_VALUES_ITEMS = 100;

    /**
     * UriMatcher code for a specific row in the Weather Values table.
     */
    private static final int VIDEO_VALUES_ITEM = 110;

   
    /**
     * UriMatcher that is used to demultiplex the incoming URIs into
     * requests.
     */
    private static final UriMatcher sUriMatcher =
        buildUriMatcher();

    /**
     * The database helper that is used to manage the providers
     * database.
     */
    private VideoDatabaseHelper mDatabaseHelper;
    /**
     * Build the UriMatcher for this Content Provider.
     */
    private static UriMatcher buildUriMatcher() {
        // Add default 'no match' result to matcher.
        final UriMatcher matcher =
            new UriMatcher(UriMatcher.NO_MATCH);

        // Initialize the matcher with the URIs used to access each
        // table.      
 
        matcher.addURI(VideoContract.CONTENT_AUTHORITY,
                       VIDEO_VALUES_TABLE_NAME,
                       VIDEO_VALUES_ITEMS);
        
        matcher.addURI(VideoContract.CONTENT_AUTHORITY,
        		VIDEO_VALUES_TABLE_NAME 
                       + "/#",
                       VIDEO_VALUES_ITEM);

        return matcher;
    }
	@Override
	public boolean onCreate() {
		
		 mDatabaseHelper =
		            new VideoDatabaseHelper(getContext());
		        return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		  Cursor retCursor;
	        final SQLiteDatabase db =
	        		mDatabaseHelper.getReadableDatabase();
	        // Match the id returned by UriMatcher to query appropriate
	        // rows.
	        switch (sUriMatcher.match(uri)) {
	        case VIDEO_VALUES_ITEMS: 
	        
	        	Log.i(TAG, "querying for items");
	            retCursor = db.query(VideoContract.VideoEntry.TABLE_NAME,
	                    projection,
	                    selection,
	                    selectionArgs,
	                    null,
	                    sortOrder,
	                    "");
	            break;
	        case VIDEO_VALUES_ITEM: 
	            // Selection clause that matches row id with id passed
	            // from Uri.
	        	Log.i(TAG, "querying for item");
	            final String rowId =
	                ""
	                + VideoContract.VideoEntry._ID
	                + " = '"
	                + ContentUris.parseId(uri)
	                + "'";

	            // TODO -- replace "null" by writing code to query the
	            // SQLite database for the particular rowId based on (a
	            // subset of) the parameters passed into the method.
	           // retCursor = null;
	            retCursor = db.query(VideoContract.VideoEntry.TABLE_NAME,
	                    projection,
	                    rowId,
	                    selectionArgs,
	                    null,
	                    sortOrder,
	                    "");
	            break;
	        default:
	            throw new UnsupportedOperationException("Unknown uri: " 
	                                                    + uri);
	        }

	        // Register to watch a content URI for changes.
	        retCursor.setNotificationUri(getContext().getContentResolver(), 
	                                     uri);
	        return retCursor;
	}

	@Override
	public String getType(Uri uri) {
		 // Use Uri Matcher to determine what kind of URI this is.
        final int match = sUriMatcher.match(uri);

        // Match the id returned by UriMatcher to return appropriate
        // MIME_TYPE.
        switch (match) {
        case VIDEO_VALUES_ITEMS:
            //return AcronymContract.AcronymEntry.CONTENT_ITEMS_TYPE;
            return VideoContract.VideoEntry.CONTENT_ITEMS_TYPE;
        case VIDEO_VALUES_ITEM:
           // return AcronymContract.AcronymEntry.CONTENT_ITEM_TYPE;
        	return VideoContract.VideoEntry.CONTENT_ITEM_TYPE;
        default:
            throw new UnsupportedOperationException("Unknown uri: " 
                                                    + uri);
        }
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// Create and/or open a database that will be used for reading
        // and writing. Once opened successfully, the database is
        // cached, so you can call this method every time you need to
        // write to the database.
        final SQLiteDatabase db =
        		mDatabaseHelper.getWritableDatabase();
        long id = 0;
        Uri returnUri = null;

        // Try to match against the path in a url.  It returns the
        // code for the matched node (added using addURI), or -1 if
        // there is no matched node.  If there's a match insert a new
        // row.
        switch (sUriMatcher.match(uri)) {
        case VIDEO_VALUES_ITEM:
            // TODO - replace 0 with code that inserts a row in Table
            // and returns the row id.
            //long id = 0;
        	Log.i(TAG, "inserting VIDEO_VALUES_ITEM");
            id = db.insert(
                    VideoContract.VideoEntry.TABLE_NAME,
                    null,
                    values );

            // Check if a new row is inserted or not.
            if (id > 0)
                returnUri = 
                		VideoContract.VideoEntry.buildUri(id);
            else
                throw new android.database.SQLException
                    ("Failed to insert row into " 
                     + uri);
            break;
        case VIDEO_VALUES_ITEMS:
        	Log.i(TAG, "inserting VIDEO_VALUES_ITEMS");
        	  id = db.insert(
                      VideoContract.VideoEntry.TABLE_NAME,
                      null,
                      values );

              // Check if a new row is inserted or not.
              if (id > 0)
                  returnUri = 
                  		VideoContract.VideoEntry.buildUri(id);
              else
                  throw new android.database.SQLException
                      ("Failed to insert row into " 
                       + uri);
        	break;
        default:
            throw new UnsupportedOperationException("Unknown uri: " 
                                                    + uri);
        }

        // Notifies registered observers that a row was inserted.
        getContext().getContentResolver().notifyChange(uri, 
                                                       null);
        return returnUri;
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		 // Number of rows updated.
        int rowsUpdated = 0;

        final SQLiteDatabase db = 
            mDatabaseHelper.getWritableDatabase();
        switch (sUriMatcher.match(uri)) {
        	case VIDEO_VALUES_ITEM:
        		Log.i(TAG, "updating VIDEO_VALUES_ITEM");
        		 rowsUpdated =
                 db.update(VideoContract.VideoEntry.TABLE_NAME,
                           values,
                           selection,
                           selectionArgs);
        		break;
        	case VIDEO_VALUES_ITEMS:
        		Log.i(TAG, "updating VIDEO_VALUES_ITEMS");
        		rowsUpdated =
                        db.update(VideoContract.VideoEntry.TABLE_NAME,
                                  values,
                                  selection,
                                  selectionArgs);
        		break;
        
        }
        // Register to watch a content URI for changes.
        getContext().getContentResolver().notifyChange(uri,
                                                       null);
        return rowsUpdated;
	}
    
    
}
