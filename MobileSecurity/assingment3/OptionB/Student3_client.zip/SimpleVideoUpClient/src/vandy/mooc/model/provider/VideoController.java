package vandy.mooc.model.provider;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.HttpClient;
import retrofit.RestAdapter.LogLevel;
import retrofit.client.ApacheClient;
import retrofit.client.Client;
import retrofit.client.OkClient;
import vandy.mooc.model.mediator.webdata.SecuredRestBuilder;
import vandy.mooc.model.mediator.webdata.UnsafeHttpsClient;
import vandy.mooc.model.webdata.VideoSvcApi;
import vandy.mooc.utils.Constants;
import android.content.Context;

/**
 * VideoController mediates the communication between the Video
 * Service and Android storage.
 */
public class VideoController {
    /**
     * Allows access to application-specific resources and classes.
     */
    private Context mContext;

    /**
     * Defines methods that communicates with Video Service.
    */
    private VideoSvcApi mVideoServiceProxy;
    
    private String USERNAME = "admin";
    private String PASSWORD = "pass";
    
    /**
     * Constructor that initializes the VideoController.
     * 
     * @param context
     */
    @SuppressWarnings("deprecation")
	public VideoController(Context context) {
        // Store the Application Context.
        mContext = context;
/*        
      	private VideoSvcApi videoService = new SecuredRestBuilder()
    			.setLoginEndpoint(TEST_URL + VideoSvcApi.TOKEN_PATH)
    			.setUsername(USERNAME)
    			.setPassword(PASSWORD)
    			.setClientId(CLIENT_ID)
    			.setClient(new ApacheClient(UnsafeHttpsClient.createUnsafeClient()))
    			.setEndpoint(TEST_URL).setLogLevel(LogLevel.FULL).build()
    			.create(VideoSvcApi.class);  */      
        
        // Initialize the VideoServiceProxy.
        mVideoServiceProxy = new SecuredRestBuilder()
		.setLoginEndpoint(Constants.SERVER_URL + VideoSvcApi.TOKEN_PATH)
		.setUsername(USERNAME)
		.setPassword(PASSWORD)
		.setClientId(Constants.CLIENT_ID)
		.setClient(/*new ApacheClient(*/new OkClient(UnsafeHttpsClient.getUnsafeOkHttpClient())/*)*/)
		.setEndpoint(Constants.SERVER_URL).setLogLevel(LogLevel.FULL).build()
		.create(VideoSvcApi.class);
        /*
        videoSvc_ = new com.isp.assignment3b.oauth.SecuredRestBuilder().setLoginEndpoint(server + VideoSvcApi.TOKEN_PATH)
        		.setUsername(user)
        		.setPassword(pass)
        		.setClientId(CLIENT_ID)
        		.setClient(new OkClient(UnsafeHttpsClient.getUnsafeOkHttpClient()) )
        		.setEndpoint(server).setLogLevel(LogLevel.FULL).build()
        		.create(VideoSvcApi.class);       */ 
    }

    /**
     * Get the List of Videos from Server
     * 
     * @return the List of Videos from Server or null if there is
     *         failure in getting the Videos.
     */
    public List<Video> getVideoList() {
        return (ArrayList<Video>) mVideoServiceProxy.getVideoList();
    }
    
    public Video addVideo(Video video) {
    	return mVideoServiceProxy.addVideo(video);
    }
    
    public void likeVideo(long videoId) {
    	mVideoServiceProxy.likeVideo(videoId, "Nothing");
    }
    
    public void unlikeVideo(long videoId) {
    	mVideoServiceProxy.unlikeVideo(videoId, "Nothing");
    }
    
    public List<String> getUsersWhoLikedVideo(long videoId) {
    	return (ArrayList<String>) mVideoServiceProxy.getUsersWhoLikedVideo(videoId);
    }
}
