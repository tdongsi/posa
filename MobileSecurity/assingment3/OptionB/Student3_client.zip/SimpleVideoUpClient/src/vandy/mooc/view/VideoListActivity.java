package vandy.mooc.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;

import vandy.mooc.R;
import vandy.mooc.common.CallableTask;
import vandy.mooc.common.GenericActivity;
import vandy.mooc.common.TaskCallback;
import vandy.mooc.common.Utils;
import vandy.mooc.model.provider.Video;
import vandy.mooc.model.provider.VideoSvc;
import vandy.mooc.model.webdata.VideoSvcApi;
import vandy.mooc.presenter.VideoOps;
import vandy.mooc.utils.VideoMediaStoreUtils;
import vandy.mooc.utils.VideoStorageUtils;
import vandy.mooc.view.ui.FloatingActionButton;
import vandy.mooc.view.ui.UploadVideoDialogFragment;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Gravity;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * This Activity can be used upload a selected video to a Video
 * Service and also displays a list of videos available at the Video
 * Service.  The user can record a video or get a video from gallery
 * and upload it.  This Activity extends GenericActivity, which
 * provides a framework that automatically handles runtime
 * configuration changes.  It implements OnVideoSelectedListener that
 * will handle callbacks from the UploadVideoDialog Fragment.
 */
public class VideoListActivity /*extends Activity */ extends GenericActivity<VideoOps>
implements UploadVideoDialogFragment.OnVideoSelectedListener  {
	private static final String ERROR_400 = "Bad Request";
    /**
     * The Request Code needed in Implicit Intent start Video
     * Recording Activity.
     */
    private final int REQUEST_VIDEO_CAPTURE = 0;

    /**
     * The Request Code needed in Implicit Intent to get Video from
     * Gallery.
     */
    private final int REQUEST_GET_VIDEO = 1;
	
    /**
     * The Floating Action Button that will show a Dialog Fragment to
     * upload Video when user clicks on it.
     */
    private FloatingActionButton mUploadVideoButton;	
    
	/**
	 * Uri to store the Recorded Video.
	 */
	private Uri mRecordVideoUri;    

	@InjectView(R.id.videoList)
	protected ListView videoList_;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_video_list);

		ButterKnife.inject(this);
        // Show the Floating Action Button.
        createPlusFabButton();
        
        registerForContextMenu(videoList_);
        
    	videoList_.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            	videoList_.showContextMenuForChild(view);
            }
        });              
                
        // Call up to the special onCreate() method in
        // GenericActivity, passing in the VideoOps class to
        // instantiate and manage.
        super.onCreate(savedInstanceState,
                       VideoOps.class);
	}

	@Override
	protected void onResume() {
		super.onResume();
		
		refreshVideos();
	}
	
	private void refreshVideos() {
		final VideoSvcApi svc = VideoSvc.getOrShowLogin(this);

		if (svc != null) {
			CallableTask.invoke(new Callable<Collection<Video>>() {

				@Override
				public Collection<Video> call() throws Exception {
					return svc.getVideoList();
				}
			}, new TaskCallback<Collection<Video>>() {

				@Override
				public void success(Collection<Video> result) {
					List<Video> names = new ArrayList<Video>();

					names.addAll(result);
					videoList_.setAdapter(new ArrayAdapter<Video>(
							VideoListActivity.this,
							android.R.layout.simple_list_item_1, names));
				}

				@Override
				public void error(Exception e) {
					Toast.makeText(
							VideoListActivity.this,
							"Unable to fetch the video list, please login again.",
							Toast.LENGTH_SHORT).show();

					startActivity(new Intent(VideoListActivity.this,
							LoginScreenActivity.class));
				}
			});
		}
	}
	
	private void getLikers(final long videoId) {
		final VideoSvcApi svc = VideoSvc.getOrShowLogin(this);

		if (svc != null) {
			CallableTask.invoke(new Callable<Collection<String>>() {

				@Override
				public Collection<String> call() throws Exception {
					return svc.getUsersWhoLikedVideo(videoId);
				}
			}, new TaskCallback<Collection<String>>() {

				@Override
				public void success(Collection<String> result) {
					List<String> users = new ArrayList<String>();

					users.addAll(result);
					
					Intent intent_ = new Intent(VideoListActivity.this,
							LikersListActivity.class);
					
					intent_.putExtra("users", (ArrayList<String>) users);
					startActivity(intent_);
				}

				@Override
				public void error(Exception e) {
					Toast.makeText(
							VideoListActivity.this,
							"Unable to fetch the video list, please login again.",
							Toast.LENGTH_SHORT).show();

					startActivity(new Intent(VideoListActivity.this,
							LoginScreenActivity.class));
				}
			});
		}
	}	

	private void uploadVideo(String videoPath) {
		final VideoSvcApi svc = VideoSvc.getOrShowLogin(this);
	
		final Video video = VideoMediaStoreUtils.getVideo(getApplicationContext(), 
				videoPath);	

		if (svc != null) {
			CallableTask.invoke(new Callable<Collection<Video>>() {
				@Override
				public Collection<Video> call() throws Exception {
					Video video_ = svc.addVideo(video);
					Collection<Video> addedVideo = new ArrayList<Video>();
					addedVideo.add(video_);
					return addedVideo;
				}
			}, new TaskCallback<Collection<Video>>() {

				@Override
				public void success(Collection<Video> result) {
					VideoListActivity.this.refreshVideos();
				}

				@Override
				public void error(Exception e) {
					Toast.makeText(
							VideoListActivity.this,
							"Unable to add video to service, please login again.",
							Toast.LENGTH_SHORT).show();

					startActivity(new Intent(VideoListActivity.this,
							LoginScreenActivity.class));
				}
			});
		}
	}
	
	private void likeOrUnlikeVideo(final long videoId, final boolean like) {
		final VideoSvcApi svc = VideoSvc.getOrShowLogin(this);

		if (svc != null) {
			CallableTask.invoke(new Callable<Boolean>() {
				@Override
				public Boolean call() throws Exception {
					if(like)
						svc.likeVideo(videoId, "Nothing");
					else
						svc.unlikeVideo(videoId, "Nothing");
					return true;
				}
			}, new TaskCallback<Boolean>() {

				@Override
				public void success(Boolean result) {
					VideoListActivity.this.refreshVideos();
				}

				@Override
				public void error(Exception e) {
					String genericError = "Unable to like video in service, please login again.";
					boolean error400 = false;
					
					Log.e(this.getClass().getName(), e.getMessage());
					
					if(e.getMessage().contains(ERROR_400)) {
						if(like)
							genericError = "You have already liked this video";
						else
							genericError = "You haven't yet liked this video";
						
						error400 = true;
					}
					
					Toast.makeText(
							VideoListActivity.this,
							genericError,
							Toast.LENGTH_SHORT).show();
					
					if (!error400)
						startActivity(new Intent(VideoListActivity.this,
								LoginScreenActivity.class));
				}
			});
		}
	}	
	
    /**
     * Show the Floating Action Button that will show a Dialog
     * Fragment to upload Video when user clicks on it.
     */
    @SuppressWarnings("deprecation")
    private void createPlusFabButton() {
        final DisplayMetrics metrics =
            getResources().getDisplayMetrics();
        final int position =
            (metrics.widthPixels / 4) + 5;

        mUploadVideoButton =
            new FloatingActionButton
            .Builder(this)
            .withDrawable(getResources()
                          .getDrawable(R.drawable.ic_video))
            .withButtonColor(getResources()
                             .getColor(R.color.theme_primary))
            .withGravity(Gravity.BOTTOM | Gravity.END)
            .withMargins(0, 
                         0,
                         position,
                         0)
            .create();

        // Show the UploadVideoDialog Fragment when user clicks the
        // Button.
        mUploadVideoButton.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
					Toast.makeText(
							VideoListActivity.this,
							"User has decided to upload a video.",
							Toast.LENGTH_SHORT).show();                 	
                    new UploadVideoDialogFragment().show(getFragmentManager(),
                                                         "uploadVideo");
               	
                }
            });
    }

    /**
     * The user selected the option to get Video from the
     * UploadVideoDialog Fragment.  Based on what the user selects
     * either record a Video or get a Video from the Video Gallery.
     */
    @Override
    public void onVideoSelected(int which) {
        if (which == UploadVideoDialogFragment.VIDEO_GALLERY) 
            // Get the Video from Video Gallery.
            getVideoFromGallery();
        else if (which == UploadVideoDialogFragment.RECORD_VIDEO) 
            // Record a video.
            selectRecordVideo();
    }

    /**
     * Start an Activity by implicit Intent to get the Video from
     * Android Video Gallery.
     */
    private void getVideoFromGallery() {
        // Create an intent that will start an Activity to
        // get Video from Gallery.
        final Intent intent = 
            new Intent(Intent.ACTION_GET_CONTENT)
            .setType("video/*")
            .putExtra(Intent.EXTRA_LOCAL_ONLY,
                      true);

        // Verify that the intent will resolve to an Activity.
        if (intent.resolveActivity(getPackageManager()) != null) 
            startActivityForResult(intent,
                                   REQUEST_GET_VIDEO);
    }

    /**
     * Start an Activity by Implicit Intent to Record the Video.
     */
    private void selectRecordVideo() {
		mRecordVideoUri = VideoStorageUtils
				.getRecordedVideoUri(getApplicationContext());
		// Create an intent that will start an Activity to get
		// Record Video.
		final Intent recordVideoIntent = new Intent(
				MediaStore.ACTION_VIDEO_CAPTURE).putExtra(
				MediaStore.EXTRA_OUTPUT, mRecordVideoUri);
		
		// Verify the intent will resolve to an Activity.
		if (recordVideoIntent.resolveActivity(getPackageManager()) != null)
			// Start an Activity to record a video.
			startActivityForResult(recordVideoIntent, REQUEST_VIDEO_CAPTURE);

    }
	

    /**
     * Hook method called when an activity you launched exits, giving
     * you the requestCode you started it with, the resultCode it
     * returned, and any additional data from it.
     * 
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    public void onActivityResult(int requestCode,
                                 int resultCode,
                                 Intent data) {
    	
    	Utils.showToast(this,
                "Coming back and processing selected video");    	
        Uri videoUri = null; 

        // Check if the Result is Ok and upload the Video to the Video
        // Service.
        if (resultCode == Activity.RESULT_OK && resultCode == RESULT_OK && data != null) {
            // Video picked from the Gallery.
            if (requestCode == REQUEST_GET_VIDEO)
                videoUri = data.getData();
                
            // Video is recorded.
            else if (requestCode == REQUEST_VIDEO_CAPTURE)
                videoUri = mRecordVideoUri;
              
            if (videoUri != null){
                Utils.showToast(this,
                                "Uploading video");
                
                // Get the path of video file from videoUri.
                String filePath =
                    VideoMediaStoreUtils.getPath(this.getApplicationContext(),
                                                 videoUri);	                
            
                // Upload the Video.
                uploadVideo(filePath);
            }
        }

        // Pop a toast if we couldn't get a video to upload.
        if (videoUri == null)
            Utils.showToast(this,
                            "Could not get video to upload");
    }    
    
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.contextmenu, menu);
        menu.setHeaderIcon(R.drawable.likers);
        menu.setHeaderTitle(R.string.tLikify);
    }  
    
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        // Here's how you can get the correct item in onContextItemSelected()
        AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
        Video selectedVideo = (Video) this.videoList_.getItemAtPosition(info.position);      
                
        Log.i(VideoListActivity.class.getName(), selectedVideo.toString());
        
        switch (item.getItemId()) {
            case R.id.getAllLikers:
            	//Utils.showToast(getApplicationContext(), "User wants to get list of likers for video " + selectedVideo.getId());
            	getLikers(selectedVideo.getId());
                return true;
            case R.id.doLike:
            	//Utils.showToast(getApplicationContext(), "User wants to like a video");
            	likeOrUnlikeVideo(selectedVideo.getId(), true);
                return true;
            case R.id.doUnlike:
            	//Utils.showToast(getApplicationContext(), "User wants to unlike a video");
            	this.likeOrUnlikeVideo(selectedVideo.getId(), false);
            	return true;
            default:
                return super.onContextItemSelected(item);
        }
    }  
    
}
