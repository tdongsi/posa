package vandy.mooc.view;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

import vandy.mooc.R;
import vandy.mooc.model.provider.Video;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class LikersListActivity extends Activity {
	
	@InjectView(R.id.lvMain)
	protected ListView usersList_;	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.users_like_video);
		ButterKnife.inject(this);
		
		Intent intent = getIntent();
		
		@SuppressWarnings("unchecked")
		ArrayList<String> users = (ArrayList<String>) intent.getSerializableExtra("users");
		
		usersList_.setAdapter(new ArrayAdapter<String>(
				LikersListActivity.this,
				android.R.layout.simple_list_item_1, users));		
	}
}