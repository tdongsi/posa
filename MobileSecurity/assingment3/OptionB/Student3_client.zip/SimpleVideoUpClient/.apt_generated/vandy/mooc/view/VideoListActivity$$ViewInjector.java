// Generated code from Butter Knife. Do not modify!
package vandy.mooc.view;

import android.view.View;
import butterknife.ButterKnife.Finder;

public class VideoListActivity$$ViewInjector {
  public static void inject(Finder finder, final vandy.mooc.view.VideoListActivity target, Object source) {
    View view;
    view = finder.findRequiredView(source, 2131296260, "field 'videoList_'");
    target.videoList_ = (android.widget.ListView) view;
  }

  public static void reset(vandy.mooc.view.VideoListActivity target) {
    target.videoList_ = null;
  }
}
