/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package org.magnum.mobilecloud.video;

import java.security.Principal;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.repository.Video;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.google.common.collect.Lists;

@Controller
public class VideoController {

	//public List<Video> videosList = new CopyOnWriteArrayList<Video>();

	/*
	 * Required:
	 * 
	 * GET /video
	 * POST /video
	 * GET /video/{id}
	 * POST /video/{id}/like
	 * POST /video/{id}/unlike
	 * GET /video/{id}/likedby
	 */

	@Autowired
	private VideoRepository videos;
	
	
	private static final AtomicLong currentId = new AtomicLong(0L);
	
	
	@RequestMapping(value="/video", method=RequestMethod.GET)
	public @ResponseBody List<Video> getAllVideos(){
		return Lists.newArrayList(videos.findAll());
		//return videos;
	}
	
	@RequestMapping(value = "/video/{id}", method = RequestMethod.GET)
	public @ResponseBody Video getData(@PathVariable("id") long id, HttpServletResponse mResponse) {

		Video v = findVideoWithId(id);

		if (v == null) {
			mResponse.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return v;
	}


	@RequestMapping(value = "/video/{id}/likedby", method = RequestMethod.GET)
	public @ResponseBody String getLikedBy(@PathVariable("id") long id, HttpServletResponse mResponse) {

		Video v = findVideoWithId(id);

		if (v == null) {
			mResponse.setStatus(HttpServletResponse.SC_NOT_FOUND);
			return "";
		}

		return v.getLikedBy().toString();
	}
	
	


	
	
	@RequestMapping(value="/video", method=RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video v, Principal p){

		System.out.println("** id is " + v.getId());
		
		long incomingVideoId = v.getId();
		
		Video existingVideo = this.findVideoWithId(incomingVideoId);
		
		//Check if it exists. If so, only overwrite if author is the same
		if (existingVideo != null) {
			
			//Video with this ID already exists. So update only if owner is the same as auth'd user
			String authdUserName = p.getName() == null ? "" : p.getName();
			
			System.out.println("** authdUserName is " + authdUserName);
			System.out.println("** videoOwner is " + v.getOwner());
			
			if (authdUserName.equalsIgnoreCase(v.getOwner())) {
				//Ok to overwrite
				System.out.println("** Ok to overwrite");
				existingVideo.overwriteMeWith(v);
				videos.save(existingVideo);
				return existingVideo;
			} else {
				//Different owner, so don't overwrite
				System.out.println("** Different owner, so don't overwrite");
				return existingVideo;
			}
		} else {
			//New video!
			System.out.println("** New video!");
			//v.setOwner(p.getName());
			//v.setLikes(0);
			v.setId((int)currentId.incrementAndGet());
			v.setUrl(getDataUrl(v.getId()));
			videos.save(v);
			return v;
		}
	}
	
	
	@RequestMapping(value="/video/{id}/unlike", method=RequestMethod.POST)
	public void unlikeVideo(@PathVariable("id") long id, Principal p, HttpServletResponse mResponse) {
		
		Video vid = findVideoWithId(id);
		
		if (vid == null) {
			mResponse.setStatus(HttpServletResponse.SC_NOT_FOUND);
			return;
		}
		
		if (vid.isVideoLikedAlready(p.getName())) {
			vid.removeLikedBy(p.getName());
			videos.save(vid);
		} else {
			mResponse.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			return;
		}

	}
	
	
	public boolean hasAlreadyLiked(String username, Video v) {

		return v.getLikedBy().contains(username);
	}
	
	
	@RequestMapping(value="/video/{id}/like", method=RequestMethod.POST)
	public @ResponseBody Video likeVideo(@PathVariable("id") long id, Principal p, HttpServletResponse mResponse){
		
		//Check if user already liked this vid
		Video thisVid = findVideoWithId(id);
		
		if (thisVid == null) {
			mResponse.setStatus(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
		
		if (thisVid.isVideoLikedAlready(p.getName())) {
			mResponse.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			return null;
		}
		
		thisVid.addLikedBy(p.getName());
		videos.save(thisVid);
		return thisVid;
	}
	
	
	
	
	private Video findVideoWithId(long id) {
		for (Video v : Lists.newArrayList(videos.findAll())) {
			if (v.getId() == id) {
				return v;
			}
		}
		return null;
	}
	
	
	
	private String getDataUrl(long videoId) {
		//String base_url = "http://192.168.0.26:8080"; // for real device wifi
		//String base_url = "http://192.168.0.20:8080"; // for real device
		String base_url = getUrlBaseForLocalServer(); //for emulator
		String url = base_url + "/video/" + videoId + "/data";
		System.out.println("** getDataUrl is " + url);
		return url;

	}

	private String getUrlBaseForLocalServer() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		String base = "http://"
				+ request.getServerName()
				+ ((request.getServerPort() != 80) ? ":"
						+ request.getServerPort() : "");
		return base;
	}
}
