package com.application3b;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


public class VideoListActivity extends Activity implements OnItemClickListener {

	public static final String VIDEO_ID_EXTRA = "videoIdExtra";
	
	protected ListView videoList_;
	protected Button addVideoBtn;
	
	private final String TAG = "Assignment3b";
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videolist);
        
        addVideoBtn = (Button)findViewById(R.id.add_video);
        videoList_ = (ListView)findViewById(R.id.listview);
        
        videoList_.setOnItemClickListener(this);
        
        Button addVideoBtn = (Button)findViewById(R.id.add_video);
        addVideoBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(VideoListActivity.this, VideoAddActivity.class));
			}
        	
        });
    }

    
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
    
    
    @Override
	protected void onResume() {
		super.onResume();
		
		refreshVideos();
	}
    
    
    private void refreshVideos() {
		final VideoSvcApi svc = VideoSvc.getOrShowLogin(this);

		if (svc != null) {
			CallableTask.invoke(new Callable<Collection<Video>>() {

				@Override
				public Collection<Video> call() throws Exception {
					return svc.getVideoList();
				}

			}, new TaskCallback<Collection<Video>>() {

				@Override
				public void success(Collection<Video> result) {
					
					Log.d(TAG, "in success");
					
					List<String> names = new ArrayList<String>();
					
					Log.d(TAG, "got " + names.size() + " videos");
					
					for (Video v : result) {
						names.add(v.getId() + "-" + v.getName());
					}

					videoList_.setAdapter(new ArrayAdapter<String>(VideoListActivity.this, android.R.layout.simple_list_item_1, names));
				}

				@Override
				public void error(Exception e) {
					
					Log.d(TAG, "in error");
					
					Toast.makeText(VideoListActivity.this, "Unable to fetch the video list, please login again.", Toast.LENGTH_SHORT).show();

					startActivity(new Intent(VideoListActivity.this, LoginActivity.class));
				}
			});
		} else {
			Log.d(TAG, "svc is NULL ");
		}
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

		String name = ((TextView)view).getText().toString();
		String [] parts = name.split("-");

		Log.d(TAG, "ID to open is " + parts[0]);

		Intent intent = new Intent(VideoListActivity.this, VideoDetailActivity.class);
		intent.putExtra(VideoListActivity.VIDEO_ID_EXTRA, parts[0]);

		startActivity(intent);
	}
}
