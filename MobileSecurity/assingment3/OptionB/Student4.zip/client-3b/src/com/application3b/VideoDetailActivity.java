package com.application3b;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.Callable;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class VideoDetailActivity extends Activity implements OnClickListener {


	private final String TAG = "Assignment3b";
	
	private String videoId;
	
	boolean alreadyLikedByThisUser = false;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videodetail);
        
        videoId = this.getIntent().getStringExtra(VideoListActivity.VIDEO_ID_EXTRA);
        
        refreshVideo(Long.parseLong(videoId));

        Button likeBtn = (Button)findViewById(R.id.like_btn);
        likeBtn.setOnClickListener(this);
    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
    
    
    private void populateUi(Video v) {
    	
    	TextView titleTv = (TextView)this.findViewById(R.id.title_tv);
    	titleTv.setText(v.getName());
    	
    	TextView idTv = (TextView)this.findViewById(R.id.id_tv);
    	idTv.setText(String.valueOf(v.getId()));
    	
    	TextView urlTv = (TextView)this.findViewById(R.id.url_tv);
    	urlTv.setText(v.getUrl());
    	
    	TextView durationTv = (TextView)this.findViewById(R.id.duration_tv);
    	durationTv.setText(String.valueOf(v.getDuration()));
    	
    	TextView likesTv = (TextView)this.findViewById(R.id.likes_tv);
    	likesTv.setText(String.valueOf(v.getLikes()));
    	
    	TextView ownerTv = (TextView)this.findViewById(R.id.owner_tv);
    	ownerTv.setText(v.getOwner());
    	
    	TextView likedByTv = (TextView)this.findViewById(R.id.likedby_tv);
    	likedByTv.setText(v.getLikedBy().toString());
    	
    	String likedBy = likedByTv.getText().toString();
    	likedBy = likedBy.replace("[", "");
    	likedBy = likedBy.replace("]", "");
    	
    	String [] allLikeUser = likedBy.split(",");
    	
    	alreadyLikedByThisUser = false;
    	
    	for(String user : allLikeUser) {
    		user = user.trim();
    		if (user.equalsIgnoreCase(LoginActivity.loggedInUsername)) {
    			alreadyLikedByThisUser = true;
    			break;
    		}
    	}
    	
    	Button likeBtn = (Button)findViewById(R.id.like_btn);
    	if (alreadyLikedByThisUser) {
    		likeBtn.setText("Already Liked! Click here to unlike");
    	} else {
    		likeBtn.setText("Click here to like");
    	}
    	
    }
    
    private void refreshVideo(final long videoId) {

		final VideoSvcApi svc = VideoSvc.getOrShowLogin(this);

		if (svc != null) {
			CallableTask.invoke(new Callable<Collection<Video>>() {

				@Override
				public Collection<Video> call() throws Exception {
					
					Collection<Video> vids = new ArrayList<Video>();
					
					Video thisVid = svc.getVideoById(videoId);
					vids.add(thisVid);
					return vids;
				}

			}, new TaskCallback<Collection<Video>>() {

				@Override
				public void success(Collection<Video> result) {
					
					Log.d(TAG, "in success");
					
					//Just want the first one!
					int cnt = 0;
					for (Video v : result) {
						if (cnt == 0) {
							populateUi(v);
						}
						cnt++;
					}
				}

				@Override
				public void error(Exception e) {
					
					Log.d(TAG, "in error");
					
					Toast.makeText(VideoDetailActivity.this, "Unable to fetch the video, please login again.", Toast.LENGTH_SHORT).show();

					startActivity(new Intent(VideoDetailActivity.this, LoginActivity.class));
				}
			});
		} else {
			Log.d(TAG, "svc is NULL ");
		}
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


	@Override
	public void onClick(View v) {
		likeVideo(Long.parseLong(videoId), alreadyLikedByThisUser);
		if (alreadyLikedByThisUser) {
    		//Toast.makeText(this, "onClick,  alreadyLiked is true", Toast.LENGTH_SHORT).show();
    	} else {
    		//Toast.makeText(this, "onClick,  alreadyLiked is false", Toast.LENGTH_SHORT).show();
    	}
	}

	
	
	private void likeVideo(final long videoId, final boolean shouldUnlike) {

		final VideoSvcApi svc = VideoSvc.getOrShowLogin(this);

		if (svc != null) {
			CallableTask.invoke(new Callable<Void>() {

				@Override
				public Void call() throws Exception {
					
					if (shouldUnlike) {
						return svc.unlikeVideo(videoId);
					} else {
						return svc.likeVideo(videoId);
					}
				}

			}, new TaskCallback<Void>() {

				@Override
				public void success(Void result) {
					if (shouldUnlike) {
						Toast.makeText(VideoDetailActivity.this, "Unliked!", Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(VideoDetailActivity.this, "Liked!", Toast.LENGTH_SHORT).show();
					}
					finish();
				}

				@Override
				public void error(Exception e) {
					
					Log.d(TAG, "in error");
					
					Toast.makeText(VideoDetailActivity.this, "Unable to like or unlike the video, please try again.", Toast.LENGTH_SHORT).show();
				}
			});
		} else {
			Log.d(TAG, "svc is NULL ");
		}
	}
}
