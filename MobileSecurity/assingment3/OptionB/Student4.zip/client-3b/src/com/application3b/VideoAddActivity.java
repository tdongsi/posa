package com.application3b;

import java.util.concurrent.Callable;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class VideoAddActivity extends Activity {


	private final String TAG = "Assignment3b";
	

	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videoadd);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
    
    public void addVideo(View v) {
    	
    	EditText etName = (EditText)findViewById(R.id.title_et);
    	String name = etName.getText().toString();
    	
    	EditText etDuration = (EditText)findViewById(R.id.duration_et);
    	String duration = etDuration.getText().toString();
    	
    	Video newVid = new Video();
    	newVid.setName(name);
    	newVid.setDuration(Long.parseLong(duration));
    	newVid.setOwner(LoginActivity.loggedInUsername);

    	createVideo(newVid);
    }

    
    private void createVideo(final Video thisVideo) {

		final VideoSvcApi svc = VideoSvc.getOrShowLogin(this);

		if (svc != null) {
			CallableTask.invoke(new Callable<Video>() {

				@Override
				public Video call() throws Exception {
										
					Video thisReturnedVid = svc.addVideo(thisVideo);
					return thisReturnedVid;
				}

			}, new TaskCallback<Video>() {

				@Override
				public void success(Video result) {
					
					Log.d(TAG, "in success");
					Toast.makeText(VideoAddActivity.this, "Created: " + result.getName(), Toast.LENGTH_SHORT).show();
					finish();
				}

				@Override
				public void error(Exception e) {
					
					Log.d(TAG, "in error");
					
					Toast.makeText(VideoAddActivity.this, "Unable to create the video, please try again.", Toast.LENGTH_SHORT).show();
				}
			});
		} else {
			Log.d(TAG, "svc is NULL ");
		}
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


}
