package com.application3b;


import java.util.Collection;
import java.util.concurrent.Callable;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class LoginActivity extends Activity {

	public static final String BASE_URL = "https://192.168.1.11:8443";
	
	public static String loggedInUsername = "";

	public static String token = "";

	EditText passwordEt;
	EditText usernameEt;
	Button loginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        passwordEt = (EditText)findViewById(R.id.password_edittext);
        usernameEt = (EditText)findViewById(R.id.username_edittext);
        loginBtn = (Button)findViewById(R.id.login_btn);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
    
    public void doLogin(View v) {
    	
    	Toast.makeText(LoginActivity.this, "Logging in...", Toast.LENGTH_SHORT).show();
    	
    	final String password = passwordEt.getText().toString();
    	final String username = usernameEt.getText().toString();
    	
    	final VideoSvcApi svc = VideoSvc.init(LoginActivity.BASE_URL, username, password);

		CallableTask.invoke(new Callable<Collection<Video>>() {

			@Override
			public Collection<Video> call() throws Exception {
				
				Collection<Video> vids = svc.getVideoList();
				return vids;
			}

		}, new TaskCallback<Collection<Video>>() {

			@Override
			public void success(Collection<Video> result) {
				// OAuth 2.0 grant was successful and web
				// can talk to the server, open up the video listing
				
				loggedInUsername = username;
				
				startActivity(new Intent(LoginActivity.this, VideoListActivity.class));
			}

			@Override
			public void error(Exception e) {
				Log.e(LoginActivity.class.getName(), "Error logging in via OAuth.", e);
				Toast.makeText(LoginActivity.this, "Login failed, check your Internet connection and credentials.", Toast.LENGTH_SHORT).show();
			}
		});
    	
    	
    	
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


}
