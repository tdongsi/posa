package vandy.mooc.model.mediator.webdata;

import java.security.cert.CertificateException;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.squareup.okhttp.OkHttpClient;

/**
 * This is an example of an HTTP client that does not properly validate SSL
 * certificates that are used for HTTPS. You should NEVER use a client like this
 * in a production application. Self-signed certificates are ususally only OK
 * for testing purposes, such as this use case.
 *
 * @author jules
 */
public class UnsafeHttpsClient
{
  public static OkHttpClient getUnsafeOkHttpClient()
  {
    try
    {
      // Create a trust manager that does not validate certificate chains
      final TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager()
      {

        @Override
        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType)
            throws CertificateException
        {
        }

        @Override
        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType)
            throws CertificateException
        {
        }

        @Override
        public java.security.cert.X509Certificate[] getAcceptedIssuers()
        {
          return null;
        }
      } };

      // Install the all-trusting trust manager
      final SSLContext sslContext = SSLContext.getInstance("SSL");
      sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
      // Create an ssl socket factory with our all-trusting manager
      final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

      OkHttpClient okHttpClient = new OkHttpClient();
      okHttpClient.setSslSocketFactory(sslSocketFactory);
      okHttpClient.setHostnameVerifier(new HostnameVerifier()
      {
        @Override
        public boolean verify(String hostname, SSLSession session)
        {
          return true;
        }
      });

      return okHttpClient;
    }
    catch (Exception e)
    {
      throw new RuntimeException(e);
    }
  }
}
