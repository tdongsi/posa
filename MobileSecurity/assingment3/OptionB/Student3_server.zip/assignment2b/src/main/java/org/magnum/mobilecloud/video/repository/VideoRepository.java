package org.magnum.mobilecloud.video.repository;

import org.springframework.data.jpa.repository.JpaRepository;


public interface VideoRepository extends JpaRepository<Video, Long> {



}
