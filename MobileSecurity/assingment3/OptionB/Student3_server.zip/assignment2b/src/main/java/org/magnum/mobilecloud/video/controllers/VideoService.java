package org.magnum.mobilecloud.video.controllers;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpEntity;
import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.repository.Like;
import org.magnum.mobilecloud.video.repository.Video;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Handles client video requests
 */
@Controller
public class VideoService {
	
	@Autowired
	private VideoRepository repository;
	
	private String getDataUrl(long videoId) {
		String url = getUrlBaseForLocalServer() + VideoSvcApi.VIDEO_SVC_PATH + "/" + videoId + "/data";
		
		return url;
	}
	
	private String getUrlBaseForLocalServer() {
		ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		
		HttpServletRequest request = servletRequestAttributes.getRequest();
		
		String base = 
				"http://"+request.getServerName()+((request.getServerPort() != 80) ? ":" + request.getServerPort() : "");
		return base;
	}	
	
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH, method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Collection<Video> getVideoList() {
		return repository.findAll();
	}
	
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Video getVideoById(@PathVariable("id") long id,
			HttpServletResponse response) {
		System.out.println("Requesting video " + id);
		Video video = repository.findOne(id);
		
		if (video == null) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		return video;
	}
	
	@PreAuthorize("#v.owner == p.name")	
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH, method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody Video addVideo(@RequestBody Video video,
			Principal p) {
		Video addedVideo = null;
		String user = p.getName();
		
		//Checks if video exists
		if(!repository.exists(video.getId())) {
			video.setLikes(0L);
			video.setOwner(user);
			addedVideo = repository.save(video);
			addedVideo.setUrl(getDataUrl(addedVideo.getId())); //test
		} else {
			//Saving new video
			addedVideo = repository.save(video);
		}		

		return addedVideo;
	}
	
	@PreAuthorize("isAuthenticated()")
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}/like", method = RequestMethod.POST)
	public @ResponseBody void likeVideo(@PathVariable("id") long id,
			Principal p,
			HttpServletResponse response) {
		Video locatedVideo = repository.findOne(id);
		
		if (locatedVideo == null) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return;
		}
		
		List<Like> likes = locatedVideo.getUserLikes();
		
		Like like = new Like();
		like.setUser(p.getName());
		
		if (likes.contains(like)) {
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return;
		} else {
			likes.add(like);
			repository.saveAndFlush(locatedVideo);
		}
		
		response.setStatus(HttpStatus.OK.value());
		return;
	}
	
	@PreAuthorize("isAuthenticated()")
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}/unlike", method = RequestMethod.POST)
	public @ResponseBody void unlikeVideo(@PathVariable("id") long id,
			Principal p,
			HttpServletResponse response) {
		Video locatedVideo = repository.findOne(id);
		
		if (locatedVideo == null) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return;
		}		
		
		Like like = new Like();
		like.setUser(p.getName());
		System.out.println("user=" + p.getName());
		
		List<Like> likes = locatedVideo.getUserLikes();
		
		if (!likes.contains(like)) {
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return;
		} else if (likes.contains(like)) {
			likes.remove(like);
			repository.saveAndFlush(locatedVideo);	
		}
		
		response.setStatus(HttpStatus.OK.value());
		return;
	}
	
	@PreAuthorize("isAuthenticated()")	
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}/likedby", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Collection<String> getUsersWhoLikedVideo(@PathVariable("id") long id,
			HttpServletResponse response) {
		Video foundVideo = repository.findOne(id);
		if(foundVideo == null) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;			
		}
		
		List<String> userLikes = new ArrayList<String>();
		
		for(Like like : foundVideo.getUserLikes()) {
			userLikes.add(like.getUser());
			System.out.println("userliked " + id + " " + like.getUser());
		}
		
		return userLikes;
	}	
}
