package org.magnum.mobilecloud.video;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.repository.Video;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.magnum.mobilecloud.video.client.VideoSvcApi;

import com.google.common.collect.Lists;

@Controller
public class VideoController {

	@Autowired
	private VideoRepository videos;
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}", method=RequestMethod.GET)
	public @ResponseBody Video getVideoById(@PathVariable("id") long id)
	{
		return videos.findOne(id);
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList()
	{
		return Lists.newArrayList(videos.findAll());
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video v, Principal user)
	{
		v.setOwner(user.getName());
		Collection<Video> videoCollection = videos.findByName(v.getName());
		if(videoCollection.size()>0){
			Video video = videoCollection.iterator().next();
			if(video != null && video.getOwner()==user.getName())
			{
				videos.delete(video);
				return videos.save(v);
			}
		}
		return videos.save(v);
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/like", method=RequestMethod.POST)
	public void likeVideo(@PathVariable("id") long id, HttpServletResponse response, Principal user) 
	{
		Video v = videos.findOne(id);
		if(v == null)
		{
			response.setStatus(404);
		}
		else if (v.getLikedBy().contains(user.getName()))
		{
			response.setStatus(400);
		}
		else
		{
			v.addLikedBy(user.getName());
			videos.save(v);
			response.setStatus(200);
		}
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/unlike", method=RequestMethod.POST)
	public void unlikeVideo(@PathVariable("id") long id, HttpServletResponse response, Principal user) 
	{
		Video v = videos.findOne(id);
		if(v == null)
		{
			response.setStatus(404);
		}
		else if (v.getLikedBy().contains(user.getName()))
		{
			v.removeLikedBy(user.getName());
			videos.save(v);
			response.setStatus(200);
		}
		else
		{
			response.setStatus(400);
		}
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/likedby", method=RequestMethod.GET)
	public @ResponseBody ArrayList<String> getLikedBy(@PathVariable("id") long id, HttpServletResponse response)
	{
		Video v = videos.findOne(id);
		if(v==null)
		{
			response.setStatus(404);
			return null;
		}
		else
		{
			response.setStatus(200);
			return v.getLikedBy();
		}
	}
	
}
