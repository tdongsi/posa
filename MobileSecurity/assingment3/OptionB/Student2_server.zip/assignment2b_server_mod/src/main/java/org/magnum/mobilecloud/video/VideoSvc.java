package org.magnum.mobilecloud.video;

import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.repository.Video;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;


@Controller
public class VideoSvc {

    // Store Video objects in the repository
    @Autowired
    private VideoRepository videos;

    // Implementation of POST /video
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.POST)
    public @ResponseBody Video addVideo(@RequestBody Video video,
                                        Principal p) {
        Video v = videos.findOne(video.getId());
        // Check if video already exists and belongs to the user
        if (v != null && p.getName().equals(v.getOwner())) {
            // Overwrite existing video
            v.setName(video.getName());
            v.setDuration(video.getDuration());
            v.setUrl(video.getUrl());
            v.setLikes(video.getLikes());
            v.setLikedByUsers(video.getUsersWhoLikedVideo());
            return videos.save(v);
        } else {
            video.setOwner(p.getName());
            return videos.save(video);}
    }

    // Implementation of GET /video
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.GET)
    public @ResponseBody Collection<Video> getVideoList() {
        Collection<Video> savedVideos = new ArrayList<Video>();
        for (Video v : videos.findAll()) {
            savedVideos.add(v);
        }
        return savedVideos;
    }

    // Implementation of GET /video/{id}
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}", method=RequestMethod.GET)
    public @ResponseBody Video getVideoById(@PathVariable("id") Long id,
                                            HttpServletResponse mResponse) throws IOException {
        Video v = videos.findOne(id);
        if (v != null) {
            // Return a video object to the client
            return v;
        } else {
            // Send 404 code if video with given id doesn't exist
            mResponse.setContentType("txt/html");
            mResponse.sendError(404, "Video with given id is not found.");
        }
        return null;
    }

    // Implementation of POST /video/{id}/like
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/like", method=RequestMethod.POST)
    public void likeVideo(@PathVariable("id") Long id,
                          HttpServletResponse mResponse,
                          Principal p) throws IOException {

        String user = p.getName(); // hardcoded user. Change to user from Principal

        Video v = videos.findOne(id);
        if (v != null) {
            // Check if video has been liked by the user
            if (v.containsLikedByUser(user)) {
                // Send to client 400 code - already liked/
                mResponse.setContentType("txt/html");
                mResponse.sendError(400, "You have already liked this video.");
            } else {
                // Send to the client 200 - OK code and add the
                // user to the list of users who have liked video.
                v.addLikedByUsers(user);
                v.setLikes(v.countLikedByUsers());
                videos.save(v);
                mResponse.setStatus(200);
            }
        } else {
            // Send 404 code if video with given id doesn't exist
            mResponse.setContentType("txt/html");
            mResponse.sendError(404, "Video with given id is not found.");
        }
    }

    // Implementation ov POST /video/{id}/unlike
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/unlike", method=RequestMethod.POST)
    public void unlikeVideo(@PathVariable("id") Long id,
                            HttpServletResponse mResponse,
                            Principal p) throws IOException {

        String user = p.getName(); // hardcoded user. Change to user from Principal

        Video v = videos.findOne(id);
        if (v != null) {
            // Check if video has been liked by the user
            if (!v.containsLikedByUser(user)) {
                // Send to client 400 code
                mResponse.setContentType("txt/html");
                mResponse.sendError(400, "You have not yet liked this video.");
            } else {
                // Send to the client 200 - OK code and the
                // user to the list of users who have liked video.
                v.removeLikedByUser(user);
                v.setLikes(v.countLikedByUsers());
                videos.save(v);
                mResponse.setStatus(200);
            }
        } else {
            // Send 404 code if video with given id doesn't exist
            mResponse.setContentType("txt/html");
            mResponse.sendError(404, "Video with given id is not found.");
        }
    }

    // Implementation of GET /video/{id}/likedby
    @RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/likedby", method=RequestMethod.GET)
    public @ResponseBody Collection<String> getLikesList(@PathVariable("id") Long id,
                                                   HttpServletResponse mResponse) throws IOException {
        Video v = videos.findOne(id);
        if (v != null) {
            // Check if video has been liked by the user
            return v.getUsersWhoLikedVideo();
        } else {
            // Send 404 code if video with given id doesn't exist
            mResponse.setContentType("txt/html");
            mResponse.sendError(404, "Video with given id is not found.");
        }
        return null;
    }

}
