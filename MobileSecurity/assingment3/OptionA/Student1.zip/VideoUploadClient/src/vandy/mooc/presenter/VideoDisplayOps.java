package vandy.mooc.presenter;

import java.io.File;
import java.lang.ref.WeakReference;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import vandy.mooc.common.ConfigurableOps;
import vandy.mooc.common.ContextView;
import vandy.mooc.common.GenericAsyncTask;
import vandy.mooc.common.GenericAsyncTaskOps;
import vandy.mooc.common.Utils;
import vandy.mooc.model.mediator.VideoDataMediator;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.model.services.DownloadVideoService;

public class VideoDisplayOps implements GenericAsyncTaskOps<Long, Void, Float>, ConfigurableOps<VideoDisplayOps.View> {

	private GenericAsyncTask<Long, Void, Float, VideoDisplayOps> mAsyncTask;

	VideoDataMediator mVideoMediator;

	private WeakReference<VideoDisplayOps.View> mVideoView;

	private Video mVideo;
	private Bitmap mThumbnail;

	private boolean mCallInProgress;

	public interface View extends ContextView {
		void updateRatingBar(float rating);

		Video getVideo();

		void initView(Video video, Bitmap bitmap);

	}

	@Override
	public Float doInBackground(Long... params) {
		float rating = mVideoMediator.setRating(params[0], params[1]);
		mVideoMediator.updateRating(mVideoView.get().getApplicationContext(), params[0], rating);
		return rating;
	}

	@Override
	public void onPostExecute(Float result) {
		Utils.showToast(mVideoView.get().getActivityContext(), "Rating Updated...");
		mVideoView.get().updateRatingBar(result);
	}

	@Override
	public void onConfiguration(VideoDisplayOps.View view, boolean firstTimeIn) {
		mVideoView = new WeakReference<>(view);

		if (firstTimeIn) {
			// Create VideoDataMediator that will mediate the
			// communication between Server and Android Storage.
			mVideoMediator = new VideoDataMediator();
			mVideo = view.getVideo();
			Log.d("myb", "get video:" + mVideo);
			getAllVideoInfo();
		}

		view.initView(mVideo, mThumbnail);
	}

	private void getAllVideoInfo() {
		mThumbnail = mVideoMediator.getPreview(mVideoView.get().getApplicationContext(), mVideo);
		mVideoMediator.updateVideoFromContentProvider(mVideoView.get().getApplicationContext(), mVideo);
	}

	public void setRating(float rating) {
		mAsyncTask = new GenericAsyncTask<>(this);
		mAsyncTask.execute(mVideo.getId(), (long) rating);
	}

	public VideoDisplayOps() {
	}

	public void downloadVideo() {
		if (mCallInProgress) {
			Utils.showToast(mVideoView.get().getApplicationContext(), "Call already in progress");
			return;
		}
		mCallInProgress = true;
		mVideoView.get().getApplicationContext()
				.startService(DownloadVideoService.makeIntent(mVideoView.get().getApplicationContext(), mVideo));
	}

	public void onDownloadEnd(Video video) {
		mCallInProgress = false;
		mVideo.setPath(video.getPath());
		if (!TextUtils.isEmpty(video.getPath())) {
			getAllVideoInfo();
			mVideoView.get().initView(mVideo, mThumbnail);
			Utils.showToast(mVideoView.get().getApplicationContext(), "Video Download Successed");
		} else
			Utils.showToast(mVideoView.get().getApplicationContext(), "Video Download Failed");

	}

	public void playVideo() {
		if (!TextUtils.isEmpty(mVideo.getPath())) {
			Intent intent = new Intent(Intent.ACTION_VIEW);
			intent.setDataAndType(Uri.fromFile(new File(mVideo.getPath())), mVideo.getContentType());
			mVideoView.get().getActivityContext().startActivity(intent);
		} else {
			Utils.showToast(mVideoView.get().getApplicationContext(), "Video does not exist.");
		}
	}

}
