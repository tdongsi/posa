package vandy.mooc.model.provider;

import java.io.File;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class VideoDatabaseHelper extends SQLiteOpenHelper {
	private static final String TABLE_NAME = "vandy_mooc_video_db";

	private static final int DATABASE_VERSION = 1;

	private static final String SQL_CREATE_VIDEO_TABLE = "CREATE TABLE "
			+ VideoContract.VideoEntry.TABLE_NAME + " ("
			+ VideoContract.VideoEntry._ID + " INTEGER PRIMARY KEY, "
			+ VideoContract.VideoEntry.COLUMN_TITLE + " TEXT NOT NULL, "
			+ VideoContract.VideoEntry.COLUMN_DURATION + " INTEGER NOT NULL, "
			+ VideoContract.VideoEntry.COLUMN_CONTENTTYPE + " TEXT NOT NULL, "
			+ VideoContract.VideoEntry.COLUMN_DATA_URL + " TEXT, "
			+ VideoContract.VideoEntry.COLUMN_PATH + " TEXT, "
			+ VideoContract.VideoEntry.COLUMN_STAR_RATING + " REAL " + ");";

	public VideoDatabaseHelper(Context context) {
		super(context, context.getCacheDir() + File.separator + TABLE_NAME,
				null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(SQL_CREATE_VIDEO_TABLE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// Delete the existing tables.
		db.execSQL("DROP TABLE IF EXISTS "
				+ VideoContract.VideoEntry.TABLE_NAME);
		// Create the new tables.
		onCreate(db);
	}
}
