package vandy.mooc.view;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.TextView;
import vandy.mooc.R;
import vandy.mooc.common.GenericActivity;
import vandy.mooc.common.Utils;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.model.services.DownloadVideoService;
import vandy.mooc.presenter.VideoDisplayOps;
import vandy.mooc.utils.VideoMediaStoreUtils;
import vandy.mooc.view.ui.FloatingActionButton;

public class VideoDisplayActivity extends GenericActivity<VideoDisplayOps.View, VideoDisplayOps>
		implements VideoDisplayOps.View {
	private TextView mTitle;
	private ImageView mPreview;
	private RatingBar mRatingBar;
	private FloatingActionButton mPlayVideoButton;
	private FloatingActionButton mDownloadButton;
	private BroadcastReceiver mDownloadResultReceiver;

	public static final String KEY_VIDEO_DATA = "video_data";

	public static final String ACTION_DISPLAY_VIDEO = "vandy.mooc.view.VideoDisplayActivity";
	public static String TAG = VideoDisplayActivity.class.getName();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.video_display_activity);
		mDownloadResultReceiver = new DownloadResultReceiver();
		mTitle = (TextView) findViewById(R.id.title);
		mPreview = (ImageView) findViewById(R.id.previewImage);
		mRatingBar = (RatingBar) findViewById(R.id.ratingBar);
		mPlayVideoButton = (FloatingActionButton) findViewById(R.id.fabButton);
		mDownloadButton = (FloatingActionButton) findViewById(R.id.fabButtonDownload);
		mRatingBar.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {

			@Override
			public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
				if (fromUser)
					getOps().setRating(rating);
			}
		});

		mPlayVideoButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				getOps().playVideo();
			}
		});
		mDownloadButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Utils.showToast(getApplicationContext(), "Downloading video");
				getOps().downloadVideo();
			}
		});

		super.onCreate(savedInstanceState, VideoDisplayOps.class, this);
	}

	public static Intent makeIntent(Video video) {
		return new Intent(ACTION_DISPLAY_VIDEO).putExtra(KEY_VIDEO_DATA, video);
	}

	@Override
	public void updateRatingBar(float rating) {
		mRatingBar.setRating(rating);
	}

	@Override
	public Video getVideo() {
		return getIntent().getParcelableExtra(KEY_VIDEO_DATA);
	}

	@Override
	public void initView(Video video, Bitmap bitmap) {
		mTitle.setText(video.getTitle());
		mRatingBar.setRating(video.getRating());
		if (bitmap != null) {
			mPreview.setImageBitmap(bitmap);
		}
		if (VideoMediaStoreUtils.videoDownloaded(video.getPath()))
			mDownloadButton.setVisibility(View.GONE);
		else
			mDownloadButton.setVisibility(View.VISIBLE);
	}

	@Override
	protected void onResume() {
		super.onResume();
		registerReceiver();
	}

	@Override
	protected void onPause() {
		super.onPause();
		LocalBroadcastManager.getInstance(this).unregisterReceiver(mDownloadResultReceiver);
	}

	private void registerReceiver() {

		// Create an Intent filter that handles Intents from the
		// UploadVideoService.
		IntentFilter intentFilter = new IntentFilter(DownloadVideoService.ACTION_DOWNLOAD_SERVICE_RESPONSE);
		intentFilter.addCategory(Intent.CATEGORY_DEFAULT);

		// Register the BroadcastReceiver.
		LocalBroadcastManager.getInstance(this).registerReceiver(mDownloadResultReceiver, intentFilter);
	}

	private class DownloadResultReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			Video video = intent.getParcelableExtra(KEY_VIDEO_DATA);
			Log.d("myb", "DownloadResultReceiver onReceive: " + video);
			getOps().onDownloadEnd(video);
		}
	}
}
