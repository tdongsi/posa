package vandy.mooc.model.provider;

import android.content.ContentUris;
import android.net.Uri;
import android.provider.BaseColumns;

public class VideoContract {
	public static final String AUTHORITY = "vandy.mooc.videoprovider";

	private static final Uri BASE_URI = Uri.parse("content://" + AUTHORITY);

	public static final String VIDEO_PATH = VideoEntry.TABLE_NAME;

	public static final class VideoEntry implements BaseColumns {
		public static final Uri CONTENT_URI = BASE_URI.buildUpon()
				.appendPath(VIDEO_PATH).build();

		public static final String CONTENT_ITEMS_TYPE = "vnd.android.cursor.dir/"
				+ AUTHORITY + "/" + VIDEO_PATH;

		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/"
				+ AUTHORITY + "/" + VIDEO_PATH;

		public static final String TABLE_NAME = "video_table";

		public static final String COLUMN_TITLE = "title";
		public static final String COLUMN_DURATION = "duration";
		public static final String COLUMN_CONTENTTYPE = "contentType";
		public static final String COLUMN_DATA_URL = "data_url";
		public static final String COLUMN_PATH = "path";
		public static final String COLUMN_STAR_RATING = "star_rating";
		public static final String COLUMN_EXPIRATION_TIME = "expiration_time";

		public static Uri buildUri(long id) {
			return ContentUris.withAppendedId(CONTENT_URI, id);
		}
	}
}
