package vandy.mooc.model.mediator.webdata;

import org.magnum.videoup.client.oauth.SecuredRestBuilder;
import org.magnum.videoup.client.unsafe.EasyHttpClient;

import retrofit.RestAdapter.LogLevel;
import retrofit.client.ApacheClient;
import vandy.mooc.view.LoginScreenActivity;
import android.content.Context;
import android.content.Intent;


/**
 * This interface defines an API for a Video Service web service. The interface
 * is used to provide a contract for client/server interactions. The interface
 * is annotated with Retrofit annotations to send Requests and automatically
 * convert the Video.
 */
public class VideoService {

	public static final String CLIENT_ID = "mobile";

	private static VideoServiceProxy videoSvc_;

	public static synchronized VideoServiceProxy getOrShowLogin(Context ctx) {
		if (videoSvc_ != null) {
			return videoSvc_;
		} else {
			Intent i = new Intent(ctx, LoginScreenActivity.class);
			ctx.startActivity(i);
			return null;
		}
	}

	public static synchronized VideoServiceProxy init(String server, String user, String pass) {

		videoSvc_ = new SecuredRestBuilder()
				.setLoginEndpoint(server + VideoServiceProxy.TOKEN_PATH)
				.setUsername(user)
				.setPassword(pass)
				.setClientId(CLIENT_ID)
				.setClient(
						new ApacheClient(new EasyHttpClient()))
				.setEndpoint(server).setLogLevel(LogLevel.FULL).build()
				.create(VideoServiceProxy.class);

		return videoSvc_;
	}
}
