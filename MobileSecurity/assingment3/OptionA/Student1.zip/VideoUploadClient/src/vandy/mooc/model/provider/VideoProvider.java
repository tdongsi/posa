package vandy.mooc.model.provider;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.text.TextUtils;

public class VideoProvider extends ContentProvider {
	private VideoDatabaseHelper mDatabaseHelper;

	private static final int VIDEOS = 100;
	private static final int VIDEO = 101;

	private static final UriMatcher mUriMatcher = buildUriMatcher();

	private static UriMatcher buildUriMatcher() {
		UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		uriMatcher.addURI(VideoContract.AUTHORITY, VideoContract.VIDEO_PATH,
				VIDEOS);
		uriMatcher.addURI(VideoContract.AUTHORITY, VideoContract.VIDEO_PATH
				+ "/#", VIDEO);
		return uriMatcher;
	}

	@Override
	public boolean onCreate() {
		mDatabaseHelper = new VideoDatabaseHelper(getContext());
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		Cursor cursor;
		switch (mUriMatcher.match(uri)) {
		case VIDEO:
			cursor = mDatabaseHelper.getReadableDatabase().query(
					VideoContract.VideoEntry.TABLE_NAME,
					projection,
					addKeyIdCheckToWhereStatement(selection,
							ContentUris.parseId(uri)), selectionArgs, null,
					null, sortOrder);
			break;
		case VIDEOS:
			cursor = mDatabaseHelper.getReadableDatabase().query(
					VideoContract.VideoEntry.TABLE_NAME, projection, selection,
					selectionArgs, null, null, sortOrder);
			break;
		default:
			throw new UnsupportedOperationException("Unknown uri: " + uri);
		}
		cursor.setNotificationUri(getContext().getContentResolver(), uri);
		return cursor;
	}

	@Override
	public String getType(Uri uri) {
		switch (mUriMatcher.match(uri)) {
		case VIDEO:
			return VideoContract.VideoEntry.CONTENT_ITEM_TYPE;
		case VIDEOS:
			return VideoContract.VideoEntry.CONTENT_ITEMS_TYPE;
		default:
			throw new IllegalArgumentException("Unknown URI " + uri);
		}
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		long rowId = mDatabaseHelper.getWritableDatabase()
				.insertWithOnConflict(VideoContract.VideoEntry.TABLE_NAME,
						null, values, SQLiteDatabase.CONFLICT_REPLACE);
		if (rowId > 0) {
			Uri newUri = ContentUris.withAppendedId(uri, rowId);
			getContext().getContentResolver().notifyChange(newUri, null);
			return newUri;
		} else
			throw new SQLException("Fail to add a new record into " + uri);

	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		int rowsDeleted;
		switch (mUriMatcher.match(uri)) {
		case VIDEO:
			rowsDeleted = mDatabaseHelper.getWritableDatabase().delete(
					VideoContract.VideoEntry.TABLE_NAME,
					addKeyIdCheckToWhereStatement(selection,
							ContentUris.parseId(uri)), selectionArgs);
			break;
		case VIDEOS:
			rowsDeleted = mDatabaseHelper.getWritableDatabase().delete(
					VideoContract.VideoEntry.TABLE_NAME, selection,
					selectionArgs);
			break;
		default:
			throw new IllegalArgumentException("Unknown URI " + uri);
		}
		getContext().getContentResolver().notifyChange(null, null);
		return rowsDeleted;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		int rowsUpdated;
		switch (mUriMatcher.match(uri)) {
		case VIDEO:
			rowsUpdated = mDatabaseHelper.getWritableDatabase().update(
					VideoContract.VideoEntry.TABLE_NAME,
					values,
					addKeyIdCheckToWhereStatement(selection,
							ContentUris.parseId(uri)), selectionArgs);
			break;
		case VIDEOS:
			rowsUpdated = mDatabaseHelper.getWritableDatabase().update(
					VideoContract.VideoEntry.TABLE_NAME, values, selection,
					selectionArgs);
			break;
		default:
			throw new IllegalArgumentException("Unknown URI " + uri);

		}
		getContext().getContentResolver().notifyChange(uri, null);
		return rowsUpdated;
	}

	/**
	 * Helper method that appends a given key id to the end of the WHERE
	 * statement parameter.
	 */
	private static String addKeyIdCheckToWhereStatement(String whereStatement,
			long id) {
		String newWhereStatement;
		if (TextUtils.isEmpty(whereStatement))
			newWhereStatement = "";
		else
			newWhereStatement = whereStatement + " AND ";

		// Append the key id to the end of the WHERE statement.
		return newWhereStatement + VideoContract.VideoEntry._ID + " = '" + id
				+ "'";
	}
}
