package org.magnum.mobilecloud.video.model;

import java.util.Collection;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserVideoRatingRepository extends CrudRepository<UserVideoRating, Long> {

	// Find all videos with a matching title (e.g., Video.name)
	public Collection<UserVideoRating> findByVideoId(long videoId);

	@Query("SELECT new org.magnum.mobilecloud.video.model.AverageVideoRating("
			+ "AVG(rating) as rating, " + "MAX(videoId) as videoId, "
			+ "COUNT(rating) as totalRatings) " + "from UserVideoRating "
			+ "where videoId=:videoId")
	AverageVideoRating findAverageVideoRatingByVideoId(@Param("videoId") long videoId);
	
	
	   // Find rating for a given user and video
    public UserVideoRating findByVideoIdAndUser(long videoId, String user);
    
}
