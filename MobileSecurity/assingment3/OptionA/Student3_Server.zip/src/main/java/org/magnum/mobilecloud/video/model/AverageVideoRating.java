package org.magnum.mobilecloud.video.model;

public class AverageVideoRating {

	private final double rating;

	private final long videoId;

	private final long totalRatings;

	public AverageVideoRating(double rating, long videoId, long totalRatings) {
		super();
		this.rating = rating;
		this.videoId = videoId;
		this.totalRatings = totalRatings;
	}
	// average of ratings over all users of a specific video
	public double getRating() {
		return rating;
	}

	public long getVideoId() {
		return videoId;
	}
	// the count of users that rated a specific video
	public long getTotalRatings() {
		return totalRatings;
	}

}
