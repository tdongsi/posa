package org.magnum.mobilecloud.video.client;

import java.io.IOException;
import java.security.Principal;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.controller.VideoFileManager;
import org.magnum.mobilecloud.video.model.AverageVideoRating;
import org.magnum.mobilecloud.video.model.UserVideoRating;
import org.magnum.mobilecloud.video.model.UserVideoRatingRepository;
import org.magnum.mobilecloud.video.model.Video;
import org.magnum.mobilecloud.video.model.VideoRepository;
import org.magnum.mobilecloud.video.model.VideoStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;

@Controller
public class VideoSvc {
	
	@Autowired
	private VideoRepository videos;

	@Autowired
	private UserVideoRatingRepository ratings;

	Principal currentUser = null;
	
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH, method = RequestMethod.GET)
	public @ResponseBody
	Collection<Video> getVideoList() {
		return Lists.newArrayList(videos.findAll());
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}", method = RequestMethod.GET)
	@ResponseBody
	Video getVideoById(@PathVariable("id") long id) {
		return videos.findOne(id);
	}

	@PreAuthorize("hasRole(user)")
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH, method = RequestMethod.POST)
	public @ResponseBody
	Video addVideo(@RequestBody Video v, Principal user) {
		currentUser = user;
		return videos.save(v);
	}

	@PreAuthorize("hasRole(user)")
	@RequestMapping(value = VideoSvcApi.VIDEO_DATA_PATH, method = RequestMethod.POST)
	public @ResponseBody
	VideoStatus setVideoData(@PathVariable(VideoSvcApi.ID_PARAMETER) long id,
			@RequestParam(VideoSvcApi.DATA_PARAMETER) MultipartFile videoData,
			HttpServletResponse resp, Principal user) throws IOException {

		Video v = videos.findOne(id);
		if (user != currentUser) {
			resp.sendError(404, "Wrong User");
			throw new IOException();
		}
		if (null == v) {
			resp.sendError(404, "Video not found");
			return new VideoStatus(VideoStatus.VideoState.PROCESSING);
		} else {
			VideoFileManager.get().saveVideoData(v, videoData.getInputStream());
			return new VideoStatus(VideoStatus.VideoState.READY);
		}
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_DATA_PATH, method = RequestMethod.GET)
	public @ResponseBody
	void getVideoData(@PathVariable(VideoSvcApi.ID_PARAMETER) long id,
			HttpServletResponse resp) throws IOException {

		Video v = videos.findOne(id);
		if (null == v) {
			resp.sendError(404, "Video not found");
		} else {
			if (VideoFileManager.get().hasVideoData(v)) {
				resp.setContentType(v.getContentType());
				VideoFileManager.get().copyVideoData(v, resp.getOutputStream());
				resp.setStatus(200);
			}
		}
	}

	@PreAuthorize("hasRole(user)")
	@RequestMapping(value = VideoSvcApi.VIDEO_RATING_POST_PATH, method = RequestMethod.POST)
	public @ResponseBody
	AverageVideoRating rateVideo(
			@PathVariable(VideoSvcApi.ID_PARAMETER) long videoId,
			@PathVariable(VideoSvcApi.RATING_PARAMETER) long rating,
			Principal user) throws IOException {

		UserVideoRating extingRate = ratings.findByVideoIdAndUser(videoId, user.getName());

		if (extingRate == null) {
			UserVideoRating newRate = new UserVideoRating(videoId, rating, user.getName());
			ratings.save(newRate);
		} else {
			extingRate.setRating(rating);
			ratings.save(extingRate);
		}
		return ratings.findAverageVideoRatingByVideoId(videoId);
	}

	@PreAuthorize("hasRole(user)")
	@RequestMapping(value = VideoSvcApi.VIDEO_RATING_GET_PATH, method = RequestMethod.GET)
	public @ResponseBody
	AverageVideoRating getVideoRating(@PathVariable("id") long id) {
		return ratings.findAverageVideoRatingByVideoId(id);
	}
}
