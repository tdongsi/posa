package vandy.mooc.presenter;

import java.math.BigDecimal;

import vandy.mooc.common.GenericAsyncTask;
import vandy.mooc.common.GenericAsyncTaskOps;
import vandy.mooc.model.mediator.VideoDataMediator;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.provider.VideoContract;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.widget.Toast;


public class RatingBarOps extends Activity
	   implements GenericAsyncTaskOps<Object, Void, Float> {

	Context context;

	public RatingBarOps(Context applicationContext) {
		// TODO Auto-generated constructor stub
		super();
		context = applicationContext;
	    
	    mVideoMediator =
	            new VideoDataMediator(context);
	}
    /**
     * VideoDataMediator mediates the communication between Video
     * Service and local storage in the Android device.
     */
    private VideoDataMediator mVideoMediator;

	/**
	 * The GenericAsyncTask used to expand an Video in a background thread via
	 * the Video web service.
	 */
	private GenericAsyncTask<Object, Void, Float, RatingBarOps> mAsyncTask;

	public void addRating(long id, float rating, String videoTitle) {
		mAsyncTask = new GenericAsyncTask<>(this);
		mAsyncTask.execute(id, rating, videoTitle); // calls doInBackground below
	}

	@Override
	public Float doInBackground(Object... params) {
		long id = (Long) params[0];
		float rating = (Float) params[1];
		String videoTitle = (String) params[2];
		Video video = new Video();
		video = mVideoMediator.addVideo(id, rating);
		float averageRating = (float) video.getRating();
		averageRating = round(averageRating, 2);
		// Save average rating to Content Provider
		updateRatingInContentProvider(id, averageRating, videoTitle);
		return averageRating;
	}

	private void updateRatingInContentProvider(long id, float rating, String videoTitle) {
		final ContentValues cvs = new ContentValues();

	    String selection = VideoContract.VideoEntry.COLUMN_TITLE + " = ?";
	    String[] selectionArgs = { videoTitle };

	    cvs.put(VideoContract.VideoEntry.COLUMN_RATING_AVERAGE, rating);

	    
	    // Enter the Video meta-data into the VideoEntry table.
	    context.getContentResolver().update(VideoContract.VideoEntry.CONTENT_URI, cvs, selection, selectionArgs);
	
	}
	
    public static float round(float d, int decimalPlace) {
        return BigDecimal.valueOf(d).setScale(decimalPlace,BigDecimal.ROUND_HALF_UP).floatValue();
   } 


	@Override
	public void onPostExecute(Float result) {
		// TODO Auto-generated method stub
//		if (result != 0) {
//			Toast.makeText(context, "Video Data SAVED to Content Provider", Toast.LENGTH_SHORT).show();
//		} else {
//			Toast.makeText(context, "Video Data NOT Saved to Content Provider", Toast.LENGTH_SHORT).show();
//		}
		Toast.makeText(context, "Average: " + result, Toast.LENGTH_SHORT).show();
	}

}
