package vandy.mooc.view;

import java.io.File;

import vandy.mooc.R;
import vandy.mooc.common.GenericActivity;
import vandy.mooc.presenter.RatingBarOps;
import vandy.mooc.presenter.VideoOps;
import vandy.mooc.view.ui.VideoAdapter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.VideoView;


public class VideoPlayActivity 
       extends GenericActivity<VideoOps.View, VideoOps>
       implements VideoOps.View, OnRatingBarChangeListener {

    Button buttonDownload;
	Button buttonPlay;
	VideoView videoView;
	
	boolean isVideoOnDevice;
	String videoTitle;
	long videoId;
	RatingBar ratingBar;
	

		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.video_play_activity);
		
		buttonPlay = (Button) findViewById(R.id.playButton);
		buttonDownload = (Button) findViewById(R.id.downloadButton);
		videoView = (VideoView) findViewById(R.id.video_view);
		ratingBar = (RatingBar) findViewById(R.id.star_rating_dialog_rating_bar);
		ratingBar.setOnRatingBarChangeListener(this);
		
		Bundle b = this.getIntent().getExtras();
	    videoTitle = b.getString("videoTitle");
	    videoId = b.getLong("videoId");
		
		wireUpButtons();
		CheckForVideoOnDevice();

		super.onCreate(savedInstanceState, VideoOps.class, this);
       		
	}

	
	@Override
	public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

		Log.i("VideoPlayActivity", "Rating: " + rating );
		RatingBarOps rbo = new RatingBarOps(getApplicationContext());
		rbo.addRating(videoId, rating, videoTitle);
	}
	
	private void CheckForVideoOnDevice() {
	
		 isVideoOnDevice = isVideoOnDevice(videoTitle);
		
		// If Video is on Device
		if(isVideoOnDevice){
			Log.v("VideoPlayActivity","Video IS on the device");			
		}else{
		  // If Video is not on Device
	        Log.v("VideoPlayActivity","Video is NOT on the device");			
		}				
	}

	private boolean isVideoOnDevice(String videoTitle) {
		Log.v("VideoPlayActivity","String videoTitle: " + videoTitle.toString());
		Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
		String[] columns = {
		        MediaStore.Video.VideoColumns.DISPLAY_NAME
		    }; 
		 
		String selection = MediaStore.Video.VideoColumns.DISPLAY_NAME + "=?";
		String[] selectionArgs = { videoTitle };
		 		
		try (Cursor cursor = getApplicationContext().getContentResolver().query(
				uri, columns, selection,
				selectionArgs, null)) {
        
		// If there are not matches in the database return false.
		if (!cursor.moveToFirst()){
            Log.i("VideoPlayActivity", "cursor.moveToFirst() NO MATCH " + cursor.moveToFirst());
			return false;
			} 
		else {
			//cursor.getColumnName(0);
			Log.i("VideoPlayActivity","cursor.moveToFirst() MATCH FOUND");
			Log.i("VideoPlayActivity", "Cursor Count: " + cursor.getString(0));
			return true;
		}
		}
        
	}
	
	private void setVideoFromAndroidMediaStorePath(String videoTitle) {
		
		File file = getVideoStorageDir(videoTitle);
		String newPath = "file://" + file.toString();	
		videoView.setVideoPath(newPath);
		Log.i("VideoListActivity: ", "  newPath: "    + newPath.toString());
	}
	
	private void wireUpButtons() {
		buttonPlay.setOnClickListener(new View.OnClickListener() {
	        @Override 
	        public void onClick(View view) {
				Log.i("VideoListActivity: ", " Clicked Play Button");
				setVideoFromAndroidMediaStorePath(videoTitle);
	        	videoView.start();
	        } 
	    });
		
		buttonDownload.setOnClickListener(new View.OnClickListener() {
	        @Override 
	        public void onClick(View view) {
				Log.i("VideoListActivity: ", " Clicked Download Button");

	        	// Start Download Service
	        	getOps().downloadVideo(videoId, videoTitle);
	        } 	 
	    });		
	}
	
	private static File getVideoStorageDir(String videoName) {
        //Check to see if external SDCard is mounted or not.
        if (isExternalStorageWritable()) {
            // Create a path where we will place our video in the
            // user's public Downloads directory. Note that you should be
            // careful about what you place here, since the user often 
            // manages these files.
            final File path =
                   Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);

            final File file = new File(path, videoName);

            // Make sure the Downloads directory exists.
       path.mkdirs();
            return file;
        } else {
            return null;
        }
    }
	
    private static boolean isExternalStorageWritable() {
        return Environment.MEDIA_MOUNTED.equals
            (Environment.getExternalStorageState());
    }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.video_play, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void setAdapter(VideoAdapter videoAdapter) {
		
	}
}


