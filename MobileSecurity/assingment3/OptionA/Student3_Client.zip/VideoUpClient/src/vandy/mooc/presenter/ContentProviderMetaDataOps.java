package vandy.mooc.presenter;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import vandy.mooc.common.GenericAsyncTask;
import vandy.mooc.common.GenericAsyncTaskOps;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.provider.VideoContract;
import vandy.mooc.provider.VideoContract.VideoEntry;
import vandy.mooc.utils.VideoMediaStoreUtils;


public class ContentProviderMetaDataOps extends Activity
	   implements GenericAsyncTaskOps<Uri, Void, Boolean> {

	Context context;

	public ContentProviderMetaDataOps(Context applicationContext) {
		// TODO Auto-generated constructor stub
		super();
		context = applicationContext;
	}

	/**
	 * The GenericAsyncTask used to expand an Video in a background thread via
	 * the Video web service.
	 */
	private GenericAsyncTask<Uri, Void, Boolean, ContentProviderMetaDataOps> mAsyncTask;

	public void downloadMetaDatatoContentProvider(Uri videoUri) {
		mAsyncTask = new GenericAsyncTask<>(this);
		mAsyncTask.execute(videoUri); // calls doInBackground below
	}

	@Override
	public Boolean doInBackground(Uri... params) {
		Uri videoUri = params[0];
	       // Get the path of video file from videoUri.
        String filePath = VideoMediaStoreUtils.getPath(context,
                                         videoUri);

        // Get the Video from Android Video Content Provider having
        // the given filePath.
        Video androidVideo = VideoMediaStoreUtils.getVideo(context, filePath);
        
		ContentValues cvs = new ContentValues();
		cvs.put(VideoContract.VideoEntry.COLUMN_ID, androidVideo.getId());
		cvs.put(VideoContract.VideoEntry.COLUMN_DATA_URL, androidVideo.getDataUrl());
		cvs.put(VideoContract.VideoEntry.COLUMN_TITLE, androidVideo.getTitle());
		cvs.put(VideoContract.VideoEntry.COLUMN_DURATION, androidVideo.getDuration());
		cvs.put(VideoContract.VideoEntry.COLUMN_CONTENT_TYPE, androidVideo.getContentType());
		cvs.put(VideoContract.VideoEntry.COLUMN_RATING_AVERAGE, androidVideo.getRating());
		context.getContentResolver().insert(VideoEntry.CONTENT_URI, cvs);

		return true;
	}

	@Override
	public void onPostExecute(Boolean result) {
		// TODO Auto-generated method stub
		if (result) {
			Toast.makeText(context, "Video Data SAVED to Content Provider", Toast.LENGTH_SHORT).show();
		} else {
			Toast.makeText(context, "Video Data NOT Saved to Content Provider", Toast.LENGTH_SHORT).show();
		}

	}

}
