package vandy.mooc.utils;

import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.provider.VideoContract;
import vandy.mooc.provider.VideoContract.VideoEntry;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class VideoQueryUtils {

	private static String columnsToQuery[] = 
			new String[] {
		VideoContract.VideoEntry._ID,
		VideoContract.VideoEntry.COLUMN_TITLE,
		VideoContract.VideoEntry.COLUMN_CONTENT_TYPE,
		VideoContract.VideoEntry.COLUMN_DATA_URL,
		VideoContract.VideoEntry.COLUMN_STAR_RATING,
		VideoContract.VideoEntry.COLUMN_TOTAL_RATING
	};

	private static String selectionById = 
			VideoContract.VideoEntry._ID
			+ "= ?";

	// @SuppressLint("NewApi")
	public static Video getById(Context context, long id) {
		try (Cursor cursor = context.getContentResolver().query(
				VideoContract.VideoEntry.CONTENT_URI, columnsToQuery, 
				selectionById, new String[] { String.valueOf(id) }, null)) {
			if (!cursor.moveToFirst()) {
				// no video was found
				return null;

			} else {
				String title = cursor.getString(cursor.getColumnIndex(VideoEntry.COLUMN_TITLE));
				String contentType = cursor.getString(cursor.getColumnIndex(VideoEntry.COLUMN_CONTENT_TYPE));
				String dataUrl = cursor.getString(cursor.getColumnIndex(VideoEntry.COLUMN_DATA_URL));
				float rating = cursor.getFloat(cursor
						.getColumnIndex(VideoEntry.COLUMN_STAR_RATING));
				int totalRatings = cursor.getInt(cursor
						.getColumnIndex(VideoEntry.COLUMN_TOTAL_RATING));

				Video video = new Video();
				video.setTitle(title);
				video.setContentType(contentType);
				video.setDataUrl(dataUrl);
				video.setRating(rating);
				video.setTotalRatings(totalRatings);
				return video;
			}

		}
	}

	public VideoQueryUtils() {
		throw new AssertionError();
	}

	public static int updateOne(Context context, Video video) {
		long id = video.getId();
		ContentValues cv = new ContentValues();
		cv.put(VideoContract.VideoEntry.COLUMN_TITLE, video.getTitle());
		cv.put(VideoContract.VideoEntry.COLUMN_CONTENT_TYPE, video.getContentType());
		cv.put(VideoContract.VideoEntry.COLUMN_DATA_URL, video.getDataUrl());
		cv.put(VideoContract.VideoEntry.COLUMN_STAR_RATING, video.getRating());
		cv.put(VideoContract.VideoEntry.COLUMN_TOTAL_RATING,
				video.getTotalRatings());
		return context.getContentResolver().update(VideoEntry.CONTENT_URI, 
				cv, selectionById, new String[] { String.valueOf(id) });
	}
}
