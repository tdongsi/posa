package vandy.mooc.view;

import vandy.mooc.R;
import vandy.mooc.common.GenericActivity;
import vandy.mooc.common.Utils;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.presenter.SingleOps;
import vandy.mooc.presenter.SingleOps.VideoLayout;
import vandy.mooc.utils.Constants;
import vandy.mooc.view.ui.FloatingActionButton;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.TextView;
import android.widget.VideoView;

public class VideoPlayerActivity extends GenericActivity<SingleOps.View, SingleOps> implements SingleOps.View {

	private long videoId;
	private RatingBar ratingBar;
	private FloatingActionButton downloadButton;
	private FloatingActionButton playButton;
	private TextView titleView;
	private VideoView videoView;
	private float lastRating;
	private Video mVideo;

	private static final String RATING_RANGE = "Rating should be from 1 to 5";

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		setContentView(R.layout.activity_video_player);

		Bundle extras = getIntent().getExtras();

		videoId = extras.getLong(Constants.VIDEO_ID);

		downloadButton = (FloatingActionButton) findViewById(R.id.downloadButton);
		playButton = (FloatingActionButton) findViewById(R.id.playButton);
		titleView = (TextView) findViewById(R.id.videoTitle);
		ratingBar = (RatingBar) findViewById(R.id.ratingBar1);
		videoView = (VideoView) findViewById(R.id.videoView1);

		ratingBar.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {

			@Override
			public void onRatingChanged(RatingBar ratingBar, float rating,
					boolean fromUser) {
				if (fromUser) {
					if (rating >= 1 && rating <= 5) {
						lastRating = rating;
						SingleOps.VideoInfo info = getOps().new VideoInfo(
								getVideoId(), (int) rating);
						getOps().setRating(info);
					} else {
						Utils.showToast(getApplicationContext(), RATING_RANGE);
						ratingBar.setRating(lastRating);
					}
				} else {
					lastRating = rating;
				}

			}
		});

		downloadButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {				
				// TODO Auto-generated method stub
				getOps().downloadVideo();
			};
		});

		super.onCreate(savedInstanceState, SingleOps.class, this);

		//		getOps().getVideoInfo(videoId);
	}

	@Override
	public long getVideoId() {
		// TODO Auto-generated method stub
		return videoId;
	}

	@Override
	public VideoLayout getVideoLayout() {
		// TODO Auto-generated method stub
		return getOps().new VideoLayout(downloadButton, playButton, titleView, ratingBar, videoView);
	}


	@Override
	public void setVideo(Video video) {
		mVideo = video;
	}

	@Override
	public Video getVideo() {
		return mVideo;
	}

	@Override
	public void setVideoPlay() {
		playButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(android.view.View v) {
				videoView.start();
			}

		});
	}

}
