package vandy.mooc.presenter;

import java.io.File;
import java.lang.ref.WeakReference;

import retrofit.client.Response;
import vandy.mooc.common.ConfigurableOps;
import vandy.mooc.common.ContextView;
import vandy.mooc.common.GenericAsyncTask;
import vandy.mooc.common.GenericAsyncTaskOps;
import vandy.mooc.common.Utils;
import vandy.mooc.model.mediator.VideoDataMediator;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.utils.VideoQueryUtils;
import vandy.mooc.utils.VideoStorageUtils;
import vandy.mooc.view.ui.FloatingActionButton;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.VideoView;

/**
 * Provides all the Video-related operations.  It implements
 * ConfigurableOps so it can be created/managed by the GenericActivity
 * framework.  It extends GenericAsyncTaskOps so its doInBackground()
 * method runs in a background task.  It plays the role of the
 * "Abstraction" in Bridge pattern and the role of the "Presenter" in
 * the Model-View-Presenter pattern.
 */
public class SingleOps
implements GenericAsyncTaskOps<SingleOps.VideoInfo, Void, Video>,
ConfigurableOps<SingleOps.View> {
	/**
	 * Debugging tag used by the Android logger.
	 */
	private static final String TAG =
			SingleOps.class.getSimpleName();

	/**
	 * This interface defines the minimum interface needed by the
	 * RatingOps class in the "Presenter" layer to interact with the
	 * VideoListActivity in the "View" layer.
	 */
	public interface View extends ContextView {
		/**
		 * Finishes the Activity the RatingOps is
		 * associated with.
		 */
		void finish();

		/**
		 * Gets the current video ID
		 */
		long getVideoId();

		/**
		 * Gets the rating bar
		 * @return
		 */
		VideoLayout getVideoLayout();

		Video getVideo();

		void setVideo(Video video);

		void setVideoPlay();
	}

	/**
	 * Used to enable garbage collection.
	 */
	private WeakReference<SingleOps.View> mVideoView;

	/**
	 * The GenericAsyncTask used to expand an Video in a background
	 * thread via the Video web service.
	 */
	private GenericAsyncTask<VideoInfo,
	Void,
	Video,
	SingleOps> mAsyncTask;

	/**
	 * VideoDataMediator mediates the communication between Video
	 * Service and local storage on the Android device.
	 */
	VideoDataMediator mVideoMediator;

	/**
	 * The layout views that are needed to update the video information
	 */
	private VideoLayout mVideoLayout;

	/**
	 * Default constructor that's needed by the GenericActivity
	 * framework.
	 */
	public SingleOps() {
	}

	/**
	 * Gets the VideoList from Server by executing the AsyncTask to
	 * expand the acronym without blocking the caller.
	 */
	public void setRating(VideoInfo info){
		mAsyncTask = new GenericAsyncTask<>(this);
		mAsyncTask.execute(info);
	}

	@Override
	public Video doInBackground(VideoInfo... params) {
		return mVideoMediator.getUpdatedVideo(params[0].id, params[0].rating);
	}

	/**
	 * Display the results in the UI Thread.
	 */
	@Override
	public void onPostExecute(Video video) {
		displayRating(video);
	}

	/**
	 * Update the star rating
	 * 
	 * @param video
	 */
	public void displayRating(Video video) {
		if (video != null) {
			mVideoLayout.ratingBar.setRating(video.getRating());
			Log.d(TAG, "rating from video " + video.getRating()
					+ " set to rating bar");
			int result = VideoQueryUtils.updateOne(mVideoView.get().getApplicationContext(), video);

			if (result > 0) {
				Log.d(TAG, "Video rating: " + video.getRating());
				Utils.showToast(mVideoView.get().getActivityContext(),
						"Rating updated");
			} else {
				Log.d(TAG, "Error uploading video");
			}

		} else {
			Utils.showToast(mVideoView.get().getActivityContext(),
					"Please connect to the Video Service");

			// Close down the Activity.
			mVideoView.get().finish();
		}
	}

	@Override
	public void onConfiguration(View view, boolean firstTimeIn) {
		final String time =
				firstTimeIn 
				? "first time" 
						: "second+ time";

		Log.d(TAG,
				"onConfiguration() called the "
						+ time
						+ " with view = "
						+ view);

		// (Re)set the mVideoView WeakReference.
		mVideoView =
				new WeakReference<>(view);

		if (firstTimeIn) {
			// Create VideoDataMediator that will mediate the
			// communication between Server and Android Storage.
			mVideoMediator = new VideoDataMediator(mVideoView.get()
					.getApplicationContext());

			mVideoLayout = mVideoView.get().getVideoLayout();

			// Get the VideoInformation from content provider. 
			getVideoInfo(mVideoView.get().getVideoId());
		}
	}

	public void getVideoInfo(long id) {
		Log.d(TAG, "Entering getVideoInfo...");
		Video v = VideoQueryUtils.getById(mVideoView.get().getApplicationContext(), id);
		if (v != null) {
			mVideoView.get().setVideo(v);
			mVideoLayout.titleText.setText(v.getTitle());
			mVideoLayout.ratingBar.setRating(v.getRating());

			if (VideoStorageUtils.fileExists(mVideoView.get().getVideo().getTitle())) {
				mVideoLayout.downloadButton.setVisibility(Button.INVISIBLE);
				mVideoLayout.videoView.setVideoPath(VideoStorageUtils.getPath(mVideoView.get().getVideo().getTitle()));
				mVideoView.get().setVideoPlay();
			}

		} else {
			Utils.showToast(mVideoView.get().getActivityContext(), "Video not found");
			Log.d(TAG, "NO video found: ID " + id);
			mVideoView.get().finish();
		}
	}

	public void downloadVideo() {
		final long id = mVideoView.get().getVideoId();
		Log.d(TAG, "Video to download ID: " + id);

		new AsyncTask<Video, Void, File>() {

			@Override
			protected File doInBackground(Video... params) {
				Response response = mVideoMediator.downloadVideo(id);
				if (response != null) {
					Log.d(TAG, "downloading video...");
					File downloadedVideo = VideoStorageUtils.storeVideoInExternalDirectory(mVideoView.get().getApplicationContext(), 
							response, mVideoView.get().getVideo().getTitle());

					return downloadedVideo;
				}
				return null;
			}

			@Override
			public void onPostExecute(File file) {
				if (file != null) {
					mVideoView.get().getVideoLayout().videoView.setVideoPath(file.getAbsolutePath());
					mVideoView.get().getVideoLayout().downloadButton.setVisibility(Button.INVISIBLE);
					mVideoView.get().setVideoPlay();
				} else {
					Utils.showToast(mVideoView.get().getActivityContext(), "Video data not found");
				}
			}

		}.execute(mVideoView.get().getVideo());

	}

	public class VideoInfo {
		long id;
		int rating;

		public VideoInfo(long id, int rating) {
			this.id = id;
			this.rating = rating;
		}
	}

	public class VideoLayout {
		FloatingActionButton downloadButton;
		FloatingActionButton playButton;
		TextView titleText;
		RatingBar ratingBar;
		VideoView videoView;

		public VideoLayout(FloatingActionButton downloadButton2, FloatingActionButton playButton2,
				TextView titleText, RatingBar ratingBar, VideoView videoView) {
			this.downloadButton = downloadButton2;
			this.playButton = playButton2;
			this.titleText = titleText;
			this.ratingBar = ratingBar;
			this.videoView = videoView;
		}

	}

}
