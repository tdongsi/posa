// Generated code from Butter Knife. Do not modify!
package vandy.mooc.view;

import android.view.View;
import butterknife.ButterKnife.Finder;

public class LoginScreenActivity$$ViewInjector {
  public static void inject(Finder finder, final vandy.mooc.view.LoginScreenActivity target, Object source) {
    View view;
    view = finder.findRequiredView(source, 2131427329, "field 'password_'");
    target.password_ = (android.widget.EditText) view;
    view = finder.findRequiredView(source, 2131427331, "field 'server_'");
    target.server_ = (android.widget.EditText) view;
    view = finder.findRequiredView(source, 2131427328, "field 'userName_'");
    target.userName_ = (android.widget.EditText) view;
    view = finder.findRequiredView(source, 2131427330, "method 'login'");
    view.setOnClickListener(
      new android.view.View.OnClickListener() {
        @Override public void onClick(
          android.view.View p0
        ) {
          target.login();
        }
      });
  }

  public static void reset(vandy.mooc.view.LoginScreenActivity target) {
    target.password_ = null;
    target.server_ = null;
    target.userName_ = null;
  }
}
