/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.magnum.mobilecloud.video.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.model.AverageVideoRating;
import org.magnum.mobilecloud.video.model.UserVideoRating;
import org.magnum.mobilecloud.video.model.Video;
import org.magnum.mobilecloud.video.model.VideoStatus;
import org.magnum.mobilecloud.video.model.VideoStatus.VideoState;
import org.magnum.mobilecloud.video.repository.UserVideoRatingRepository;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;

@Controller
public class VideoController {

	@Autowired
	private VideoRepository videos;

	@Autowired
	private UserVideoRatingRepository userVideoRatingRepository;

	private static final AtomicLong currentId = new AtomicLong(0L);

	private VideoFileManager videoFileManager;

	public VideoController() {
		try {
			videoFileManager = VideoFileManager.get();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH, method = RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList() {
		System.out.println("entering getVideoList");
		return Lists.newArrayList(videos.findAll());
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH, method = RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video v, Principal p,
			HttpServletResponse response) throws IOException {

		Video videoFind = videos.findOne(v.getId());
		if (videoFind != null) {
			if (!videoFind.getOwner().equals(p.getName())) {
				response.sendError(HttpServletResponse.SC_FORBIDDEN,
						"Only the owner can modify video meta-data");
				return null;
			}
		}
		String owner = p.getName();
		v.setOwner(owner);
		return videos.save(v);
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_DATA_PATH, method = RequestMethod.POST)
	public @ResponseBody VideoStatus setVideoData(@PathVariable("id") long id,
			@RequestParam MultipartFile data, Principal p,
			HttpServletResponse response) throws Exception {
		if (data.isEmpty()) {
			throw new ResourceNotFoundException(); 
		} else {
			Video v = videos.findOne(id);
			try {
				if (v != null) {
					if (v.getOwner().equals(p.getName())) {
						videoFileManager
						.saveVideoData(v, data.getInputStream());
					} else {
						response.sendError(HttpServletResponse.SC_FORBIDDEN,
								"Wrong owner");
					}
				} else {
					throw new ResourceNotFoundException();
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
			return new VideoStatus(VideoState.READY);
		}
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_DATA_PATH, method = RequestMethod.GET)
	public void getVideoData(@PathVariable("id") long id, HttpServletResponse response) {
		Video v = videos.findOne(id);
		try {
			if (v != null && videoFileManager.hasVideoData(v)) {
				videoFileManager.copyVideoData(v, response.getOutputStream());
				response.setContentType(v.getContentType());
				response.getOutputStream();
			} else {
				throw new ResourceNotFoundException(); 		
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{"
			+ VideoSvcApi.ID_PARAMETER + "}", method = RequestMethod.GET)
	public Video getVideoById(@PathVariable("id") long id){
		if (id != 0) {
			Video v = videos.findOne(id);
			if (v != null) {
				return v;
			} else {
				throw new ResourceNotFoundException();
			}
		} else {
			throw new IllegalArgumentException();
		}
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{"
			+ VideoSvcApi.ID_PARAMETER + "}/rating/{rating}", method = RequestMethod.POST)
	public @ResponseBody AverageVideoRating rateVideo(
			@PathVariable("id") long id,
			@PathVariable("rating") int rating,
			Principal p, HttpServletResponse response) throws IOException {

		Video v = videos.findOne(id);
		String user = p.getName();
		if (v != null) {
			UserVideoRating existingUserVideoRating = userVideoRatingRepository
					.findByIdAndUser(id, user);
			if (existingUserVideoRating == null) {
				UserVideoRating newRating = new UserVideoRating(id, rating,
						user);
				userVideoRatingRepository.save(newRating);
			} else {
				existingUserVideoRating.setRating(rating);
				userVideoRatingRepository.save(existingUserVideoRating);
			}
			AverageVideoRating avg = getVideoRating(id);
			v.setTotalRatings((int) avg.getTotalRatings());
			v.setRating(avg.getRating());
			videos.save(v);
			return avg;
		} else {
			response.sendError(HttpServletResponse.SC_NOT_FOUND,
					"No video exists with id " + id);
			return null;
		}

	}

	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}/rating", method = RequestMethod.GET)
	public @ResponseBody AverageVideoRating getVideoRating(
			@PathVariable("id") long id) {

		double rating = userVideoRatingRepository.findAvgRatingByVideoId(id);
		long totalRatings = userVideoRatingRepository.findCountByVideoId(id);
		return new AverageVideoRating(rating, id, totalRatings);
	}

	private String getDataUrl(long videoId){
		String url = getUrlBaseForLocalServer() + "/video/" + videoId + "/data";
		return url;
	}

	private String getUrlBaseForLocalServer() {
		HttpServletRequest request = 
				((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		String base = 
				"http://"+request.getServerName() 
				+ ((request.getServerPort() != 80) ? ":"+request.getServerPort() : "");
		return base;
	}

	public Video save(Video entity) {
		checkAndSetId(entity);
		entity.setUrl(getDataUrl(entity.getId()));
		videos.save(entity);
		return entity;
	}

	private void checkAndSetId(Video entity) {
		if(entity.getId() == 0){
			entity.setId(currentId.incrementAndGet());
		}
	}

	@ExceptionHandler(IllegalArgumentException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	void handleIllegalArgumentException(IllegalArgumentException e, HttpServletResponse response) throws IOException {
		response.sendError(HttpStatus.BAD_REQUEST.value(), e.getMessage());
	}

}