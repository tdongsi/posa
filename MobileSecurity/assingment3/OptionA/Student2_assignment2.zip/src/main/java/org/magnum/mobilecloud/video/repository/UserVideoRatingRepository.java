package org.magnum.mobilecloud.video.repository;

import org.magnum.mobilecloud.video.model.UserVideoRating;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * An interface for a repository that can store UserVideoRating objects and
 * allow them to be searched by id.
 *
 */

@Repository
public interface UserVideoRatingRepository extends
CrudRepository<UserVideoRating, Long> {

	@Query("SELECT AVG(rating) from UserVideoRating where videoId=:videoId")
	public double findAvgRatingByVideoId(@Param("videoId") long videoId);

	@Query("SELECT COUNT(rating) from UserVideoRating where videoId=:videoId")
	public int findCountByVideoId(@Param("videoId") long videoId);

	@Query("select uvr from UserVideoRating uvr where uvr.videoId = :videoId and uvr.user = :user")
	public UserVideoRating findByIdAndUser(@Param("videoId") long videoId,
			@Param("user") String user);
}
