package org.magnum.mobilecloud.video.model;


public class AverageVideoRating {

	private final double rating;

	private final long videoId;

	private final long totalRatings;

	public AverageVideoRating(double rating, long videoId, long totalRatings) {
		super();
		this.rating = rating;
		this.videoId = videoId;
		this.totalRatings = totalRatings;
	}
	
	public double getRating() {
		return rating;
	}

	public long getVideoId() {
		return videoId;
	}

	public long getTotalRatings() {
		return totalRatings;
	}

}
