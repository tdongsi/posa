package org.magnum.client.screen.home;

import java.util.ArrayList;
import java.util.List;

import org.magnum.client.IController;
import org.magnum.client.R;
import org.magnum.client.controller.VideosController;
import org.magnum.client.model.Video;
import org.magnum.client.provider.VideosResolver;
import org.magnum.client.screen.WorkerFragment;
import org.magnum.client.screen.video.VideoActivity;
import org.magnum.client.service.UploadService;
import org.magnum.client.utils.SettingsUtils;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

public class HomeFragment extends WorkerFragment
{
    private final int PICK_VIDEO = 101;

    private final int COMMAND_GET_VIDEOS = 1;

    private final UploadReceiver receiver = new UploadReceiver();

    private final VideosAdapter adapter = new VideosAdapter();

    private Context context;

    private IController controller;

    private ListView  videosView;
    private ImageView buttonView;

    private Toast toast;

    private boolean isStartUp;
    private boolean isVisible;

    public static HomeFragment instance()
    {
        return new HomeFragment();
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);

        try
        {
            context = activity.getApplicationContext();
            controller = (IController) activity;
        }
        catch (ClassCastException e)
        {
            throw new ClassCastException(activity.toString() + " must implement IController");
        }
    }

    @Override
    public void onCreate(Bundle saved)
    {
        super.onCreate(saved);

        setRetainInstance(true);
        setHasOptionsMenu(true);
        registerReceiver();

        isStartUp = true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saved)
    {
        final View layout = inflater.inflate(R.layout.home_fragment, container, false);

        videosView = (ListView) layout.findViewById(R.id.items_list);
        videosView.setOnItemClickListener(onVideoClick);
        videosView.setAdapter(adapter);

        buttonView = (ImageView) layout.findViewById(R.id.float_button);
        buttonView.setOnClickListener(onPickerClick);

        return layout;
    }

    @Override
    public void onResume()
    {
        super.onResume();
        isVisible = true;

        if (isStartUp)
        {
            execute(COMMAND_GET_VIDEOS);
            isStartUp = false;
        }
    }

    @Override
    public void onPause()
    {
        isVisible = false;
        super.onPause();
    }

    @Override
    public void onDestroy()
    {
        unregisterReceiver();
        hideToastMessage();
        context = null;
        super.onDestroy();
    }

    @Override
    public void onDetach()
    {
        controller = null;
        super.onDetach();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
    {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.home, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        boolean handled = false;
        final int itemID = item.getItemId();
        switch (itemID)
        {
            case R.id.action_update_videos:
                execute(COMMAND_GET_VIDEOS);
                handled = true;
                break;
            default:
                handled = super.onOptionsItemSelected(item);
                break;
        }
        return handled;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        try
        {
            if (requestCode == PICK_VIDEO && resultCode == Activity.RESULT_OK)
            {
                if (data != null)
                {
                    final Uri videoURI = data.getData();
                    final Intent intent = UploadService.intent(context, videoURI);
                    context.startService(intent);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

    @Override
    protected void execute(int command)
    {
        showLoad();
        super.execute(command);
    }

    @Override
    protected Result onTaskExecuting(int command)
    {
        Result result = new Result();
        switch (command)
        {
            case COMMAND_GET_VIDEOS:
                result = doGetVideos();
                break;
            default:
                break;
        }
        return result;
    }

    @Override
    protected void onTaskCancelled(int command)
    {
        hideLoad();
    }

    @Override
    protected void onTaskCompleted(int command, Result result)
    {
        switch (command)
        {
            case COMMAND_GET_VIDEOS:
                onGetVideos(result);
                break;
            default:
                break;
        }
        hideLoad();
    }

    private Result doGetVideos()
    {
        final Result result = new Result();
        try
        {
            final String username = SettingsUtils.loadUsername(context, "");
            final String password = SettingsUtils.loadPassword(context, "");

            final VideosController proxy = new VideosController(username, password);

            final List<Video> videos = proxy.getVideos();
            result.setStatus(Result.STATUS_SUCCESS);
            result.setObject(videos);

            // persist incoming videos metadata
            final ContentResolver resolver = context.getContentResolver();
            VideosResolver.addVideos(resolver, videos);
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);

            try
            {
                // load persisted videos metadata if something fails
                final ContentResolver resolver = context.getContentResolver();
                final List<Video> stored = VideosResolver.getVideos(resolver);

                result.setStatus(Result.STATUS_ERROR);
                result.setObject(stored);
            }
            catch (Exception a)
            {
                Log.e(TAG, e.getMessage(), e);

                result.setStatus(Result.STATUS_ERROR);
                result.setObject(null);
            }
        }
        return result;
    }

    private void onGetVideos(Result result)
    {
        try
        {
            if (result == null)
            {
                showToastMessage("Failed to update videos.");
            }
            else
            {
                final int status = result.getStatus();
                if (status == Result.STATUS_SUCCESS)
                {
                    final List<Video> videos = toVideos(result);
                    adapter.setVideos(videos);
                    adapter.notifyDataSetChanged();
                }
                else
                {
                    showToastMessage("Failed to update videos.");

                    final List<Video> videos = toVideos(result);
                    adapter.setVideos(videos);
                    adapter.notifyDataSetChanged();
                }
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

    private AdapterView.OnItemClickListener onVideoClick = new AdapterView.OnItemClickListener()
    {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id)
        {
            try
            {
                final Video video = adapter.getItem(position);
                if (video != null)
                {
                    final Intent intent = VideoActivity.intent(context, video);
                    startActivity(intent);

                    isStartUp = true;
                }
            }
            catch (Exception e)
            {
                Log.e(TAG, e.getMessage(), e);
            }
        }
    };

    private View.OnClickListener onPickerClick = new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            try
            {
                // Create an intent that will start an Activity to get Video from Gallery.
                final Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("video/*");
                intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);

                // Verify the intent will resolve to an Activity.
                startActivityForResult(intent, PICK_VIDEO);
            }
            catch (Exception e)
            {
                Log.e(TAG, e.getMessage(), e);

                // ActivityNotFoundException
                showToastMessage("Unable to open Gallery");
            }
        }
    };

    private void showLoad()
    {
        if (controller != null)
        {
            controller.showLoad();
        }
    }

    private void hideLoad()
    {
        if (controller != null)
        {
            controller.hideLoad();
        }
    }

    @SuppressWarnings("unused")
    private void terminate()
    {
        if (controller != null)
        {
            controller.terminate();
        }
    }

    private void showToastMessage(String message)
    {
        hideToastMessage();

        try
        {
            toast = Toast.makeText(context, message, Toast.LENGTH_LONG);
            toast.show();
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

    private void hideToastMessage()
    {
        if (toast != null)
        {
            toast.cancel();
            toast = null;
        }
    }

    @SuppressWarnings("unchecked")
    private List<Video> toVideos(Result result)
    {
        List<Video> videos = new ArrayList<Video>();
        try
        {
            final Object object = result.getObject();
            if (object instanceof List<?>)
            {
                videos = (List<Video>) object;
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
        return videos;
    }

    /**
     * The Broadcast Receiver that registers itself to receive result
     * from UploadVideoService.
     */
    private class UploadReceiver extends BroadcastReceiver
    {
        /**
         * Hook method that's dispatched when the UploadService has uploaded the Video.
         */
        @Override
        public void onReceive(Context context, Intent intent)
        {
            final int status = intent.getIntExtra(UploadService.UPLOAD_STATUS_CODE, UploadService.STATUS_UPLOAD_ERROR);
            if (status == UploadService.STATUS_UPLOAD_SUCCESS)
            {
                // successfuly upload falls here, so lets reload videos list
                execute(COMMAND_GET_VIDEOS);
            }

            if (isVisible)
            {
                final String message = intent.getStringExtra(UploadService.UPLOAD_STATUS_MESSAGE);
                if (message != null) showToastMessage(message);
            }
        }
    }

    /**
     * Register a BroadcastReceiver to UploadService
     */
    private void registerReceiver()
    {
        // Create an Intent filter that handles Intents from the UploadVideoService.
        final IntentFilter filter = new IntentFilter(UploadService.ACTION_UPLOAD_ENDED);
        filter.addCategory(Intent.CATEGORY_DEFAULT);

        // Register the BroadcastReceiver.
        final LocalBroadcastManager manager = LocalBroadcastManager.getInstance(context);
        manager.registerReceiver(receiver, filter);
    }

    /**
     * Unregister a BroadcastReceiver to UploadService
     */
    private void unregisterReceiver()
    {
        // Create an Intent filter that handles Intents from the UploadVideoService.
        final IntentFilter filter = new IntentFilter(UploadService.ACTION_UPLOAD_ENDED);
        filter.addCategory(Intent.CATEGORY_DEFAULT);

        // Register the BroadcastReceiver.
        final LocalBroadcastManager manager = LocalBroadcastManager.getInstance(context);
        manager.unregisterReceiver(receiver);
    }
}
