package org.magnum.client.screen.video;

import java.io.File;

import org.magnum.client.IController;
import org.magnum.client.R;
import org.magnum.client.controller.VideosController;
import org.magnum.client.model.AverageVideoRating;
import org.magnum.client.model.Video;
import org.magnum.client.provider.VideosResolver;
import org.magnum.client.screen.WorkerFragment;
import org.magnum.client.service.DownloadService;
import org.magnum.client.utils.MediaStoreUtils;
import org.magnum.client.utils.SettingsUtils;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class VideoFragment extends WorkerFragment
{
    private static final String EXTRA_VIDEO = "VIDEO";

    private final int COMMAND_LOAD_URI = 1;
    private final int COMMAND_SET_RATE = 2;

    private final DownloadReceiver receiver = new DownloadReceiver();

    private Context context;

    private IController controller;

    private TextView  titleView;
    private TextView  labelView;
    private RatingBar ratingBar;
    private ImageView buttonView;

    private Toast toast;

    private Video video;
    private Uri videoURI;

    private boolean isStartUp;
    private boolean isVisible;

    private int stars;

    public static VideoFragment instance(Video video)
    {
        final Bundle args = new Bundle();
        args.putParcelable(EXTRA_VIDEO, video);
        
        final VideoFragment fragment = new VideoFragment();
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);

        try
        {
            context = activity.getApplicationContext();
            controller = (IController) activity;
        }
        catch (ClassCastException e)
        {
            throw new ClassCastException(activity.toString() + " must implement IController");
        }
    }

    @Override
    public void onCreate(Bundle saved)
    {
        super.onCreate(saved);

        setRetainInstance(true);
        registerReceiver();

        isStartUp = true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saved)
    {
        final View layout = inflater.inflate(R.layout.video_fragment, container, false);

        titleView = (TextView)  layout.findViewById(R.id.title_view);
        labelView = (TextView)  layout.findViewById(R.id.label_view);

        ratingBar = (RatingBar) layout.findViewById(R.id.rating_bar);
        ratingBar.setOnRatingBarChangeListener(onRateChanged);

        buttonView = (ImageView) layout.findViewById(R.id.float_button);
        buttonView.setOnClickListener(null);

        final Bundle args = getArguments();
        video = getVideo(args);

        // sanity check
        if (video == null)
        {
            // we have no conditions to show screen
            terminate();
        }
        else
        {
            // populate the UI with video data
            updateUI(video);
        }

        return layout;
    }

    @Override
    public void onResume()
    {
        super.onResume();
        isVisible = true;

        if (isStartUp)
        {
            execute(COMMAND_LOAD_URI);
            isStartUp = false;
        }
    }

    @Override
    public void onPause()
    {
        isVisible = false;
        super.onPause();
    }

    @Override
    public void onDestroy()
    {
        unregisterReceiver();
        hideToastMessage();
        context = null;
        super.onDestroy();
    }

    @Override
    public void onDetach()
    {
        controller = null;
        super.onDetach();
    }

    @Override
    protected void execute(int command)
    {
        showLoad();
        super.execute(command);
    }

    @Override
    protected Result onTaskExecuting(int command)
    {
        Result result = new Result();
        switch (command)
        {
            case COMMAND_LOAD_URI:
                result = doLoadURI();
                break;
            case COMMAND_SET_RATE:
                result = doSetRate();
                break;
            default:
                break;
        }
        return result;
    }

    @Override
    protected void onTaskCancelled(int command)
    {
        hideLoad();
    }

    @Override
    protected void onTaskCompleted(int command, Result result)
    {
        switch (command)
        {
            case COMMAND_LOAD_URI:
                onLoadURI(result);
                break;
            case COMMAND_SET_RATE:
                onSetRate(result);
                break;
            default:
                break;
        }
        updateUI(video);
        hideLoad();
    }

    private Result doLoadURI()
    {
        final Result result = new Result();
        try
        {
            final long traceID = video.getVideoID();

            final ContentResolver resolver = context.getContentResolver();
            final Uri localURI = VideosResolver.getTrace(resolver, traceID);
            final Uri  fileURI = toFileURI(localURI);

            result.setStatus(Result.STATUS_SUCCESS);
            result.setObject(fileURI);
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);

            result.setStatus(Result.STATUS_ERROR);
            result.setObject(null);
        }
        return result;
    }

    private void onLoadURI(Result result)
    {
        try
        {
            if (result == null)
            {
                showToastMessage("Failed to load video URI.");
                videoURI = null;
            }
            else
            {
                final int status = result.getStatus();
                if (status == Result.STATUS_SUCCESS)
                {
                    videoURI = toVideoURI(result);
                }
                else
                {
                    showToastMessage("Failed to load video URI.");
                    videoURI = null;
                }
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

    private Result doSetRate()
    {
        final Result result = new Result();
        try
        {
            final long videoID = video.getVideoID();

            final String username = SettingsUtils.loadUsername(context, "");
            final String password = SettingsUtils.loadPassword(context, "");

            final VideosController proxy = new VideosController(username, password);
            final AverageVideoRating rating = proxy.rateVideo(videoID, stars);

            result.setStatus(Result.STATUS_SUCCESS);
            result.setObject(rating);
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);

            result.setStatus(Result.STATUS_ERROR);
            result.setObject(null);
        }
        return result;
    }

    private void onSetRate(Result result)
    {
        try
        {
            if (result == null)
            {
                showToastMessage("Failed to rate video.");
            }
            else
            {
                final int status = result.getStatus();
                if (status == Result.STATUS_SUCCESS)
                {
                    final AverageVideoRating rating = toRating(result);

                    final double rates = rating.getRating();
                    video.setRating(rates);

                    final long votes = rating.getVotes();
                    video.setVotes(votes);
                }
                else
                {
                    showToastMessage("Failed to rate video.");
                }
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

    private void updateUI(Video video)
    {
        if (video != null)
        {
            final String title = video.getTitle();
            titleView.setText(title);

            final double rates = video.getRating();
            final long   votes = video.getVotes();
            final String type  = video.getContentType();
            final long   time  = video.getDuration();

            final long seconds = (time / 1000) % 60;
            final long minutes = (time / 1000) / 60;

            final String label = String.format("Content Type: %s\n\nDuration: %02d:%02d\n\nRating: %.1f  /  Votes: %02d", type, minutes, seconds, rates, votes);
//          final String label = String.format("Content Type: %s\n\nRating: %.1f  /  Votes: %02d", type, rates, votes);
            labelView.setText(label);

            ratingBar.setProgress(0);
            stars = 0;

            if (videoURI != null)
            {
                buttonView.setImageResource(R.drawable.ic_file_video_playback);
                buttonView.setOnClickListener(onPlaybackClick);
            }
            else
            {
                buttonView.setImageResource(R.drawable.ic_file_cloud_download);
                buttonView.setOnClickListener(onDownloadClick);
            }
        }
    }

    private void showLoad()
    {
        if (controller != null)
        {
            controller.showLoad();
        }
    }

    private void hideLoad()
    {
        if (controller != null)
        {
            controller.hideLoad();
        }
    }

    private void terminate()
    {
        if (controller != null)
        {
            controller.terminate();
        }
    }

    private void showToastMessage(String message)
    {
        hideToastMessage();

        try
        {
            toast = Toast.makeText(context, message, Toast.LENGTH_LONG);
            toast.show();
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

    private void hideToastMessage()
    {
        if (toast != null)
        {
            toast.cancel();
            toast = null;
        }
    }

    private Video getVideo(Bundle bundle)
    {
        Video result = null;

        if (bundle != null)
        {
            final Parcelable extra = bundle.getParcelable(EXTRA_VIDEO);
            if (extra instanceof Video)
            {
                result = (Video) extra;
            }
        }

        return result;
    }

    private Uri toFileURI(Uri videoURI)
    {
        Uri fileURI = null;
        try
        {
            if (videoURI != null)
            {
                final String path = MediaStoreUtils.getPath(context, videoURI);
                if (TextUtils.isEmpty(path))
                {
                    fileURI = null;
                }
                else
                {
                    final File file = new File(path);
                    if (file.exists())
                    {
                        fileURI = Uri.fromFile(file);
                    }
                    else
                    {
                        fileURI = null;
                    }
                }
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
        return fileURI;
    }

    protected Uri toVideoURI(Result result)
    {
        Uri videoURI = null;
        try
        {
            final Object object = result.getObject();
            if (object instanceof Uri)
            {
                videoURI = (Uri) object;
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
        return videoURI;
    }

    protected AverageVideoRating toRating(Result result)
    {
        AverageVideoRating rating = null;
        try
        {
            final Object object = result.getObject();
            if (object instanceof AverageVideoRating)
            {
                rating = (AverageVideoRating) object;
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
        return rating;
    }

    private RatingBar.OnRatingBarChangeListener onRateChanged = new RatingBar.OnRatingBarChangeListener()
    {
        @Override
        public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser)
        {
            if (fromUser)
            {
                rating = (rating < 1) ? 1 : rating;
                rating = (rating > 5) ? 5 : rating;

                stars = (int) (rating);
                ratingBar.setProgress(stars);

                execute(COMMAND_SET_RATE);
            }
        }
    };

    private View.OnClickListener onDownloadClick = new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            try
            {
                if (video != null)
                {
                    showLoad();

                    final long videoID = video.getVideoID();

                    final Intent intent = DownloadService.intent(context, videoID);
                    context.startService(intent);
                }
            }
            catch (Exception e)
            {
                Log.e(TAG, e.getMessage(), e);
            }
        }
    };

    private View.OnClickListener onPlaybackClick = new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            if (videoURI != null)
            {
                startVideoPlayer(videoURI);
            }
        }
    };

    public void startVideoPlayer(Uri file)
    {
        try
        {
            // String type = getActivity().getContentResolver().getType(file);
            final Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(file, "video/*");

            startActivity(Intent.createChooser(intent, "Open Video with..."));
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);

            // ActivityNotFoundException
            showToastMessage("Unable to play video");
        }
    }

    /**
     * The Broadcast Receiver that registers itself to receive result
     * from DownloadService
     */
    private class DownloadReceiver extends BroadcastReceiver
    {
        /**
         * Hook method that's dispatched when the UploadService has uploaded the Video.
         */
        @Override
        public void onReceive(Context context, Intent intent)
        {
            final int status = intent.getIntExtra(DownloadService.DOWNLOAD_STATUS_CODE, DownloadService.STATUS_DOWNLOAD_ERROR);
            if (status == DownloadService.STATUS_DOWNLOAD_SUCCESS)
            {
                videoURI = intent.getParcelableExtra(DownloadService.DOWNLOAD_CONTENT_URI);
                updateUI(video);
            }

            if (isVisible)
            {
                final String message = intent.getStringExtra(DownloadService.DOWNLOAD_STATUS_MESSAGE);
                if (message != null) showToastMessage(message);
            }

            hideLoad();
        }
    }

    private void registerReceiver()
    {
        // Create an Intent filter that handles Intents from the DownloadService
        final IntentFilter filter = new IntentFilter(DownloadService.ACTION_DOWNLOAD_ENDED);
        filter.addCategory(Intent.CATEGORY_DEFAULT);

        // Register the BroadcastReceiver
        final LocalBroadcastManager manager = LocalBroadcastManager.getInstance(context);
        manager.registerReceiver(receiver, filter);
    }

    private void unregisterReceiver()
    {
        // Create an Intent filter that handles Intents from the DownloadService
        final IntentFilter filter = new IntentFilter(DownloadService.ACTION_DOWNLOAD_ENDED);
        filter.addCategory(Intent.CATEGORY_DEFAULT);

        // Unregister the BroadcastReceiver
        final LocalBroadcastManager manager = LocalBroadcastManager.getInstance(context);
        manager.unregisterReceiver(receiver);
    }
}
