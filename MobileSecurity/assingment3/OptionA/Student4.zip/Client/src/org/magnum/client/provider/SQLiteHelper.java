package org.magnum.client.provider;

import java.io.File;

import org.magnum.client.provider.VideosContract.TraceContent;
import org.magnum.client.provider.VideosContract.VideoContent;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * The database helper used by the Content Provider to create
 * and manage its underling database.
 */
public class SQLiteHelper extends SQLiteOpenHelper
{
    /**
     * Database name.
     */
    private static String DATABASE_NAME = "videos.db";

    /**
     * Database version number, which is updated with each schema
     * change.
     */
    private static int DATABASE_VERSION = 1;

    /*
     * SQL create table statements.
     */

     /**
     * Constructor - initialize database name and version, but don't
     * actually construct the database (which is done in the
     * onCreate() hook method). It places the database in the
     * application's cache directory, which will be automatically
     * cleaned up by Android if the device runs low on storage space.
     * 
     * @param context
     */
    public SQLiteHelper(Context context)
    {
        // super(context, context.getCacheDir() + File.separator + DATABASE_NAME, null, DATABASE_VERSION);
        super(context, context.getFilesDir() + File.separator + DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Hook method called when the database is created.
     */
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        final StringBuilder builder1 = new StringBuilder();
        builder1.append("CREATE TABLE ");
        builder1.append(VideoContent.TABLE_NAME);
        builder1.append(" (");

        builder1.append(VideoContent.COLUMN_ID);
        builder1.append(" ");
        // builder1.append("INTEGER PRIMARY KEY");
        builder1.append("INTEGER UNIQUE NOT NULL");
        builder1.append(", ");

        builder1.append(VideoContent.COLUMN_TITLE);
        builder1.append(" ");
        builder1.append("TEXT NOT NULL");
        builder1.append(", ");

        builder1.append(VideoContent.COLUMN_DURATION);
        builder1.append(" ");
        builder1.append("TEXT NOT NULL");
        builder1.append(", ");

        builder1.append(VideoContent.COLUMN_CONTENT_TYPE);
        builder1.append(" ");
        builder1.append("TEXT NOT NULL");
        builder1.append(", ");

        builder1.append(VideoContent.COLUMN_DATA_URL);
        builder1.append(" ");
        builder1.append("TEXT NOT NULL");
        builder1.append(", ");

        builder1.append(VideoContent.COLUMN_RATING);
        builder1.append(" ");
        builder1.append("TEXT NOT NULL");
        builder1.append(", ");

        builder1.append(VideoContent.COLUMN_VOTES);
        builder1.append(" ");
        builder1.append("TEXT NOT NULL");
        builder1.append(");");

        final StringBuilder builder2 = new StringBuilder();
        builder2.append("CREATE TABLE ");
        builder2.append(TraceContent.TABLE_NAME);
        builder2.append(" (");

        builder2.append(TraceContent.COLUMN_ID);
        builder2.append(" ");
        // builder2.append("INTEGER PRIMARY KEY");
        builder2.append("INTEGER UNIQUE NOT NULL");
        builder2.append(", ");

        builder2.append(TraceContent.COLUMN_URI);
        builder2.append(" ");
        builder2.append("TEXT");
        builder2.append(");");

        final String CREATE_TABLE_1 = builder1.toString();
        final String CREATE_TABLE_2 = builder2.toString();

        // Create the table(s).
        db.execSQL(CREATE_TABLE_1);
        db.execSQL(CREATE_TABLE_2);
    }

    /**
     * Hook method called when the database is upgraded.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        // Delete the existing tables.
        db.execSQL("DROP TABLE IF EXISTS " + VideoContent.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TraceContent.TABLE_NAME);

        // Create the new tables.
        onCreate(db);
    }
}
