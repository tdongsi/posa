package org.magnum.client.provider;

import org.magnum.client.provider.VideosContract.TraceContent;
import org.magnum.client.provider.VideosContract.VideoContent;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.text.TextUtils;

/**
 * Content Provider interface used to manage Hobbit characters.  This
 * class plays the role of the "Abstraction" in the Bridge pattern.
 * It and the hierarchy it abstracts play the role of the "Model" in
 * the Model-View-Presenter pattern.
 */
public class VideosProvider extends ContentProvider
{
    /**
     * Debugging tag used by the Android logger.
     */
    protected final static String TAG = VideosProvider.class.getSimpleName();

    private SQLiteHelper helper;

    /**
     * The code that is returned when a URI for more than 1 items
     * is matched against the given components. Must be positive.
     */
    public static final int VIDEOS = 100;
    public static final int TRACES = 200;

    /**
     * The code that is returned when a URI for exactly 1 item
     * is matched against the given components. Must be positive.
     */
    public static final int VIDEO = 101;
    public static final int TRACE = 201;

    /**
     * The URI Matcher used by this content provider.
     */
    public static final UriMatcher URI_MATCHER = matcher();

    /**
     * Helper method to match each URI to the ACRONYM integers constant defined above.
     * 
     * @return UriMatcher
     */
    protected final static UriMatcher matcher()
    {
        // All paths added to the UriMatcher have a corresponding code
        // to return when a match is found. The code passed into the
        // constructor represents the code to return for the rootURI.
        // It's common to use NO_MATCH as the code for this case.
        final UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);

        // For each type of URI that is added, a corresponding code is
        // created.
        matcher.addURI(VideosContract.CONTENT_AUTHORITY, VideosContract.PATH_VIDEOS, VIDEOS);
        matcher.addURI(VideosContract.CONTENT_AUTHORITY, VideosContract.PATH_VIDEOS + "/#", VIDEO);
        matcher.addURI(VideosContract.CONTENT_AUTHORITY, VideosContract.PATH_TRACES, TRACES);
        matcher.addURI(VideosContract.CONTENT_AUTHORITY, VideosContract.PATH_TRACES + "/#", TRACE);

        return matcher;
    }

    @Override
    public boolean onCreate()
    {
        final Context context = getContext();
        helper = new SQLiteHelper(context);
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder)
    {
        Cursor cursor;

        switch (URI_MATCHER.match(uri))
        {
            case VIDEOS:
                cursor = getVideos(uri, projection, selection, selectionArgs, sortOrder);
                break;
            case VIDEO:
                cursor = getVideo(uri, projection, selection, selectionArgs, sortOrder);
                break;
            case TRACES:
                cursor = getTraces(uri, projection, selection, selectionArgs, sortOrder);
                break;
            case TRACE:
                cursor = getTrace(uri, projection, selection, selectionArgs, sortOrder);
                break;
            default:
                throw new UnsupportedOperationException("Unknown URI: " + uri);
        }

        // Register to watch a content URI for changes.
        final Context context = getContext();
        cursor.setNotificationUri(context.getContentResolver(), uri);

        return cursor;
    }

    private Cursor getVideos(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder)
    {
        final SQLiteDatabase database = helper.getReadableDatabase();
        return database.query(VideoContent.TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);
    }

    private Cursor getVideo(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder)
    {
        final SQLiteDatabase database = helper.getReadableDatabase();
        
        final long id = ContentUris.parseId(uri);
        selection = whereByID(selection, VideoContent.COLUMN_ID, id);

        return database.query(VideoContent.TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);
    }

    private Cursor getTraces(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder)
    {
        final SQLiteDatabase database = helper.getReadableDatabase();
        return database.query(TraceContent.TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);
    }

    private Cursor getTrace(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder)
    {
        final SQLiteDatabase database = helper.getReadableDatabase();
        
        final long id = ContentUris.parseId(uri);
        selection = whereByID(selection, TraceContent.COLUMN_ID, id);

        return database.query(TraceContent.TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);
    }

    @Override
    public Uri insert(Uri uri, ContentValues values)
    {
        Uri result = null;
        switch (URI_MATCHER.match(uri))
        {
            case VIDEO:
                result = addVideo(uri, values);
                break;
            case TRACE:
                result = addTrace(uri, values);
                break;
            default:
                throw new UnsupportedOperationException("Unknown URI: " + uri);
        }
        return result;
    }

    private Uri addVideo(Uri uri, ContentValues values)
    {
        final SQLiteDatabase database = helper.getWritableDatabase();

        final long rowID = database.insertWithOnConflict(VideoContent.TABLE_NAME, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        Uri result = (rowID != -1) ? VideoContent.buildURI(rowID) : null;

        final boolean notify = (rowID != -1);
        warnAboutChanges(uri, notify);

        return result;
    }

    private Uri addTrace(Uri uri, ContentValues values)
    {
        final SQLiteDatabase database = helper.getWritableDatabase();

        final long rowID = database.insertWithOnConflict(TraceContent.TABLE_NAME, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        Uri result = (rowID != -1) ? TraceContent.buildURI(rowID) : null;

        final boolean notify = (rowID != -1);
        warnAboutChanges(uri, notify);

        return result;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs)
    {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs)
    {
        int counter = 0;

        switch (URI_MATCHER.match(uri))
        {
            case VIDEO:
                counter = setVideo(uri, values, selection, selectionArgs);
                break;
            case TRACE:
                counter = setTrace(uri, values, selection, selectionArgs);
                break;
            default:
                throw new UnsupportedOperationException();
        }

        final boolean notify = (counter > 0);
        warnAboutChanges(uri, notify);

        return counter;
    }

    private int setVideo(Uri uri, ContentValues values, String selection, String[] selectionArgs)
    {
        final SQLiteDatabase database = helper.getWritableDatabase();

        final long id = ContentUris.parseId(uri);
        selection = whereByID(selection, VideoContent.COLUMN_ID, id);

        final int counter = database.updateWithOnConflict(VideoContent.TABLE_NAME, values, selection, selectionArgs, SQLiteDatabase.CONFLICT_REPLACE);

        final boolean notify = (counter != -1);
        warnAboutChanges(uri, notify);

        return counter;
    }

    private int setTrace(Uri uri, ContentValues values, String selection, String[] selectionArgs)
    {
        final SQLiteDatabase database = helper.getWritableDatabase();

        final long id = ContentUris.parseId(uri);
        selection = whereByID(selection, TraceContent.COLUMN_ID, id);

        final int counter = database.updateWithOnConflict(TraceContent.TABLE_NAME, values, selection, selectionArgs, SQLiteDatabase.CONFLICT_REPLACE);

        final boolean notify = (counter != -1);
        warnAboutChanges(uri, notify);

        return counter;
    }

    @Override
    public int bulkInsert(Uri uri, ContentValues[] values)
    {
        int counter = 0;

        switch (URI_MATCHER.match(uri))
        {
            case VIDEOS:
                counter = addVideos(uri, values);
                break;
            case TRACES:
                counter = addTraces(uri, values);
                break;
            default:
                throw new UnsupportedOperationException();
        }

        final boolean notify = (counter > 0);
        warnAboutChanges(uri, notify);

        return counter;
    }

    private int addVideos(Uri uri, ContentValues[] values)
    {
        final SQLiteDatabase database = helper.getWritableDatabase();

        int counter = 0;

        // Begins a transaction in EXCLUSIVE mode.
        database.beginTransaction();
        try
        {
            for (ContentValues row : values)
            {
                // final long rowID = database.insert(VideoEntry.TABLE_NAME, null, row);
                final long rowID = database.insertWithOnConflict(VideoContent.TABLE_NAME, null, row, SQLiteDatabase.CONFLICT_REPLACE);
                if (rowID != -1) counter++;
            }

            // Marks the current transaction as successful.
            database.setTransactionSuccessful();
        }
        finally
        {
            // End a transaction.
            database.endTransaction();
        }
        return counter;
    }

    private int addTraces(Uri uri, ContentValues[] values)
    {
        final SQLiteDatabase database = helper.getWritableDatabase();

        int counter = 0;

        // Begins a transaction in EXCLUSIVE mode.
        database.beginTransaction();
        try
        {
            for (ContentValues row : values)
            {
                final long rowID = database.insertWithOnConflict(TraceContent.TABLE_NAME, null, row, SQLiteDatabase.CONFLICT_REPLACE);
                if (rowID != -1) counter++;
            }

            // Marks the current transaction as successful.
            database.setTransactionSuccessful();
        }
        finally
        {
            // End a transaction.
            database.endTransaction();
        }
        return counter;
    }

    private void warnAboutChanges(Uri uri, boolean notify)
    {
        if (notify)
        {
            // Notifies registered observers that row(s) were inserted.
            final Context context = getContext();
            final ContentResolver resolver = context.getContentResolver();
            resolver.notifyChange(uri, null);
        }
    }

    /**
     * Helper method that appends a given key id to the end of the WHERE statement parameter.
     */
    private static String whereByID(String selection, String column, long id)
    {
        final StringBuilder builder = new StringBuilder();

        if (!TextUtils.isEmpty(selection))
        {
            builder.append(selection);
            builder.append(" AND ");
        }

        builder.append(column);
        builder.append(" = ");
        builder.append("'");
        builder.append(id);
        builder.append("'");

        return builder.toString();
    }

    @Override
    public String getType(Uri uri)
    {
        switch (URI_MATCHER.match(uri))
        {
            case VIDEOS:
                return VideoContent.CONTENT_ITEMS_TYPE;
            case VIDEO:
                return VideoContent.CONTENT_ITEM_TYPE;
            case TRACES:
                return TraceContent.CONTENT_ITEMS_TYPE;
            case TRACE:
                return TraceContent.CONTENT_ITEM_TYPE;
            default:
                throw new UnsupportedOperationException("Unknown URI: " + uri);
        }
    }
}
