package org.magnum.client.screen;

import android.os.AsyncTask;
import android.util.Log;

public abstract class WorkerFragment extends AbstractFragment
{
    private AsyncTask<Void, Void, Result> task;

    protected void execute(int command)
    {
        cancel();

        task = new InternalTask(command);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

        Log.d(TAG, "execute()");
    }

    protected void cancel()
    {
        if (task != null)
        {
            task.cancel(true);
            task = null;
        }
    }

    protected abstract Result onTaskExecuting(int command);

    protected abstract void onTaskCancelled(int command);

    protected abstract void onTaskCompleted(int command, Result result);

    private final class InternalTask extends AsyncTask<Void, Void, Result>
    {
        private int command;

        public InternalTask(int command)
        {
            super();
            this.command = command;
        }

        @Override
        protected Result doInBackground(Void... params)
        {
            return onTaskExecuting(command);
        }

        @Override
        protected void onPostExecute(Result result)
        {
            super.onPostExecute(result);
            onTaskCompleted(command, result);
        }

        @Override
        protected void onCancelled()
        {
            super.onCancelled();
            onTaskCancelled(command);
        }
    }

    public static class Result
    {
        public static final int STATUS_SUCCESS = 0;
        public static final int STATUS_ERROR   = 1;

        private int    status;
        private Object object;

        public Result()
        {
            this.status = STATUS_ERROR;
            this.object = null;
        }

        public Result(int status, Object object)
        {
            super();
            this.status = status;
            this.object = object;
        }

        public int getStatus()
        {
            return status;
        }

        public void setStatus(int status)
        {
            this.status = status;
        }

        public Object getObject()
        {
            return object;
        }

        public void setObject(Object object)
        {
            this.object = object;
        }
    }
}
