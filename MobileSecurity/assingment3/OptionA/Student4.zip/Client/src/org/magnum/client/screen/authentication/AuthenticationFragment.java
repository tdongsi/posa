package org.magnum.client.screen.authentication;

import org.magnum.client.IController;
import org.magnum.client.R;
import org.magnum.client.controller.VideosController;
import org.magnum.client.screen.WorkerFragment;
import org.magnum.client.screen.home.HomeActivity;
import org.magnum.client.utils.SettingsUtils;

import retrofit.client.Response;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AuthenticationFragment extends WorkerFragment
{
    private final int TASK_VALIDATE = 1;

    private Context context;

    private IController controller;

    private EditText editUsername;
    private EditText editPassword;
    private Button   actionButton;

    private String username;
    private String password;

    private Toast toast;

    public static AuthenticationFragment instance()
    {
        return new AuthenticationFragment();
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);

        try
        {
            context = activity.getApplicationContext();
            controller = (IController) activity;
        }
        catch (ClassCastException e)
        {
            throw new ClassCastException(activity.toString() + " must implement IController");
        }
    }

    @Override
    public void onCreate(Bundle saved)
    {
        super.onCreate(saved);

        setRetainInstance(true);
        SettingsUtils.clearCredentials(context);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saved)
    {
        final View layout = inflater.inflate(R.layout.authentication_fragment, container, false);

        editUsername = (EditText) layout.findViewById(R.id.edit_username);
        editPassword = (EditText) layout.findViewById(R.id.edit_password);
        actionButton = (Button)   layout.findViewById(R.id.action_button);

        actionButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                username = editUsername.getText().toString();
                password = editPassword.getText().toString();

                username = (username == null) ? null : username.trim();
                password = (password == null) ? null : password.trim();
                
                layout.requestFocus();
                validate(username, password);
            }
        });

        return layout;
    }

    @Override
    public void onDestroy()
    {
        hideToastMessage();
        context = null;
        super.onDestroy();
    }

    @Override
    public void onDetach()
    {
        controller = null;
        super.onDetach();
    }

    @Override
    protected void execute(int command)
    {
        showLoad();
        super.execute(command);
    }

    @Override
    protected Result onTaskExecuting(int command)
    {
        Result result = new Result();

        switch (command)
        {
            case TASK_VALIDATE:
                result = doValidate();
                break;
            default:
                break;
        }

        return result;
    }

    @Override
    protected void onTaskCancelled(int command)
    {
        hideLoad();
    }

    @Override
    protected void onTaskCompleted(int command, Result result)
    {
        switch (command)
        {
            case TASK_VALIDATE:
                onValidate(result);
                break;
            default:
                break;
        }
        hideLoad();
    }

    private void validate(String username, String password)
    {
        if (TextUtils.isEmpty(username))
        {
            showToastMessage("The username is missing.");
        }
        else
        {
            if (TextUtils.isEmpty(password))
            {
                showToastMessage("The password  is missing.");
            }
            else
            {
                execute(TASK_VALIDATE);
            }
        }
    }

    private Result doValidate()
    {
        final Result result = new Result();
        try
        {
            final VideosController proxy = new VideosController(username, password);

            final Response response = proxy.validate();
            if (response == null)
            {
                result.setStatus(Result.STATUS_ERROR);
                result.setObject(null);
            }
            else
            {
                final int status = response.getStatus();
                if (status < 200 || status > 299)
                {
                    // If not, we probably have bad credentials
                    result.setStatus(Result.STATUS_ERROR);
                    result.setObject(null);
                }
                else
                {
                    SettingsUtils.saveCredentials(context, username, password);
                    result.setStatus(Result.STATUS_SUCCESS);
                    result.setObject(null);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);

            result.setStatus(Result.STATUS_ERROR);
            result.setObject(null);
        }
        return result;
    }

    private void onValidate(Result result)
    {
        try
        {
            if (result == null)
            {
                showToastMessage("Please check your credentials.");
            }
            else
            {
                final int status = result.getStatus();
                if (status == Result.STATUS_SUCCESS)
                {
                    final Intent intent = HomeActivity.intent(context);
                    startActivity(intent);
                    terminate();
                }
                else
                {
                    showToastMessage("Please check your credentials.");
                }
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

    private void showLoad()
    {
        if (controller != null)
        {
            controller.showLoad();
        }
    }

    private void hideLoad()
    {
        if (controller != null)
        {
            controller.hideLoad();
        }
    }

    private void terminate()
    {
        if (controller != null)
        {
            controller.terminate();
        }
    }

    private void showToastMessage(String message)
    {
        hideToastMessage();

        try
        {
            toast = Toast.makeText(context, message, Toast.LENGTH_LONG);
            toast.show();
        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

    private void hideToastMessage()
    {
        if (toast != null)
        {
            toast.cancel();
            toast = null;
        }
    }
}
