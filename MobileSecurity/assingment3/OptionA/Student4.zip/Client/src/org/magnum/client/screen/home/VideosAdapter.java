package org.magnum.client.screen.home;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.magnum.client.R;
import org.magnum.client.model.Video;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class VideosAdapter extends BaseAdapter
{
    private final List<Video> items = new CopyOnWriteArrayList<Video>();

    public VideosAdapter()
    {
        super();
        setVideos(null);
    }

    public synchronized void setVideos(Collection<Video> videos)
    {
        if (videos != null)
        {
            items.clear();
            items.addAll(videos);
        }
        else
        {
            items.clear();
        }
    }

    @Override
    public int getCount()
    {
        return items.size();
    }

    @Override
    public synchronized Video getItem(int position)
    {
        Video item = null;

        final int S = items.size();
        final int L = S - 1;

        if (position >= 0 && position <= L)
        {
            item = items.get(position);
        }

        return item;
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent)
    {
        ViewHolder holder = null;

        if (view == null)
        {
            final Context context = parent.getContext();

            final LayoutInflater inflater = LayoutInflater.from(context);
            view = inflater.inflate(R.layout.list_video_item, parent, false);

            holder = new ViewHolder();
            holder.title = (TextView) view.findViewById(R.id.title);
            holder.label = (TextView) view.findViewById(R.id.label);

            view.setTag(holder);
        }

        holder = (ViewHolder) view.getTag();

        final Video video = getItem(position);

        final String title = video.getTitle();
        holder.title.setText(title);

        final double rated = video.getRating();

        final String label = String.format("Rating: %.1f", rated);
        holder.label.setText(label);

        return view;
    }

    private final class ViewHolder
    {
        private TextView title;
        private TextView label;
    }
}
