package org.magnum.client;

public interface IController
{
    public void showLoad();

    public void hideLoad();

    public void terminate();
}
