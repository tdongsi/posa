package org.magnum.client.service;

import java.io.File;

import org.magnum.client.Constants;
import org.magnum.client.controller.VideosController;
import org.magnum.client.model.Video;
import org.magnum.client.model.VideoStatus;
import org.magnum.client.model.VideoStatus.VideoState;
import org.magnum.client.provider.VideosResolver;
import org.magnum.client.utils.MediaStoreUtils;
import org.magnum.client.utils.SettingsUtils;

import retrofit.mime.TypedFile;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.content.LocalBroadcastManager;

public class UploadService extends IntentService
{
    public static final String ACTION_UPLOAD_ENDED   = "org.magnum.client.ACTION_UPLOAD_ENDED";
    public static final String UPLOAD_STATUS_CODE    = "org.magnum.client.UPLOAD_STATUS_CODE";
    public static final String UPLOAD_STATUS_MESSAGE = "org.magnum.client.UPLOAD_STATUS_MESSAGE";

    public static final int STATUS_UPLOAD_SUCCESS = 1;
    public static final int STATUS_UPLOAD_ERROR   = 2;

    /**
     * It is used by Notification Manager to send Notifications.
     */
    private static final int NOTIFICATION_ID = 10;

    /**
     * Factory method that generates the intent to call this Service.
     */
    public static Intent intent(Context context, Uri videoURI)
    {
        final Intent intent = new Intent(context, UploadService.class);
        intent.setData(videoURI);
        return intent;
    }

    public UploadService()
    {
        super("UploadsService");
    }

    @Override
    protected void onHandleIntent(Intent intent)
    {
        if (intent == null) return;

        try
        {
            final Uri videoURI = intent.getData();
            handleVideoUpload(videoURI);
        }
        catch (Exception e)
        {
            final Context context = getApplicationContext();

            informUploadStopped(context, "Upload Failed", "");
            sendBroadcast(context, STATUS_UPLOAD_ERROR, "Upload Failed");
        }
    }

    /**
     * Upload video file handle method.
     */
    private void handleVideoUpload(Uri videoURI)
    {
        if (videoURI != null)
        {
            final Context context = getApplicationContext();

            final String username = SettingsUtils.loadUsername(context, "");
            final String password = SettingsUtils.loadPassword(context, "");

            final VideosController controller = new VideosController(username, password);

            final String path = MediaStoreUtils.getPath(context, videoURI);
            final File   file = new File(path);

            final long size = file.length();
            if (size > Constants.MAX_SIZE)
            {
                final Video local = MediaStoreUtils.getVideo(context, path);

                informUploadStopped(context, "Upload Failed: Large File", local.getTitle());
                sendBroadcast(context, STATUS_UPLOAD_ERROR, "Upload Failed: Large File");
            }
            else
            {
                if (size <= 0)
                {
                    final Video local = MediaStoreUtils.getVideo(context, path);

                    informUploadStopped(context, "Upload Failed: Empty File", local.getTitle());
                    sendBroadcast(context, STATUS_UPLOAD_ERROR, "Upload Failed: Empty File");
                }
                else
                {
                    final Video local = MediaStoreUtils.getVideo(context, path);

                    informUploadStarted(context, "Uploading File...", local.getTitle());

                    // add/update video information
                    final Video video = controller.setVideo(local);
                    if (video == null)
                    {
                        informUploadStopped(context, "Upload Failed: Video Not Added", local.getTitle());
                        sendBroadcast(context, STATUS_UPLOAD_ERROR, "Upload Failed: Video Not Added");
                    }
                    else
                    {
                        final long   videoID = video.getVideoID();
                        final String content = video.getContentType();
                        final TypedFile data = new TypedFile(content, file);

                        // add/update video data
                        final VideoStatus status = controller.setVideoContent(videoID, data);
    
                        // save the video metadata and its video URI trace to skip its download in future
                        final ContentResolver resolver = getContentResolver();
                        VideosResolver.addVideo(resolver, video);
                        VideosResolver.addTrace(resolver, videoID, videoURI);

                        final VideoState state = (status != null) ? status.getState() : null;
                        if (state == VideoState.READY)
                        {
                            informUploadStopped(context, "File Uploaded", local.getTitle());
                            sendBroadcast(context, STATUS_UPLOAD_SUCCESS, "File Uploaded");
                        }
                        else
                        {
                            informUploadStopped(context, "Upload Failed", local.getTitle());
                            sendBroadcast(context, STATUS_UPLOAD_ERROR, "File Failed");
                        }
                    }
                }
            }
        }
    }

    /**
     * Send the Notification to show the progress of video upload.
     */
    private void informUploadStarted(Context context, String title, String text)
    {
        final NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        final Notification.Builder builder = new Notification.Builder(context);
        builder.setContentTitle(title);
        builder.setContentText(text);
        builder.setSmallIcon(android.R.drawable.stat_sys_upload);
        builder.setProgress(0, 100, true);

        manager.notify(NOTIFICATION_ID, builder.build());
    }

    /**
     * Send the Notification after the Video is Uploaded.
     */
    private void informUploadStopped(Context context, String title, String text)
    {
        final NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        final Notification.Builder builder = new Notification.Builder(context);
        builder.setContentTitle(title);
        builder.setContentText(text);
        builder.setSmallIcon(android.R.drawable.stat_sys_upload_done);
        builder.setProgress(0, 100, false);

        manager.notify(NOTIFICATION_ID, builder.build());
    }

    /**
     * Send the Broadcast to Activity that the Video Upload is completed.
     */
    private void sendBroadcast(Context context, int status, String message)
    {
        final LocalBroadcastManager manager = LocalBroadcastManager.getInstance(context);

        final Intent intent = new Intent(ACTION_UPLOAD_ENDED);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.putExtra(UPLOAD_STATUS_CODE, status);
        intent.putExtra(UPLOAD_STATUS_MESSAGE, message);

        manager.sendBroadcast(intent);
    }
}
