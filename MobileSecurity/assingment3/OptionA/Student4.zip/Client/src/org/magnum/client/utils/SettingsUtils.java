package org.magnum.client.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class SettingsUtils
{
    private static final String PREFERENCES_FILE_NAME = "settings";

    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    private static SharedPreferences getPreferences(Context context)
    {
        return context.getSharedPreferences(PREFERENCES_FILE_NAME, Activity.MODE_PRIVATE);
    }

    public static void clearCredentials(Context context)
    {
        final SharedPreferences preferences = getPreferences(context);

        final SharedPreferences.Editor editor = preferences.edit();
        editor.remove(KEY_USERNAME);
        editor.remove(KEY_PASSWORD);
        editor.commit();
    }

    public static void saveCredentials(Context context, String username, String password)
    {
        final SharedPreferences preferences = getPreferences(context);

        final SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_USERNAME, username);
        editor.putString(KEY_PASSWORD, password);
        editor.commit();
    }

    public static String loadUsername(Context context, String fallback)
    {
        final SharedPreferences preferences = getPreferences(context);
        return preferences.getString(KEY_USERNAME, fallback);
    }

    public static String loadPassword(Context context, String fallback)
    {
        final SharedPreferences preferences = getPreferences(context);
        return preferences.getString(KEY_PASSWORD, fallback);
    }
}
