package org.magnum.client.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * This "Plain Ol' Java Object" (POJO) class represents meta-data of interest downloaded
 * in Json from the Video Service via the VideosServiceAPI.
 */
public class Video implements Parcelable
{
    /**
     * Various fields corresponding to data downloaded in Json from the Video WebService.
     */

    @SerializedName("id")
    private long videoID;

    @SerializedName("title")
    private String title;

    @SerializedName("duration")
    private long duration;

    @SerializedName("contentType")
    private String contentType;

    @SerializedName("dataURL")
    private String dataURL;

    @SerializedName("rating")
    private double rating;

    @SerializedName("votes")
    private long votes;

    /**
     * No-op constructor
     */
    public Video()
    {
        this.videoID     = 0;
        this.title       = "<UNKNOWN>";
        this.duration    = 0;
        this.contentType = null;
        this.dataURL     = null;
        this.rating      = 0;
        this.votes       = 0;
    }

    protected Video(Parcel parcel)
    {
        this();
        readFromParcel(parcel);
    }

    /**
     * Constructor that initializes title, duration, and contentType.
     */
    public Video(String title, long duration, String contentType)
    {
        this.title       = title;
        this.duration    = duration;
        this.contentType = contentType;
    }

    /*
     * Getters and setters to access Video.
     */

    /**
     * Get the video ID.
     */
    public long getVideoID()
    {
        return videoID;
    }

    /**
     * Set the video ID.
     */
    public void setVideoID(long videoID)
    {
        this.videoID = videoID;
    }

    /**
     * Get the video title.
     */
    public String getTitle()
    {
        return title;
    }

    /**
     * Set the video title.
     */
    public void setTitle(String title)
    {
        this.title = title;
    }

    /**
     * Get the video duration.
     */
    public long getDuration()
    {
        return duration;
    }

    /**
     * Set the video duration.
     */
    public void setDuration(long duration)
    {
        this.duration = duration;
    }

    /**
     * Get the video content type.
     */
    public String getContentType()
    {
        return contentType;
    }

    /**
     * Set the video content type.
     */
    public void setContentType(String contentType)
    {
        this.contentType = contentType;
    }

    /**
     * @return the dataURL
     */
    public String getDataURL()
    {
        return dataURL;
    }

    /**
     * @param dataURL the dataURL to set
     */
    public void setDataURL(String dataURL)
    {
        this.dataURL = dataURL;
    }

    /**
     * Get the video rating.
     */
    public double getRating()
    {
        return rating;
    }

    /**
     * Set the video rating.
     */
    public void setRating(double rating)
    {
        this.rating = rating;
    }

    /**
     * @return the votes
     */
    public long getVotes()
    {
        return votes;
    }

    /**
     * @param votes the votes to set
     */
    public void setVotes(long votes)
    {
        this.votes = votes;
    }

    /**
     * Parcelable related methods
     */

    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags)
    {
        parcel.writeLong(videoID);
        parcel.writeString(title);
        parcel.writeLong(duration);
        parcel.writeString(contentType);
        parcel.writeString(dataURL);
        parcel.writeDouble(rating);
        parcel.writeLong(votes);
    }

    private void readFromParcel(Parcel parcel)
    {
        videoID     = parcel.readLong();
        title       = parcel.readString();
        duration    = parcel.readLong();
        contentType = parcel.readString();
        dataURL     = parcel.readString();
        rating      = parcel.readDouble();
        votes       = parcel.readLong();
    }

    public static final Parcelable.Creator<Video> CREATOR = new Creator<Video>()
    {
        @Override
        public Video[] newArray(int size)
        {
            return new Video[size];
        }
        
        @Override
        public Video createFromParcel(Parcel source)
        {
            return new Video(source);
        }
    };
}
