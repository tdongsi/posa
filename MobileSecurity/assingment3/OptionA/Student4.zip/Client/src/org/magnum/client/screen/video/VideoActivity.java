package org.magnum.client.screen.video;

import org.magnum.client.IController;
import org.magnum.client.R;
import org.magnum.client.model.Video;
import org.magnum.client.screen.AbstractActivity;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;

public class VideoActivity extends AbstractActivity implements IController
{
    private static final String EXTRA_VIDEO  = "EXTRA_VIDEO";
    private static final String TAG_FRAGMENT = "TAG_FRAGMENT";

    private View loadOverlay;

    public static final Intent intent(Context context, Video video)
    {
        final Intent intent = new Intent(context, VideoActivity.class);

        intent.putExtra(EXTRA_VIDEO, video);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

        return intent;
    }

    @Override
    protected void onCreate(Bundle saved)
    {
        super.onCreate(saved);
        setContentView(R.layout.video_activity);

        loadOverlay = findViewById(R.id.load_overlay);
        showHideLoad();

        final FragmentManager manager = getFragmentManager();
        final Fragment fragment = manager.findFragmentByTag(TAG_FRAGMENT);
        if (fragment == null)
        {
            final Intent intent = getIntent();

            final Video video = getVideo(intent);
            if (video == null)
            {
                // we have no conditions to show screen
                terminate();
            }
            else
            {
                final FragmentTransaction transaction = manager.beginTransaction();

                final Fragment container = VideoFragment.instance(video);
                transaction.replace(R.id.container, container, TAG_FRAGMENT);
                transaction.commitAllowingStateLoss();
            }
        }
    }

    @Override
    public void onBackPressed()
    {
        if (isLoading)
        {
            // do nothing
        }
        else
        {
            super.onBackPressed();
        }
    }

    @Override
    protected View getLoadView()
    {
        return loadOverlay;
    }

    private Video getVideo(Intent intent)
    {
        Video result = null;

        if (intent != null)
        {
            final Parcelable extra = intent.getParcelableExtra(EXTRA_VIDEO);
            if (extra instanceof Video)
            {
                result = (Video) extra;
            }
        }
        return result;
    }
}