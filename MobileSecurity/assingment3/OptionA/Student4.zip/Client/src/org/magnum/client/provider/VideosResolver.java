package org.magnum.client.provider;

import java.util.ArrayList;
import java.util.List;

import org.magnum.client.model.Video;
import org.magnum.client.provider.VideosContract.TraceContent;
import org.magnum.client.provider.VideosContract.VideoContent;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.RemoteException;
import android.text.TextUtils;

public class VideosResolver
{
    /**
     * Insert an array of Videos the VideosContentProvider.
     * Plays the role of a "template method" in the Template Method pattern.
     */
    public static int addVideos(ContentResolver resolver, List<Video> videos) throws RemoteException
    {
        if (videos == null) return 0;

        final ContentValues[] values = new ContentValues[videos.size()];

        // Index counter.
        int i = 0;

        // Insert all the characters into the ContentValues array.
        for (Video video : videos)
        {
            final ContentValues row = new ContentValues();
            row.put(VideoContent.COLUMN_ID,           video.getVideoID());
            row.put(VideoContent.COLUMN_TITLE,        video.getTitle());
            row.put(VideoContent.COLUMN_DURATION,     video.getDuration());
            row.put(VideoContent.COLUMN_CONTENT_TYPE, video.getContentType());
            row.put(VideoContent.COLUMN_DATA_URL,     video.getDataURL());
            row.put(VideoContent.COLUMN_RATING,       video.getRating());
            row.put(VideoContent.COLUMN_VOTES,        video.getVotes());
            values[i] = row;
            i++;
        }

        return resolver.bulkInsert(VideoContent.CONTENT_URI, values);
    }

    /**
     * Insert an video into the VideosContentProvider.
     */
    public static Uri addVideo(ContentResolver resolver, Video video)
    {
        final ContentValues values = toVideoValues(video);

        final long videoID = video.getVideoID();
        final Uri uri = VideoContent.buildURI(videoID);
        return resolver.insert(uri, values);
    }

    /**
     * Retrieve videos from the VideosContentProvider.
     */
    public static List<Video> getVideos(ContentResolver resolver)
    {
        final List<Video> result = new ArrayList<Video>();

        Cursor cursor = null;
        try
        {
            final Uri uri = VideoContent.CONTENT_URI;
            cursor = resolver.query(uri, null, null, null, null);
            if (cursor.moveToFirst())
            {
                Video video = toVideoModel(cursor);
                if (video != null) result.add(video);

                while (cursor.moveToNext())
                {
                    video = toVideoModel(cursor);
                    if (video != null) result.add(video);
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (cursor != null)
            {
                cursor.close();
            }
        }

        return result;
    }

    /**
     * Retrieve a video from the VideosContentProvider.
     */
    public static Video getVideo(ContentResolver resolver, long videoID)
    {
        Video result = null;

        Cursor cursor = null;
        try
        {
            final Uri uri = VideoContent.buildURI(videoID);
            cursor = resolver.query(uri, null, null, null, null);
            if (cursor.moveToFirst())
            {
                result = toVideoModel(cursor);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (cursor != null)
            {
                cursor.close();
            }
        }

        return result;
    }

    /**
     * Insert a rate into the ContentResolver.
     */
    public static Uri addTrace(ContentResolver resolver, long traceID, Uri traceURI)
    {
        final String value = traceURI.toString();

        final ContentValues values = new ContentValues();
        values.put(TraceContent.COLUMN_ID, traceID);
        values.put(TraceContent.COLUMN_URI, value);

        final Uri uri = TraceContent.buildURI(traceID);
        return resolver.insert(uri, values);
    }

    /**
     * Update a rate into the ContentResolver.
     */
    public static int setTrace(ContentResolver resolver, long traceID, Uri traceURI)
    {
        final String value = traceURI.toString();

        final ContentValues values = new ContentValues();
        values.put(TraceContent.COLUMN_ID, traceID);
        values.put(TraceContent.COLUMN_URI, value);

        final Uri uri = TraceContent.buildURI(traceID);
        return resolver.update(uri, values, null, null);
    }

    public static Uri getTrace(ContentResolver resolver, long traceID)
    {
        Uri result = null;

        Cursor cursor = null;
        try
        {
            final Uri uri = TraceContent.buildURI(traceID);
            cursor = resolver.query(uri, null, null, null, null);
            if (cursor.moveToFirst())
            {
                final int index = cursor.getColumnIndex(TraceContent.COLUMN_URI);

                final String text = cursor.getString(index);
                if (!TextUtils.isEmpty(text))
                {
                    result = Uri.parse(text);
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (cursor != null)
            {
                cursor.close();
            }
        }

        return result;
    }

    private static Video toVideoModel(Cursor cursor)
    {
        if (cursor == null) return null;

        final int index1 = cursor.getColumnIndex(VideoContent.COLUMN_ID);
        final int index2 = cursor.getColumnIndex(VideoContent.COLUMN_TITLE);
        final int index3 = cursor.getColumnIndex(VideoContent.COLUMN_DURATION);
        final int index4 = cursor.getColumnIndex(VideoContent.COLUMN_CONTENT_TYPE);
        final int index5 = cursor.getColumnIndex(VideoContent.COLUMN_DATA_URL);
        final int index6 = cursor.getColumnIndex(VideoContent.COLUMN_RATING);
        final int index7 = cursor.getColumnIndex(VideoContent.COLUMN_VOTES);

        final Video video = new Video();
        
        final long videoID = cursor.getLong(index1);
        video.setVideoID(videoID);

        final String title = cursor.getString(index2);
        video.setTitle(title);

        final long duration = cursor.getLong(index3);
        video.setDuration(duration);

        final String type = cursor.getString(index4);
        video.setContentType(type);

        final String dataURL = cursor.getString(index5);
        video.setDataURL(dataURL);

        final double rating = cursor.getDouble(index6);
        video.setRating(rating);

        final long votes = cursor.getLong(index7);
        video.setVotes(votes);

        return video;
    }

    private static ContentValues toVideoValues(Video video)
    {
        if (video == null) return null;

        final ContentValues values = new ContentValues();

        values.put(VideoContent.COLUMN_ID,           video.getVideoID());
        values.put(VideoContent.COLUMN_TITLE,        video.getTitle());
        values.put(VideoContent.COLUMN_DURATION,     video.getDuration());
        values.put(VideoContent.COLUMN_CONTENT_TYPE, video.getContentType());
        values.put(VideoContent.COLUMN_DATA_URL,     video.getDataURL());
        values.put(VideoContent.COLUMN_RATING,       video.getRating());
        values.put(VideoContent.COLUMN_VOTES,        video.getVotes());

        return values;
    }
}
