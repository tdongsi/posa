package org.magnum.client.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class AverageVideoRating implements Parcelable
{
    @SerializedName("rating")
    private double rating;

    @SerializedName("videoId")
    private long videoID;

    @SerializedName("totalRatings")
    private long votes;

    /**
     * No-op constructor
     */
    public AverageVideoRating()
    {
        this.rating  =  0;
        this.videoID = -1;
        this.votes   =  0;
    }

    protected AverageVideoRating(Parcel parcel)
    {
        this();
        readFromParcel(parcel);
    }

    /**
     * Constructor that initializes rating, videoID, and votes.
     */
    public AverageVideoRating(double rating, long videoID, int votes)
    {
        super();
        this.rating  = rating;
        this.videoID = videoID;
        this.votes   = votes;
    }

    /**
     * @return the rating
     */
    public double getRating()
    {
        return rating;
    }

    /**
     * @param rating the rating to set
     */
    public void setRating(double rating)
    {
        this.rating = rating;
    }

    /**
     * @return the videoID
     */
    public long getVideoID()
    {
        return videoID;
    }

    /**
     * @param videoID the videoID to set
     */
    public void setVideoID(long videoID)
    {
        this.videoID = videoID;
    }

    /**
     * @return the votes
     */
    public long getVotes()
    {
        return votes;
    }

    /**
     * @param votes the votes to set
     */
    public void setVotes(long votes)
    {
        this.votes = votes;
    }

    /**
     * Parcelable related methods
     */

    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags)
    {
        parcel.writeDouble(rating);
        parcel.writeLong(videoID);
        parcel.writeLong(votes);
    }

    private void readFromParcel(Parcel parcel)
    {
        videoID = parcel.readLong();
        rating  = parcel.readDouble();
        votes   = parcel.readLong();
    }

    public static final Parcelable.Creator<AverageVideoRating> CREATOR = new Creator<AverageVideoRating>()
    {
        @Override
        public AverageVideoRating[] newArray(int size)
        {
            return new AverageVideoRating[size];
        }
        
        @Override
        public AverageVideoRating createFromParcel(Parcel source)
        {
            return new AverageVideoRating(source);
        }
    };
}
