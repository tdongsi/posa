package org.magnum.client.controller;

import java.util.Collection;

import org.magnum.client.model.AverageVideoRating;
import org.magnum.client.model.Video;
import org.magnum.client.model.VideoStatus;

import retrofit.client.Response;
import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.Multipart;
import retrofit.http.POST;
import retrofit.http.Part;
import retrofit.http.Path;
import retrofit.http.Streaming;
import retrofit.mime.TypedFile;

public interface VideosServiceAPI
{
    /**
     * Used as Request Parameter for Video data.
     */
    public static final String PARAMETER_DATA = "data";

    /**
     * Used as Request Parameter for Video rating.
     */
    public static final String PARAMETER_RATE = "rate";

    /**
     * Used as Request Parameter for Video ID.
     */
    public static final String PARAMETER_ID = "id";

    /**
     * The path where we expect the Video service to live.
     */
    public static final String PATH_VIDEO = "/video";

    /**
     * The path where we expect the Video detail service to live.
     */
    public static final String PATH_VIDEO_DETAIL = "/video/{id}";

    /**
     * The path where we expect the Video data service to live.
     */
    public static final String PATH_VIDEO_DATA = PATH_VIDEO + "/{id}/data";

    /**
     * The path where we expect the Video rating service to live.
     */
    public static final String PATH_VIDEO_RATE = PATH_VIDEO + "/{id}/rating/{rate}";

    /**
     * The path where we expect to validate the user credentials.
     */
    public static final String PATH_VALIDATE = "/validate";

    /**
     * Sends a GET request to validate the credentials from a Web service using a two-way Retrofit RPC call.
     */
    @GET(PATH_VALIDATE)
    public Response validate();

    /**
     * Sends a GET request to get the List of Videos from a Web service using a two-way Retrofit RPC call.
     */
    @GET(PATH_VIDEO)
    public Collection<Video> getVideos();

    /**
     * Sends a GET request to get the Video from a Web service using a two-way Retrofit RPC call.
     */
    @GET(PATH_VIDEO_DETAIL)
    public Video getVideo(@Path(PARAMETER_ID) long videoID);

    /**
     * Sends a POST request to add/update the Video metadata to the Web service using a two-way Retrofit RPC call.
     * 
     * @param video  meta-data
     * @return Updated  video meta-data returned from the Video Service.
     */
    @POST(PATH_VIDEO)
    public Video setVideo(@Body Video video);

    /**
     * Sends a POST request to Upload the Video data to the Web service using a two-way Retrofit RPC call.
     * @Multipart is used to transfer multiple content (i.e. several files in case of a file upload to a server)
     * within one request entity. When doing so, a REST client can save the overhead of sending a sequence of
     * single requests to the server, thereby reducing network latency.
     * 
     * @param  videoID
     * @param  data
     * @return  videoStatus indicating status of the uploaded video.
     */
    @Multipart
    @POST(PATH_VIDEO_DATA)
    public VideoStatus setVideoContent(@Path(PARAMETER_ID) long videoID, @Part(PARAMETER_DATA) TypedFile data);

    /**
     * This method uses Retrofit's @Streaming annotation to indicate that the method is going to access a large
     * stream of data (e.g., the mpeg video data on the server). The client can access this stream of data by
     * obtaining an InputStream from the Response as shown below:
     *  
     * // use retrofit to create the client 
     * Response response = client.geVideotData(videoID);
     * InputStream videoDataStream = response.getBody().in();
     * 
     * @param  videoID
     * @return  Response which contains the actual Video data.
     */
    @Streaming
    @GET(PATH_VIDEO_DATA)
    public Response getVideotContent(@Path(PARAMETER_ID) long videoID);

    /**
     * Sends a POST request to rate the Video to the Web service using a two-way Retrofit RPC call.
     * 
     * @param videoID  the video ID
     * @param rate  the video rate
     * @return Updated  video meta-data returned from the Video Rate Service.
     */
    @POST(PATH_VIDEO_RATE)
    public AverageVideoRating rateVideo(@Path(PARAMETER_ID) long videoID, @Path(PARAMETER_RATE) double rate);
}
