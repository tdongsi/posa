package org.magnum.client.screen;

import org.magnum.client.IController;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public abstract class AbstractActivity extends Activity implements IController
{
    private final String EXTRA_LOADING = "EXTRA_LOADING";

    protected boolean isLoading;

    @Override
    protected void onCreate(Bundle saved)
    {
        super.onCreate(saved);

        if (saved == null)
        {
            // created
            isLoading = false;
        }
        else
        {
            // re-created
            isLoading = saved.getBoolean(EXTRA_LOADING, false);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        super.onSaveInstanceState(outState);
        outState.putBoolean(EXTRA_LOADING, isLoading);
    }

    @Override
    public void showLoad()
    {
        isLoading = true;

        final View view = getLoadView();
        if (view != null)
        {
            view.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void hideLoad()
    {
        final View view = getLoadView();
        if (view != null)
        {
            view.setVisibility(View.GONE);
        }

        isLoading = false;
    }

    @Override
    public void terminate()
    {
        finish();
    }

    protected abstract View getLoadView();

    protected void showHideLoad()
    {
        if (isLoading)
        {
            showLoad();
        }
        else
        {
            hideLoad();
        }
    }
}