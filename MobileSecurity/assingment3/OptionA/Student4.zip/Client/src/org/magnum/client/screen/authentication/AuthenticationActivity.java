package org.magnum.client.screen.authentication;

import org.magnum.client.IController;
import org.magnum.client.R;
import org.magnum.client.screen.AbstractActivity;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;

public class AuthenticationActivity extends AbstractActivity implements IController
{
    private static final String TAG_FRAGMENT = "TAG_FRAGMENT";

    private View loadOverlay;

    @Override
    protected void onCreate(Bundle saved)
    {
        super.onCreate(saved);
        setContentView(R.layout.authentication_activity);

        loadOverlay = findViewById(R.id.load_overlay);
        showHideLoad();

        final FragmentManager manager = getFragmentManager();
        final Fragment fragment = manager.findFragmentByTag(TAG_FRAGMENT);
        if (fragment == null)
        {
            final FragmentTransaction transaction = manager.beginTransaction();

            final Fragment container = AuthenticationFragment.instance();
            transaction.replace(R.id.container, container, TAG_FRAGMENT);
            transaction.commitAllowingStateLoss();
        }
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
    }

    @Override
    protected View getLoadView()
    {
        return loadOverlay;
    }
}
