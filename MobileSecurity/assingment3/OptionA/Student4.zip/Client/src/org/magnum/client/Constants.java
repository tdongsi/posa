package org.magnum.client;

public class Constants
{
    // TODO: change this IP address to be coherent with your running server
    // more information here:
    // https://github.com/juleswhite/mobilecloud-15/blob/master/ex/VideoUploadClient/README.md
    // public static final String SERVER_URL = "https://192.168.1.75:8443";
    public static final String SERVER_URL = "https://10.0.2.2:8443";

    public static final int MAX_SIZE = 50 * 1024 * 1024; // 50MB

    private Constants()
    {
        // disable instantiation
    }
}