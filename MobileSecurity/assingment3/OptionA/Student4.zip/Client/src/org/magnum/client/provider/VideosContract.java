package org.magnum.client.provider;

import android.content.ContentUris;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * This contract defines the metadata for the VideosContentProvider,
 * including the provider's access URIs and its "database" constants.
 */
public final class VideosContract
{
    /**
     * This ContentProvider's unique identifier.
     */
    public static final String CONTENT_AUTHORITY = "org.magnum.client.provider";

    /**
     * Use CONTENT_AUTHORITY to create the base of all URI's which
     * apps will use to contact the content provider.
     */
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    /**
     * Possible paths (appended to base content URI for possible
     * URI's).  For instance, content://vandy.mooc/character_table/ is
     * a valid path for looking at Character data.  Conversely,
     * content://vandy.mooc/givemeroot/ will fail, as the
     * ContentProvider hasn't been given any information on what to do
     * with "givemeroot".
     */
    public static final String PATH_VIDEOS = VideoContent.TABLE_NAME;

    /*
     * Columns
     */

    /**
     * Inner class that defines the table contents of the Videos table.
     */
    public static final class VideoContent implements BaseColumns
    {
        /**
         * Use BASE_CONTENT_URI to create the unique URI for Videos
         * Table that apps will use to contact the content provider.
         */
        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon().appendPath(PATH_VIDEOS).build();

        /**
         * When the Cursor returned for a given URI by the
         * ContentProvider contains 0..x items.
         */
        public static final String CONTENT_ITEMS_TYPE = "vnd.android.cursor.dir/" + CONTENT_AUTHORITY + "/" + PATH_VIDEOS;
            
        /**
         * When the Cursor returned for a given URI by the
         * ContentProvider contains 1 item.
         */
        public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/" + CONTENT_AUTHORITY + "/" + PATH_VIDEOS;

        /**
         * Name of the database table.
         */
        public static final String TABLE_NAME = "videos";

        /**
         * Columns to store data.
         */
        public static final String COLUMN_ID           = _ID;
        public static final String COLUMN_TITLE        = "TITLE";
        public static final String COLUMN_DURATION     = "DURATION";
        public static final String COLUMN_CONTENT_TYPE = "CONTENT_TYPE";
        public static final String COLUMN_DATA_URL     = "DATA_URL";
        public static final String COLUMN_RATING       = "RATING";
        public static final String COLUMN_VOTES        = "VOTES";

        /**
         * Return a Uri that points to the row containing a given id.
         * 
         * @param id
         * @return Uri
         */
        public static Uri buildURI(long id)
        {
            return ContentUris.withAppendedId(CONTENT_URI, id);
        }
    }

    public static final String PATH_TRACES = TraceContent.TABLE_NAME;

    /**
     * Inner class that defines the table contents of the Traces table.
     */
    public static final class TraceContent implements BaseColumns
    {
        /**
         * Use BASE_CONTENT_URI to create the unique URI for Traces
         * Table that apps will use to contact the content provider.
         */
        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon().appendPath(PATH_TRACES).build();

        /**
         * When the Cursor returned for a given URI by the
         * ContentProvider contains 0..x items.
         */
        public static final String CONTENT_ITEMS_TYPE = "vnd.android.cursor.dir/" + CONTENT_AUTHORITY + "/" + PATH_TRACES;
            
        /**
         * When the Cursor returned for a given URI by the
         * ContentProvider contains 1 item.
         */
        public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/" + CONTENT_AUTHORITY + "/" + PATH_TRACES;

        /**
         * Name of the database table.
         */
        public static final String TABLE_NAME = "traces";

        /**
         * Columns to store data.
         */
        public static final String COLUMN_ID  = _ID;
        public static final String COLUMN_URI = "URI";

        /**
         * Return a Uri that points to the row containing a given id.
         * 
         * @param id
         * @return Uri
         */
        public static Uri buildURI(long id)
        {
            return ContentUris.withAppendedId(CONTENT_URI, id);
        }
    }
}
