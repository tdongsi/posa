package org.magnum.client.service;

import java.io.File;

import org.magnum.client.controller.VideosController;
import org.magnum.client.provider.VideosResolver;
import org.magnum.client.utils.LocalStoreUtils;
import org.magnum.client.utils.SettingsUtils;

import retrofit.client.Response;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.support.v4.content.LocalBroadcastManager;

public class DownloadService extends IntentService
{
    public static final String ACTION_DOWNLOAD_ENDED   = "org.magnum.client.ACTION_DOWNLOAD_ENDED";
    public static final String DOWNLOAD_STATUS_CODE    = "org.magnum.client.DOWNLOAD_STATUS_CODE";
    public static final String DOWNLOAD_STATUS_MESSAGE = "org.magnum.client.DOWNLOAD_STATUS_MESSAGE";
    public static final String DOWNLOAD_CONTENT_URI    = "org.magnum.client.DOWNLOAD_CONTENT_URI";

    public static final int STATUS_DOWNLOAD_SUCCESS = 1;
    public static final int STATUS_DOWNLOAD_ERROR   = 2;

    /**
     * It is used by Notification Manager to send Notifications.
     */
    private static final int NOTIFICATION_ID = 20;

    /**
     * Factory method that generates the intent to call this Service.
     */
    public static Intent intent(Context context, long videoID)
    {
        final Intent intent = new Intent(context, DownloadService.class);
        intent.putExtra("VIDEO_ID", videoID);
        return intent;
    }

    public DownloadService()
    {
        super("DownloadService");
    }

    @Override
    protected void onHandleIntent(Intent intent)
    {
        if (intent == null) return;

        try
        {
            final long videoID = intent.getLongExtra("VIDEO_ID", -1);
            handleVideoDownload(videoID);
        }
        catch (Exception e)
        {
            final Context context = getApplicationContext();

            informDownloadStopped(context, "Download Failed", "");
            sendBroadcast(context, STATUS_DOWNLOAD_ERROR, "Download Failed", null);
        }
    }

    /**
     * Download video file handle method.
     */
    private void handleVideoDownload(final long videoID)
    {
        final Context context = getApplicationContext();
        createNotification(context, "Downloading File", "Video ID: " + videoID);

        final String username = SettingsUtils.loadUsername(context, "");
        final String password = SettingsUtils.loadPassword(context, "");

        final VideosController controller = new VideosController(username, password);

        final Response response = controller.getVideoContent(videoID);
        if (response.getStatus() == 200)
        {
            final File file = LocalStoreUtils.storeVideoInExternalDirectory(context, response, "video_" + videoID + ".mp4");
            if (file == null)
            {
                informDownloadStopped(context, "Download Failed", "Video ID: " + videoID);
                sendBroadcast(context, STATUS_DOWNLOAD_ERROR, "Download Failed", null);
            }
            else
            {
                // finishNotification(context, "Download Success", "");
                // sendBroadcast(context, STATUS_DOWNLOAD_SUCCESS, "Download Success", file.getAbsolutePath());

                MediaScannerConnection.scanFile(context, new String[] { file.toString() }, null, new MediaScannerConnection.OnScanCompletedListener()
                {
                    public void onScanCompleted(String path, Uri videoURI)
                    {
                        // save the video URI trace to skip its download in future
                        final ContentResolver resolver = getContentResolver();
                        VideosResolver.addTrace(resolver, videoID, videoURI);

                        informDownloadStopped(context, "Download Success", "Video ID: " + videoID);
                        sendBroadcast(context, STATUS_DOWNLOAD_SUCCESS, "Download Success", videoURI);
                    }
                });
            }
        }
        else
        {
            informDownloadStopped(context, "Download Failed", "Video ID: " + videoID);
            sendBroadcast(context, STATUS_DOWNLOAD_ERROR, "Download Failed", null);
        }
    }

    /**
     * Starts the Notification to show the progress of video upload.
     */
    private void createNotification(Context context, String title, String text)
    {
        final NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        final Notification.Builder builder = new Notification.Builder(context);
        builder.setContentTitle(title);
        builder.setContentText(text);
        builder.setSmallIcon(android.R.drawable.stat_sys_download);
        builder.setProgress(0, 100, true);

        manager.notify(NOTIFICATION_ID, builder.build());
    }

    /**
     * Finish the Notification after the Video is Uploaded.
     */
    private void informDownloadStopped(Context context, String title, String text)
    {
        final NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        final Notification.Builder builder = new Notification.Builder(context);
        builder.setContentTitle(title);
        builder.setContentText(text);
        builder.setSmallIcon(android.R.drawable.stat_sys_download_done);
        builder.setProgress(0, 100, false);

        manager.notify(NOTIFICATION_ID, builder.build());
    }

    /**
     * Send the Broadcast to Activity that the Video Upload is completed.
     */
    private void sendBroadcast(Context context, int status, String message, Uri contentURI)
    {
        final LocalBroadcastManager manager = LocalBroadcastManager.getInstance(context);

        final Intent intent = new Intent(ACTION_DOWNLOAD_ENDED);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.putExtra(DOWNLOAD_STATUS_CODE, status);
        intent.putExtra(DOWNLOAD_STATUS_MESSAGE, message);
        intent.putExtra(DOWNLOAD_CONTENT_URI, contentURI);

        manager.sendBroadcast(intent);
    }
}
