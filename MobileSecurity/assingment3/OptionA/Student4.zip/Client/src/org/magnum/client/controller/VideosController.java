package org.magnum.client.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.magnum.client.Constants;
import org.magnum.client.model.AverageVideoRating;
import org.magnum.client.model.Video;
import org.magnum.client.model.VideoStatus;
import org.magnum.client.network.SecuredRestBuilder;
import org.magnum.client.network.UnsafeHttpsClient;

import retrofit.RestAdapter;
import retrofit.client.Client;
import retrofit.client.OkClient;
import retrofit.client.Response;
import retrofit.mime.TypedFile;

public class VideosController
{
    private VideosServiceAPI videosAPI;

    public VideosController(String username, String password)
    {
        super();

        final Client client = new OkClient(UnsafeHttpsClient.getUnsafeOkHttpClient());
        
        final SecuredRestBuilder builder = new SecuredRestBuilder();
        builder.setLoginEndpoint(Constants.SERVER_URL + "/oauth/token");
        builder.setUsername(username);
        builder.setPassword(password);
        builder.setClientId("mobile");
        builder.setClient(client);
        builder.setEndpoint(Constants.SERVER_URL);

        final RestAdapter adapter = builder.build();
        adapter.setLogLevel(RestAdapter.LogLevel.BASIC);
        videosAPI = adapter.create(VideosServiceAPI.class);
    }

    public Response validate()
    {
        Response result = null;

        if (videosAPI != null)
        {
            result = videosAPI.validate();
        }

        return result;
    }

    public List<Video> getVideos()
    {
        final List<Video> videos = new ArrayList<Video>();
        if (videosAPI != null)
        {
            final Collection<Video> items = videosAPI.getVideos();
            videos.addAll(items);
        }
        return videos;
    }

    public Video getVideo(long videoID)
    {
        return videosAPI.getVideo(videoID);
    }

    public Video setVideo(Video video)
    {
        Video result = null;

        if (videosAPI != null)
        {
            result = videosAPI.setVideo(video);
        }

        return result;
    }

    public VideoStatus setVideoContent(long videoID, TypedFile file)
    {
        VideoStatus result = null;

        if (videosAPI != null)
        {
            result = videosAPI.setVideoContent(videoID, file);
        }

        return result;
    }

    public Response getVideoContent(long videoID)
    {
        Response result = null;

        if (videosAPI != null)
        {
            result = videosAPI.getVideotContent(videoID);
        }

        return result;
    }

    public AverageVideoRating rateVideo(long videoID, double rate)
    {
        AverageVideoRating result = null;

        if (videosAPI != null)
        {
            result = videosAPI.rateVideo(videoID, rate);
        }

        return result;
    }
}
