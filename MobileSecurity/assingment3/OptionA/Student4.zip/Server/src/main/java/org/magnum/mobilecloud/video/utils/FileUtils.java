package org.magnum.mobilecloud.video.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.magnum.mobilecloud.video.controller.VideoFileManager;
import org.magnum.mobilecloud.video.model.Video;

public class FileUtils
{
    public static boolean hasVideoContent(VideoFileManager manager, Video video) throws IOException
    {
        return manager.hasVideoData(video);
    }

    public static void saveVideoContent(VideoFileManager manager, Video video, InputStream stream) throws IOException
    {
        manager.saveVideoData(video, stream);
    }

    public static void loadVideoContent(VideoFileManager manager, Video video, OutputStream stream) throws IOException
    {
        manager.copyVideoData(video, stream);
    }
}
