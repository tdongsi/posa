package org.magnum.mobilecloud.video.repository;

import org.magnum.mobilecloud.video.model.UserVideoRating;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RatingsRepository extends CrudRepository<UserVideoRating, Long>
{
    public Iterable<UserVideoRating> findByVideoId(long videoID);

    public UserVideoRating findByVideoIdAndUser(long videoID, String name);
}
