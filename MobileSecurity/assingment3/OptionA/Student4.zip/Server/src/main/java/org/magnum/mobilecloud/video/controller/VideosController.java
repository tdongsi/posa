package org.magnum.mobilecloud.video.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.model.AverageVideoRating;
import org.magnum.mobilecloud.video.model.UserVideoRating;
import org.magnum.mobilecloud.video.model.Video;
import org.magnum.mobilecloud.video.model.VideoStatus;
import org.magnum.mobilecloud.video.model.VideoStatus.VideoState;
import org.magnum.mobilecloud.video.repository.RatingsRepository;
import org.magnum.mobilecloud.video.repository.VideosRepository;
import org.magnum.mobilecloud.video.utils.FileUtils;
import org.magnum.mobilecloud.video.utils.HostUtils;
import org.magnum.mobilecloud.video.utils.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class VideosController
{
    @Autowired
    private VideoFileManager manager;

    @Autowired
    private VideosRepository videos;

    @Autowired
    private RatingsRepository ratings;

    //
    // Get All Videos
    //

    @RequestMapping(value = "/video", method = RequestMethod.GET)
    @ResponseBody
    public Collection<Video> getVideos(HttpServletRequest request)
    {
        final List<Video> result = new ArrayList<>();

        final Iterable<Video> iterable = videos.findAll();
        if (iterable != null)
        {
            for (Video video : iterable)
            {
                updateWithRatingAndDataURL(request, video);
                result.add(video);
            }
        }

        return result;
    }

    //
    // Get One Video (by ID)
    //

    @RequestMapping(value = "/video/{id}", method = RequestMethod.GET)
    @ResponseBody
    public Video getVideo(@PathVariable("id") long videoID, HttpServletRequest request, HttpServletResponse response)
    {
        final Video result = videos.findOne(videoID);
        if (result == null)
        {
            sendError(response, HttpServletResponse.SC_NOT_FOUND, "Video not found");
        }
        else
        {
            updateWithRatingAndDataURL(request, result);
        }
        return result;
    }

    //
    // Add/Update Video Metadata
    //

    @RequestMapping(value = "/video", method = RequestMethod.POST)
    @ResponseBody
    public Video setVideo(@RequestBody Video video, HttpServletRequest request, HttpServletResponse response, Principal principal)
    {
        if (video == null)
        {
            // sanity check
            sendError(response, HttpServletResponse.SC_BAD_REQUEST, "Video not provided");
        }
        else
        {
            final String name = principal.getName();
            if (TextUtils.isNullOrEmpty(name))
            {
                // sanity check
                sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Null/Empty user name");
            }
            else
            {
                final long videoID = video.getId();
                final Video stored = videos.findOne(videoID);
                if (stored != null)
                {
                    final String owner = stored.getOwner();
                    if (TextUtils.areEqual(name, owner))
                    {
                        // update video record
                        video.setOwner(name);
                        video = videos.save(video);
                        updateWithRatingAndDataURL(request, video);
                    }
                    else
                    {
                        // owner mismatch
                        sendError(response, HttpServletResponse.SC_FORBIDDEN, "Invalid owner");
                    }
                }
                else
                {
                    // create video record
                    video.setOwner(name);
                    video = videos.save(video);
                    updateWithRatingAndDataURL(request, video);
                }
            }
        }

        return video;
    }

    //
    // Set Video Data/Content
    //

    @RequestMapping(value = "/video/{id}/data", method = RequestMethod.POST)
    @ResponseBody
    public VideoStatus setVideoContent(@PathVariable("id") long videoID, @RequestParam("data") MultipartFile file, HttpServletResponse response, Principal principal)
    {
        VideoStatus status = null;

        if (file == null)
        {
            // sanity check
            sendError(response, HttpServletResponse.SC_BAD_REQUEST, "Missing video data file");
        }
        else
        {
            final long size = file.getSize();
            if (size > 0L)
            {
                final Video video = videos.findOne(videoID);
                if (video == null)
                {
                    sendError(response, HttpServletResponse.SC_NOT_FOUND, "Video not found");
                }
                else
                {
                    final String name = principal.getName();
                    if (TextUtils.isNullOrEmpty(name))
                    {
                        // sanity check
                        sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Null/Empty user name");
                    }
                    else
                    {
                        final String owner = video.getOwner();
                        if (TextUtils.areEqual(name, owner))
                        {
                            try
                            {
                                // update video data
                                final InputStream stream = file.getInputStream();
                                FileUtils.saveVideoContent(manager, video, stream);
                                status = new VideoStatus(VideoState.READY);
                            }
                            catch (Exception e)
                            {
                                sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An internal error occurred");
                            }
                        }
                        else
                        {
                            // owner mismatch
                            sendError(response, HttpServletResponse.SC_FORBIDDEN, "Invalid video owner");
                        }
                    }
                }
            }
            else
            {
                sendError(response, HttpServletResponse.SC_BAD_REQUEST, "Empty data file");
            }
        }

        return status;
    }

    //
    // Get Video Data/Content
    //

    @RequestMapping(value = "/video/{id}/data", method = RequestMethod.GET)
    public void getVideoContent(@PathVariable("id") long videoID, HttpServletResponse response)
    {
        try
        {
            final Video video = videos.findOne(videoID);
            if (video == null)
            {
                // sanity check
                sendError(response, HttpServletResponse.SC_NOT_FOUND, "Video not found");
            }
            else
            {
                if (FileUtils.hasVideoContent(manager, video))
                {
                    final String contentType = video.getContentType();
                    response.setContentType(contentType);

                    final OutputStream stream = response.getOutputStream();
                    FileUtils.loadVideoContent(manager, video, stream);
                    response.flushBuffer();
                }
                else
                {
                    sendError(response, HttpServletResponse.SC_NOT_FOUND, "Video data not found");
                }
            }
        }
        catch (Exception e)
        {
            sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An internal error occurred");
        }
    }

    //
    // Set Video Rating
    //

    @RequestMapping(value = "/video/{id}/rating/{rating}", method = RequestMethod.POST)
    @ResponseBody
    public AverageVideoRating setVideoRating(@PathVariable("id") long videoID, @PathVariable("rating") double value, HttpServletResponse response, Principal principal)
    {
        AverageVideoRating result = null;

        final Video video = videos.findOne(videoID);
        if (video == null)
        {
            sendError(response, HttpServletResponse.SC_NOT_FOUND, "Video not found");
        }
        else
        {
            final String name = principal.getName();
            if (TextUtils.isNullOrEmpty(name))
            {
                // sanity check
                sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Null/Empty user name");
            }
            else
            {
                UserVideoRating rating = ratings.findByVideoIdAndUser(videoID, name);
                if (rating == null)
                {
                    // create user rating record
                    rating = new UserVideoRating(videoID, value, name);
                    ratings.save(rating);
                }
                else
                {
                    // update user rating record
                    rating.setRating(value);
                    ratings.save(rating);
                }

                // update the result
                result = getAverageVideoRating(videoID);
            }
        }

        return result;
    }

    //
    // Get Video Rating
    //

    @RequestMapping(value = "/video/{id}/rating", method = RequestMethod.GET)
    @ResponseBody
    public AverageVideoRating getVideoRating(@PathVariable("id") long videoID, HttpServletResponse response)
    {
        final AverageVideoRating result = getAverageVideoRating(videoID);
        if (result == null)
        {
            sendError(response, HttpServletResponse.SC_NOT_FOUND, "Video rating not found");
        }
        return result;
    }

    //
    // Validate Credentials
    //

    @RequestMapping(value = "/validate", method = RequestMethod.GET)
    public void validate(HttpServletResponse response)
    {
        // if we reach this point we have managed to authenticate via OAuth2
        setStatus(response, HttpServletResponse.SC_OK);
    }

    //
    // internal helper methods
    //

    private AverageVideoRating getAverageVideoRating(long videoID)
    {
        AverageVideoRating result = null;

        final Iterable<UserVideoRating> iterable = ratings.findByVideoId(videoID);
        if (iterable != null)
        {
            int    counter = 0;
            double average = 0;

            for (UserVideoRating rating : iterable)
            {
                average += rating.getRating();
                counter += 1;
            }

            if (counter < 1)
            {
                result = new AverageVideoRating(0, videoID, 0);
            }
            else
            {
                average = average / counter;
                result = new AverageVideoRating(average, videoID, counter);
            }
        }

        return result;
    }

    private void updateWithRatingAndDataURL(HttpServletRequest request, Video video)
    {
        if (video != null)
        {
            final long videoID = video.getId();

            // enrich with rating value
            final AverageVideoRating rating = getAverageVideoRating(videoID);
            final double value = (rating == null) ? 0 : rating.getRating();
            final long   votes = (rating == null) ? 0 : rating.getTotalRatings();
            video.setRating(value);
            video.setVotes(votes);

            // enrich with data URL
            final String dataURL = HostUtils.getVideoURL(videoID, request);
            video.setDataURL(dataURL);
        }
    }

    private void sendError(HttpServletResponse response, int statusCode, String message)
    {
        try
        {
            if (response != null)
            {
                response.sendError(statusCode, message);
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private void setStatus(HttpServletResponse response, int statusCode)
    {
        if (response != null)
        {
            response.setStatus(statusCode);
        }
    }
}
