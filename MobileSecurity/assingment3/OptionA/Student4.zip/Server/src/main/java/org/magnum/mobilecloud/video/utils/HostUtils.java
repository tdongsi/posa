package org.magnum.mobilecloud.video.utils;

import javax.servlet.http.HttpServletRequest;

public class HostUtils
{
    public static String getVideoURL(long videoID, HttpServletRequest request)
    {
        return getVideoHostURL(request) + "/video/" + videoID + "/data";
    }

    private static String getVideoHostURL(HttpServletRequest request)
    {
        final StringBuilder builder = new StringBuilder();
        if (request != null)
        {
            builder.append(request.getScheme());
            builder.append("://");
            builder.append(request.getServerName());
            builder.append(":");
            builder.append(request.getServerPort());
        }
        return builder.toString();
    }
}
