package org.magnum.mobilecloud.video.utils;

public class TextUtils
{
    private TextUtils()
    {
        // do nothing
    }

    public static boolean isNullOrEmpty(String text)
    {
        boolean flag = false;
        if (text != null)
        {
            text = text.trim();
            flag = text.isEmpty();
        }
        return flag;
    }

    public static boolean areEqual(String text1, String text2)
    {
        boolean result = false;
        if (text1 == null)
        {
            if (text2 == null)
            {
                result = true;
            }
            else
            {
                result = false;
            }
        }
        else
        {
            if (text2 == null)
            {
                result = false;
            }
            else
            {
                final int value = text1.compareTo(text2);
                result = (value == 0);
            }
        }
        return result;
    }
}
