package org.magnum.dataup;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class VideoSvcHelper {

	/**
	 * An id-generator for assigning unique id for each uploaded video in
	 * VideoSvc
	 */
	private static final AtomicLong currentId = new AtomicLong(0L);
    static Map<Long, List<Double>> idRatings = new HashMap<Long, List<Double>>();

	/**
	 * Atomically increment the last video id and return new id.
	 * 
	 * @return
	 */
	public static long getNextId() {
		return currentId.incrementAndGet();
	}

	/**
	 * Generate a data URL from videoID. The URL is a complete URL of the form
	 * http://localhost:8080/video/<videoid>/data or
	 * http://<servername>/video/<videoid>/data
	 * 
	 * @param videoId
	 * @return
	 */
	public static String getDataUrl(long videoId) {
        String url = "http://192.168.43.106:8080" + VideoSvcApi.VIDEO_SVC_PATH + "/" + videoId + "/data";
        return url;
	}

    private static String getUrlBaseForLocalServer() {
        HttpServletRequest request = 
            ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String base = 
           "http://"+request.getServerName() 
           + ((request.getServerPort() != 80) ? ":"+request.getServerPort() : "");
        return base;
     }
    
    public static double calculateAvgRating(long id, double rating) {
    	if (rating <= 0)
    		return 0;
    	idRatings.get(id).add(rating);
    	double sum = 0;
    	for (double r : idRatings.get(id))
    		sum += r;
    	
    	return sum / idRatings.get(id).size();
    }
}
