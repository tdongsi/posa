package org.magnum.dataup;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;











import javax.servlet.http.HttpServletResponse;

import org.magnum.dataup.model.Video;
import org.magnum.dataup.model.VideoStatus;
import org.magnum.dataup.model.VideoStatus.VideoState;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MultipartFile;


@Controller
public class VideoSvc {

    private Map<Long,Video> videos = new HashMap<Long, Video>();
    private VideoFileManager videodataManager;

	@ExceptionHandler(IOException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	void handleException(IOException e) {
	}

	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video v) {
		long id = VideoSvcHelper.getNextId();
		v.setId(id);
		v.setDataUrl(VideoSvcHelper.getDataUrl(id));
		v.setAvgRating(0);
		videos.put(id, v);
		return v;
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList() {
		return videos.values();
	}

	@RequestMapping(value=VideoSvcApi.VIDEO_DATA_PATH, method=RequestMethod.POST)
	public @ResponseBody VideoStatus setVideoData(@PathVariable(VideoSvcApi.ID_PARAMETER) long id,
							@RequestParam(VideoSvcApi.DATA_PARAMETER) MultipartFile videoData)
							 throws IOException {
			InputStream in = videoData.getInputStream();
			Video v = videos.get(id);
			if (null == v) {
				throw new IOException();
			}
			videodataManager = VideoFileManager.get();
			videodataManager.saveVideoData(v, in);
			VideoStatus vs = new VideoStatus(VideoState.READY);
		return vs;
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_DATA_PATH, method=RequestMethod.GET)
	public HttpServletResponse getData(@PathVariable(VideoSvcApi.ID_PARAMETER) long id, 
						HttpServletResponse response) throws IOException {
		Video v = videos.get(id);
		if (null == v) {
			throw new IOException();
		}
		else {
			videodataManager = VideoFileManager.get();
			OutputStream out = response.getOutputStream();
			videodataManager.copyVideoData(v, out);
		}
		return response;
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_RATING_PATH, method=RequestMethod.POST)
	public @ResponseBody double rateVideo(@PathVariable(VideoSvcApi.ID_PARAMETER) long id, 
										@RequestBody double rating,
										HttpServletResponse r) {
		Video v = videos.get(id);
		if (null != v) {
			if (v.getAvgRating() <= 0) {
				//not rating for this video exists yet, 
				//this rating is the only one => put directly into avgRating
				if (rating <= 0)
					return 0;
				v.setAvgRating(rating);
				//initiating List<Long> for Map<Long, List<Long>>
				List<Double> ratings = new ArrayList<Double>();
				ratings.add(rating);
				VideoSvcHelper.idRatings.put(id, ratings);
			}	 
			else 
				//at least 1 rating already available => calculate avgRating
				v.setAvgRating(VideoSvcHelper.calculateAvgRating(id, rating));

			return v.getAvgRating();
		}
		else {
			r.setStatus(404);;
			return 0;
		}
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_RATING_PATH, method=RequestMethod.GET)
	public @ResponseBody double getAvgRating(@PathVariable long id) {
		return videos.get(id).getAvgRating();
	}
}
