package org.magnum.dataup.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fluentinterface.ReflectionBuilder;
import com.fluentinterface.builder.Builder;

public class VideoStars {
	
	public static VideoStarsBuilder create() {
		return ReflectionBuilder.implementationFor(VideoStarsBuilder.class).create();
	}
	
	public interface VideoStarsBuilder extends Builder<VideoStars> {
		public VideoStarsBuilder withAvarageStars(float averageStar);
		public VideoStarsBuilder withStars(long stars);
		public VideoStarsBuilder withCount(long count);
	}
	
	private long id;
	private float averageStars;
	
	@JsonIgnore
	private long stars;
	
	@JsonIgnore
	private long count;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getStars() {
		return stars;
	}
	public void setStars(long stars) {
		this.stars = stars;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public float getAverageStars() {
		return averageStars;
	}
	public void setAverageStars(float averagestars) {
		this.averageStars = averagestars;
	}
	
}
