package org.magnum.dataup;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletResponse;

import org.magnum.dataup.model.Video;
import org.magnum.dataup.model.VideoStars;
import org.magnum.dataup.model.VideoStatus;
import org.magnum.dataup.model.VideoStatus.VideoState;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class VideoController {
	
	private Map<Long, Video> videoMap = new ConcurrentHashMap<Long, Video>();
	private Map<Long, VideoStars> videoStarsMap = new ConcurrentHashMap<Long, VideoStars>();
	
	private static final AtomicLong currentId = new AtomicLong();
	
	@RequestMapping(value = "/video", method=RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video video)
	{
		if (video.getId() == 0)
		{
			video.setId(currentId.incrementAndGet());
		}
		long id = video.getId();
		
		video.setDataUrl("/video/"+video.getId());
		videoMap.put(id, video);
		
		VideoStars videoStars = new VideoStars();
		videoStars.setId(id);
		
		videoStarsMap.put(id, videoStars);
		return video;
	}
	
	@RequestMapping(value = "/video", method=RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList()
	{
		return videoMap.values();
	}
	
	@RequestMapping(value = "/video/{id}/star", method=RequestMethod.GET)
	public @ResponseBody VideoStars getVideoStars(@PathVariable long id, HttpServletResponse response)
	{
		//System.out.println("Mapped "+id+" get "+new Date(System.currentTimeMillis()));
		if (id <= 0 || videoStarsMap.get(id) == null) 
		{
			response.setStatus(404);
			return null;
		}		
		VideoStars videoStars = videoStarsMap.get(id);
		return videoStars;
	}
	
	@RequestMapping(value = "/video/{id}/star", method=RequestMethod.POST)
	public @ResponseBody VideoStars setVideoStars(@RequestBody VideoStars videoStars, HttpServletResponse response)
	{
		//System.out.println("Mapped "+videoStars.getId()+" set "+new Date(System.currentTimeMillis()));
		long id = videoStars.getId();
		if (id <= 0 || videoStarsMap.get(id) == null) 
		{
			response.setStatus(404);
			return null;
		}
		VideoStars videoStarsData = videoStarsMap.get(id);
		videoStarsData.setCount(videoStarsData.getCount() + 1);
		videoStarsData.setStars(videoStarsData.getStars() + (long) videoStars.getAverageStars());
		videoStarsData.setAverageStars((float) videoStarsData.getStars() / videoStarsData.getCount());
		videoStarsMap.put(id, videoStarsData);
		return videoStarsData;
	}
	
	@RequestMapping(value = "/video/{id}/data", method=RequestMethod.GET, produces = "application/xml")
	public @ResponseBody void getVideoData(@PathVariable long id, HttpServletResponse response) throws IOException
	{
		if (id <= 0 || videoMap.get(id) == null) 
		{
			response.setStatus(404);
			return;
		}
		
		String name = "File"+id;
		
		FileInputStream input = new FileInputStream(new File(name));
		
		response.setContentType("video/mpeg");
		OutputStream output = response.getOutputStream();
		
		byte[] bytes = new byte[input.available()];
		input.read(bytes);
       
		output.write(bytes);
		output.flush();
		output.close();
		input.close();
	}
	
	@RequestMapping(value = "/video/{id}/data", method=RequestMethod.POST)
	public @ResponseBody VideoStatus postVideoData(@PathVariable long id, @RequestParam("data") MultipartFile videoData, HttpServletResponse response) throws IOException
	{
		if (id <= 0 || videoMap.get(id) == null) 
		{
			response.setContentType("text/html");
			response.setStatus(404);
			return null;
		}
		String name = "File"+id;
		
		if (!videoData.isEmpty()) {
            try {
                byte[] bytes = videoData.getBytes();
                BufferedOutputStream stream =
                        new BufferedOutputStream(new FileOutputStream(new File(name)));
                stream.write(bytes);
                stream.close();
                return new VideoStatus(VideoState.READY);
            } catch (Exception e) {
            	response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return null;
            }
        } else {
        	response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return null;
        }
	}
}
