package vandy.mooc.view;

import java.io.File;

import vandy.mooc.R;
import vandy.mooc.common.LifecycleLoggingActivity;
import vandy.mooc.common.Utils;
import vandy.mooc.model.mediator.VideoDataMediator;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.model.services.DownloadVideoService;
import vandy.mooc.view.ui.FloatingActionButton;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.TextView;

public class VideoMetadataActivity extends LifecycleLoggingActivity {

	TextView mTitleView;
	
	TextView mDurationView;
	
	RatingBar mVideoRatingBar;
	
	FloatingActionButton mPlayVideo;
	
	Video mVideo;
	
	boolean gettingVideoRating = false;
	
	/**
     * The Broadcast Receiver that registers itself to receive the
     * result from DownloadVideoService when a video download completes.
     */
    private DownloadResultReceiver mDownloadResultReceiver;
	
	/**
     * Hook method called when a new instance of Activity is created.
     * One time initialization code goes here, e.g., storing Views.
     * 
     * @param Bundle
     *            object that contains saved state information.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	
    	Intent intent = getIntent();
    	
    	mVideo = new Video();
    	mVideo.setId(intent.getLongExtra("Id", 0));
    	mVideo.setTitle(intent.getStringExtra("Title"));
    	mVideo.setDuration(intent.getLongExtra("Duration",0));
    	mVideo.setDataUrl(intent.getStringExtra("DataUrl"));
    	
    	// Initialize the default layout.
        setContentView(R.layout.video_metadata_activity);
        
        mTitleView = (TextView) findViewById(R.id.titleView);
        mTitleView.setText("Title: "+mVideo.getTitle());
        
        mDurationView = (TextView) findViewById(R.id.durationView);
        mDurationView.setText("Duration: "+mVideo.getDuration());
        
        mVideoRatingBar = (RatingBar) findViewById(R.id.videoRatingBar);
        mVideoRatingBar.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
			@Override
			public void onRatingChanged(RatingBar ratingBar, float rating,
					boolean fromUser) {
				if (!gettingVideoRating)
				{
					gettingVideoRating = true;
					mVideoRatingBar.setIsIndicator(gettingVideoRating);
					rateVideo(rating, fromUser);
				}
			}
		});
        
        mPlayVideo = (FloatingActionButton) findViewById(R.id.playVideoButton);
        mPlayVideo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				downloadAndPlay();				
			}
		});
        
        
        mDownloadResultReceiver =
                new DownloadResultReceiver();
        
        gettingVideoRating = true;
        mVideoRatingBar.setIsIndicator(gettingVideoRating);
        getVideoRating(mVideo.getId());
    }

	/**
     *  Hook method that is called when user resumes activity
     *  from paused state, onPause(). 
     */
    @Override
    protected void onResume() {
        // Call up to the superclass.
        super.onResume();

        // Register BroadcastReceiver that receives result from
        // UploadVideoService when a video upload completes.
        registerReceiver();
    }
    
    /**
     * Hook method that gives a final chance to release resources and
     * stop spawned threads.  onDestroy() may not always be
     * called-when system kills hosting process.
     */
    @Override
    protected void onPause() {
        // Call onPause() in superclass.
        super.onPause();
        
        // Unregister BroadcastReceiver.
        
        LocalBroadcastManager.getInstance(this)
          .unregisterReceiver(mDownloadResultReceiver);
    }
    
    /**
     * The Broadcast Receiver that registers itself to receive result
     * from UploadVideoService.
     */
    private class DownloadResultReceiver 
            extends BroadcastReceiver {
        /**
         * Hook method that's dispatched when the DownloadService has
         * download the Video.
         */
        @Override
        public void onReceive(Context context,
                              Intent intent) {
        	long id = intent.getLongExtra("id", 0);
        	Log.d(TAG, "Id received from "+id);
        	
        	setVideoUrl(id);
        	
        	mVideo.setDataUrl(Utils.generateFileName(id));
        	
        	if (id != 0)
        		playVideo();
        	
        }
    }
    
    public void setVideoUrl(final long id)
    {
    	Log.d(TAG, "Setting video url "+id);
    	final Context context = this;
    	
    	AsyncTask<Object, Object, Integer> task = new AsyncTask<Object, Object, Integer>() {

			@Override
			protected Integer doInBackground(Object... params) {
				Log.d(TAG, "Setting video url doInBackground");
				VideoDataMediator videoDataMediator = new VideoDataMediator();
				return videoDataMediator.setVideoUrl(context, id);
			}    		
		};
		
		task.execute("");
    }
    
 
    public void playVideo()
    {
    	Intent intent = new Intent(android.content.Intent.ACTION_VIEW);
    	Uri data = Uri.parse(mVideo.getDataUrl());
		Log.d(TAG, "Playing video "+data.toString());        
        intent.setDataAndType(data, "video/*");
        startActivity(intent);
    }
    
    public void rateVideo(final float rating, final boolean fromUser) {
    	Log.d(TAG, "Setting video rating "+rating);
    	
    	AsyncTask<Object, Object, Float> task = new AsyncTask<Object, Object, Float>() {
    		
    		@Override
			protected Float doInBackground(Object... params) {
    			Log.d(TAG, "doInBackground setting video rating");
				VideoDataMediator videoDataMediator = new VideoDataMediator();
				return videoDataMediator.setRating(mVideo.getId(), rating);
			}
    		
    		@Override
    		protected void onPostExecute(Float result) {
    			Log.d(TAG, "onPostExecute getting video rating");
    			mVideoRatingBar.setRating(result);
    			gettingVideoRating = false;
    			mVideoRatingBar.setIsIndicator(gettingVideoRating);
    			super.onPostExecute(result);
    		}
    	};
    	
    	task.execute("");
	}
    
    public void getVideoRating(final long id)
    {
    	Log.d(TAG, "Getting video rating");
    	AsyncTask<Object, Object, Float> task = new AsyncTask<Object, Object, Float>() {
    		
    		@Override
			protected Float doInBackground(Object... params) {
    			Log.d(TAG, "doInBackground getting video rating");
    			VideoDataMediator videoDataMediator = new VideoDataMediator();
				return videoDataMediator.getRating(mVideo.getId());
			}
    		
    		@Override
    		protected void onPostExecute(Float result) {
    			Log.d(TAG, "onPostExecute getting video rating");
    			mVideoRatingBar.setRating(result);
    			gettingVideoRating = false;
    			mVideoRatingBar.setIsIndicator(gettingVideoRating);
    			super.onPostExecute(result);
    		}
    	};
    	
    	task.execute("");
    }
    
    private boolean checkVideoNotExistLocaly(Video video)
    {
//    	String fileName = generateFileName(video.getId());			
//		File file = new File(fileName);
//		
//		Log.d(TAG, "Checking if video exist " + fileName);
//		
//    	return !file.exists();
    	return (video.getDataUrl().equals("") || !new File(video.getDataUrl()).exists());
    }
    
    private void downloadAndPlay() {    	
    	//if dataUrl not null then data exist locally. Checking if exist.
    	if (checkVideoNotExistLocaly(mVideo))
    	{
    		Utils.showToast(this, "Downloading video "+mVideo.getTitle());
    		downloadVideo(mVideo);
    	}
    	else
    	{
    		//Have file path from content provider and file exist
    		playVideo();
    	}
        
	}
    
	public void downloadVideo(Video video) {
		// Sends an Intent command to the DownloadVideoService.
		startService
			(DownloadVideoService.makeIntent
					(this, video.getId()));
	}
    
    private void registerReceiver()
    {
        // Create an Intent filter that handles Intents from the
        // DownloadVideoService.
        IntentFilter intentFilterDownload =
            new IntentFilter(DownloadVideoService.ACTION_DOWNLOAD_SERVICE_RESPONSE);
        intentFilterDownload.addCategory(Intent.CATEGORY_DEFAULT);

        // Register the BroadcastReceiver.
        LocalBroadcastManager.getInstance(this)
               .registerReceiver(mDownloadResultReceiver,
            		   intentFilterDownload);
    }
}
