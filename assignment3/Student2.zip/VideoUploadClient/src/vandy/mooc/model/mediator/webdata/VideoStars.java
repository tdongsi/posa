package vandy.mooc.model.mediator.webdata;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class VideoStars {
	
	private long id;
	private float averageStars;
	
	public VideoStars()
	{
		
	}
	
	public VideoStars(long id, float averageStars) {
		super();
		this.id = id;
		this.averageStars = averageStars;
	}

	public VideoStars(long id, float averageStars, long stars, long count) {
		super();
		this.id = id;
		this.averageStars = averageStars;
		this.stars = stars;
		this.count = count;
	}

	@JsonIgnore
	private long stars;
	
	@JsonIgnore
	private long count;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getStars() {
		return stars;
	}
	public void setStars(long stars) {
		this.stars = stars;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public float getAverageStars() {
		return averageStars;
	}
	public void setAverageStars(float averagestars) {
		this.averageStars = averagestars;
	}
	
}
