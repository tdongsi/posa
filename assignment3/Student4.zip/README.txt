Attached are assignment3_WFC.zip file. It contains two projects in two
folders for Eclipse IDE. 

VideoGramWFC is Android app project. You need to import it as
Existing Android Code into Workspace.
The code is default configured SERVER_URL="http://10.0.2.2:8080" to run with an emulator.

VideoServiceWFC is a Video Server Gradle project. You need to import it as Gradle Project. 

You need to run Application in VideoServiceWFC as Java application first before 
run VideoGramWFC Android app.

The emulator recorded simulation video can play back on the emulator.

Please read the README.md files in both folders for more detail.

Thank you in advance for spend your valuable time to evaluate my projects.