/**
 *  VideoPlayActivity
 *  @author WFC 2015-07-12
 */
package vandy.mooc.view;

import vandy.mooc.R;
import vandy.mooc.common.GenericActivity;
import vandy.mooc.model.services.DownloadVideoService;
import vandy.mooc.presenter.VideoPlayOps;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.TextView;
import android.widget.VideoView;

/**
 * This Activity can be used download a selected video from a Video
 * Service. User can play a selected video.
 * It extends GenericActivity that provides a framework for
 * automatically handling runtime configuration changes of an
 * VideoPlayOps object, which plays the role of the "Presenter" in
 * the MVP pattern.  The VideoPlayOps.View interface is used to minimize
 * dependencies between the View and Presenter layers.
 */
public class VideoPlayActivity 
       extends GenericActivity<VideoPlayOps.View, VideoPlayOps>  implements  VideoPlayOps.View   {
    /**
     * The Broadcast Receiver that registers itself to receive the
     * result from UploadVideoService when a video upload completes.
     */
    private DownloadResultReceiver mDownloadResultReceiver;

	private long		mVideoId;
    private String		mVideoTitle;
    private TextView	mVideoTitleTextView;
    private Button		mDownloadBtn;
    private Button		mPlayBtn;
    private RatingBar	mRatingBar; 
//    private VideoView	mVideoView;
//    private MediaController mMediaController;
    /**
     * Hook method called when a new instance of Activity is created.
     * One time initialization code goes here, e.g., storing Views.
     * 
     * @param Bundle
     *            object that contains saved state information.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Initialize the default layout.
        setContentView(R.layout.video_play_activity);
        // mVideoView			= (VideoView) findViewById( R.id.videoView);
        mVideoTitleTextView = (TextView) findViewById(R.id.video_title);
        mDownloadBtn		= (Button) findViewById(R.id.button_download);
        mPlayBtn			= (Button) findViewById(R.id.button_play);
        mRatingBar			= (RatingBar) findViewById( R.id.rating_bar);
        
        // get passed intent 
        Intent intent = getIntent();
        // get video title string from intent
        mVideoTitle = intent.getStringExtra("VIDEO_TITLE");
        mVideoId	= intent.getLongExtra("VIDEO_ID", 0);
        mVideoTitleTextView.setText(mVideoTitle);
        
        // Receiver for the notification.
        mDownloadResultReceiver =
            new DownloadResultReceiver();
        
        addListenerOnRatingBar();
        
        // mMediaController= new MediaController( this );
        
        // Invoke the special onCreate() method in GenericActivity,
        // passing in the VideoPlayOps class to instantiate/manage and
        // "this" to provide VideoPlayOps with the VideoPlayOps.View instance.
        super.onCreate( savedInstanceState,
                       VideoPlayOps.class , this);

    }

    /**
     *  Hook method that is called when user resumes activity
     *  from paused state, onPause(). 
     */
    @Override
    protected void onResume() {
        // Call up to the superclass.
        super.onResume();

        // Register BroadcastReceiver that receives result from
        // DownloadVideoService when a video upload completes.
        registerReceiver();
        getOps().mFileChecker.isVideoExist(mVideoTitle); 
		// get rating info from Video Server, which handle by VideoPlayOps.onPostExecute() and update RatingBar. 
		getOps().updateVideoRating( mVideoId, 0.0f, VideoPlayOps.RATING_OP_MODE_GET);
    }
    
    /**
     * Register a BroadcastReceiver that receives a result from the
     * UploadVideoService when a video upload completes.
     */
    private void registerReceiver() {
        
        // Create an Intent filter that handles Intents from the
        // UploadVideoService.
        IntentFilter intentFilter =
            new IntentFilter( DownloadVideoService.ACTION_DOWNLOAD_SERVICE_RESPONSE);
        intentFilter.addCategory(Intent.CATEGORY_DEFAULT);

        // Register the BroadcastReceiver.
        LocalBroadcastManager.getInstance(this)
               .registerReceiver( mDownloadResultReceiver,
                                 intentFilter);
    }

    /**
     * Hook method that gives a final chance to release resources and
     * stop spawned threads.  onDestroy() may not always be
     * called-when system kills hosting process.
     */
    @Override
    protected void onPause() {
        // Call onPause() in superclass.
        super.onPause();
        
        // Unregister BroadcastReceiver.
        LocalBroadcastManager.getInstance(this)
          .unregisterReceiver(mDownloadResultReceiver);
    }

    
    private void addListenerOnRatingBar() {
    	mRatingBar.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
    		public void onRatingChanged(RatingBar ratingBar, float rating,	boolean fromUser) {
    			if ( fromUser ) {
    				if ( rating > 0.0 && rating < 1.0)
    					rating = 1.0f;
    				else if ( rating > 1.0  && rating < 2.0 )
    					rating = 2.0f;
    				else if ( rating > 2.0  && rating < 3.0 )
    					rating = 3.0f;
    				else if ( rating > 3.0  && rating < 4.0 )
    					rating = 4.0f;
    				else rating = 5.0f;
    				
    				mRatingBar.setRating(rating);
    				// post new rating to Video Server, the Video Server send back a update rating info
    				// which in turn intercept by VideoPlayOps.onPostExecute() and update RatingBar again. 
    				getOps().updateVideoRating( mVideoId, rating, VideoPlayOps.RATING_OP_MODE_POST);
    			}
    		}
    	});
   }
    
    
    /**
     * The Broadcast Receiver that registers itself to receive result
     * from UploadVideoService.
     */
    private class DownloadResultReceiver 
            extends BroadcastReceiver {
        /**
         * Hook method that's dispatched when the DownloadService has
         * downloaded the Video.
         */
     	@Override
		public void onReceive(Context context, Intent intent) {
     		enabledDownloadButton(false);		// remove download button
		}
    }


    /**
     * Finishes this Activity.
     */
    @Override
    public void finish() {
        super.finish();
    }

    @Override
    public void enabledDownloadButton(boolean b) {
	// Auto-generated method stub
    	if ( b ) 
    		mDownloadBtn.setVisibility(View.VISIBLE);
    	else
    		mDownloadBtn.setVisibility(View.GONE);
    }

    @Override
    public void enabledPlayButton(boolean b) {
    	// Auto-generated method stub
    	if ( b ) 
    		mPlayBtn.setVisibility(View.VISIBLE);
    	else
    		mPlayBtn.setVisibility(View.GONE);
    }

    /**
     * Initiate the video data download when the user presses
     * the "Download" button.
     */
    public void downloadVideoData(View v) {
    	getOps().downloadVideo( mVideoTitle, mVideoId );
    }

    /**
     * Initiate the video data download when the user presses
     * the "Download" button.
     */
    public void playVideo(View v) {
    	getOps().playVideo( mVideoTitle );
    	//getOps().mFileChecker.isVideoExist(mVideoTitle);
    }

	@Override
	public void playVideo(Uri videoUri ) {
		// Auto-generated method stub
        
//		mMediaController.setAnchorView( mVideoView );          
//		//Setting MediaController and URI to videoView, then starting the videoView  
//		mVideoView.setMediaController( mMediaController );  
//		mVideoView.setVideoURI( videoUri );          
//		mVideoView.requestFocus();  
//		mVideoView.start(); 		
		
		Intent intent = new Intent( Intent.ACTION_VIEW );  
		intent.setDataAndType( videoUri,"video/mp4");  
		startActivity( intent );
	}

	@Override
	public void updateRatingBar(float rating) {
		// Auto-generated method stub
		mRatingBar.setRating(rating);
	}
   
    
}
