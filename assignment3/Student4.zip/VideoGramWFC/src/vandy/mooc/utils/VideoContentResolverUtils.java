/**
 *  Video Content Resolver utils.
 *  @author -WFC-
 */

package vandy.mooc.utils;

import java.util.ArrayList;
import java.util.List;

import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.provider.VideoContract;
import vandy.mooc.provider.VideoContract.VideoEntry;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class VideoContentResolverUtils {

    /**
     * Helper method that puts a List of Video metadata into
     * Video content provider.
     *
     * @param videos array of video.
     * @return number of rows inserted
     */
    public static int putValues( Context context, List<Video> videos ) {
        // Check if the List is not null or empty.
        if ( videos == null
            || videos.isEmpty()) 
            return -1;

        // Use ContentValues to store the values in appropriate
        // columns, so that ContentResolver can process it.  Since
        // more than one rows needs to be inserted, an Array of
        // ContentValues is needed.
        ContentValues[] cvArray = new ContentValues[ videos.size() ];

        for (int i = 0; i < videos.size(); i++) {
            // you loop through the list of value
            // expansions create a ContentValues object that contains
            // their contents, and store this into the appropriate
            // location the cvArray.
        	
        	ContentValues cv = new ContentValues();
        	cv.put( VideoContract.VideoEntry.COLUMN_ID,   			videos.get(i).getId());
        	cv.put( VideoContract.VideoEntry.COLUMN_TITLE,			videos.get(i).getTitle());
        	cv.put( VideoContract.VideoEntry.COLUMN_DURATION,		videos.get(i).getDuration());
        	cv.put( VideoContract.VideoEntry.COLUMN_CONTENT_TYPE,	videos.get(i).getContentType());
        	cv.put( VideoContract.VideoEntry.COLUMN_DATA_URL,		videos.get(i).getDataUrl());
        	cv.put( VideoContract.VideoEntry.COLUMN_NUM_RATING,		videos.get(i).getNumrating());
        	cv.put( VideoContract.VideoEntry.COLUMN_SUM_RATING,   	videos.get(i).getSumrating());
        	cvArray[i++] = cv;
        }

        // Use ContentResolver to bulk insert the ContentValues into
        // the Video database and return the number of rows inserted.
        return context.getContentResolver().bulkInsert( VideoEntry.CONTENT_URI,
                                                        cvArray);
    }

    /**
     * Helper method that puts a video metadata into
     * Video content provider.
     *
     * @param videos array of video.
     * @return number of rows inserted
     */
    public static int putValues( Context context, Video video ) {
        // Check if the List is not null or empty.
        if ( null == video )
            return -1;

        // Use ContentValues to store the values in appropriate
        // columns, so that ContentResolver can process it.  Since
        // more than one rows needs to be inserted, an Array of
        // ContentValues is needed.
        ContentValues[] cvArray = new ContentValues[ 1 ];

            // expansions create a ContentValues object that contains
            // their contents, and store this into the appropriate
            // location the cvArray.
        	
        	ContentValues cv = new ContentValues();
        	cv.put( VideoContract.VideoEntry.COLUMN_ID,   			video.getId());
        	cv.put( VideoContract.VideoEntry.COLUMN_TITLE,			video.getTitle());
        	cv.put( VideoContract.VideoEntry.COLUMN_DURATION,		video.getDuration());
        	cv.put( VideoContract.VideoEntry.COLUMN_CONTENT_TYPE,	video.getContentType());
        	cv.put( VideoContract.VideoEntry.COLUMN_DATA_URL,		video.getDataUrl());
        	cv.put( VideoContract.VideoEntry.COLUMN_NUM_RATING,		video.getNumrating());
        	cv.put( VideoContract.VideoEntry.COLUMN_SUM_RATING,   	video.getSumrating());
        	cvArray[0] = cv;

        // Use ContentResolver to bulk insert the ContentValues into
        // the Video database and return the number of rows inserted.
        return context.getContentResolver().bulkInsert( VideoEntry.CONTENT_URI,
                                                        cvArray);
    }
    
    
    
    /**
     * Gets the @a List of Acronym Expansions from the cache having
     * given @a acronym. Remove it if expired.
     * 
     * @param acronym
     * @return List of Acronym Data
     */
    public static List<Video> getVideos( Context context ) {
        // Initializes an array to contain selection arguments.
        // Cursor that is returned as a result of database query which
        // points to one or more rows.
        try (Cursor cursor =
             context.getContentResolver().query
             (VideoEntry.CONTENT_URI,
              null,
              null,
              null,
              null)) {
            // If there are no matches in the database return false. 
            if (!cursor.moveToFirst())
                return null;

            // Since all rows with same acronym have same expiration
            // time, check the expiration of first row.  If its
            // expired, then return null and start a thread to delete
            // all rows having that acronym else get the Acronym Data
            // from first row and add it to the List.
            else {
                List< Video > videos = new ArrayList< Video >();

                // Now we're sure that the acronym has not
                // expired, get the List of AcronymExpansions.
                do 
                    videos.add( getVideo( cursor ) );
                while (cursor.moveToNext());

                return videos;
                }
            }
    }

    /**
     * Get a video metadata from the database.
     * 
     * @param cursor
     * @return Video
     */
    public static Video getVideo( Cursor cursor ) {
   
        long videoId = cursor.getLong( cursor.getColumnIndex(
        				VideoContract.VideoEntry.COLUMN_ID));
        String title = cursor.getString(cursor.getColumnIndex(
        				VideoContract.VideoEntry.COLUMN_TITLE));
        long duration = cursor.getLong( cursor.getColumnIndex(
						VideoContract.VideoEntry.COLUMN_DURATION));
        String contentType = cursor.getString(cursor.getColumnIndex(
						VideoContract.VideoEntry.COLUMN_CONTENT_TYPE));
        String dataUrl = cursor.getString(cursor.getColumnIndex(
						VideoContract.VideoEntry.COLUMN_DATA_URL));
        long numrating = cursor.getLong( cursor.getColumnIndex(
						VideoContract.VideoEntry.COLUMN_NUM_RATING));
        float sumrating = cursor.getLong( cursor.getColumnIndex(
						VideoContract.VideoEntry.COLUMN_SUM_RATING));
        
        return new Video( videoId, title, duration, contentType, dataUrl,
                 numrating, sumrating );
    }
    
}
