/**
 * VideoPlayOps
 * @author -WFC- 2015-07-12
 */
package vandy.mooc.presenter;

import java.lang.ref.WeakReference;
import java.util.List;

import vandy.mooc.common.ConfigurableOps;
import vandy.mooc.common.ContextView;
import vandy.mooc.common.GenericAsyncTask;
import vandy.mooc.common.GenericAsyncTaskOps;
import vandy.mooc.model.mediator.VideoDataMediator;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.model.services.DownloadVideoService;
import vandy.mooc.utils.VideoContentResolverUtils;
import vandy.mooc.utils.VideoMediaStoreUtils;
import android.net.Uri;
import android.util.Log;


/**
 * Provides all the Video-related operations.  It implements
 * ConfigurableOps so it can be created/managed by the GenericActivity
 * framework.  It extends GenericAsyncTaskOps so its doInBackground()
 * method runs in a background task.  It plays the role of the
 * "Abstraction" in Bridge pattern and the role of the "Presenter" in
 * the Model-View-Presenter pattern.
 */
public class VideoPlayOps
       implements GenericAsyncTaskOps< Object, Void, Video>,
                  ConfigurableOps<VideoPlayOps.View> {
    /**
     * Debugging tag used by the Android logger.
     */
    private static final String TAG =
        VideoPlayOps.class.getSimpleName();
    
    public final static int RATING_OP_MODE_GET = 0;
    public final static int RATING_OP_MODE_POST = 1;
    
    /**
     * This interface defines the minimum interface needed by the
     * VideoPlayOps class in the "Presenter" layer to interact with the
     * VideoPlayActivity in the "View" layer.
     */
    public interface View extends ContextView {
        /**
         * Finishes the Activity the VideoPlayOps is
         * associated with.
         */
        void finish();

        void enabledDownloadButton( boolean b );
        void enabledPlayButton( boolean b );
        void playVideo( Uri videoUri );
        void updateRatingBar( float rating );
    }
        
    /**
     * Used to enable garbage collection.
     */
    private WeakReference<VideoPlayOps.View> mVideoView;
    
    /**
     * The GenericAsyncTask used to run in a background
     * thread to interact with the Video web service.
     */
    private GenericAsyncTask< Object, Void, Video, VideoPlayOps> mAsyncTask;
    
    /**
     * VideoDataMediator mediates the communication between Video
     * Service and local storage on the Android device.
     */
    VideoDataMediator mVideoMediator;
    
    public LocalFileChecker mFileChecker;
    
    private Uri mCurrentVideoUri;
    
    
    /**
     * Default constructor that's needed by the GenericActivity
     * framework.
     */
    public VideoPlayOps() {
    	mFileChecker = new LocalFileChecker();
    }
    
    /**
     * Called after a runtime configuration change occurs to finish
     * the initialization steps.
     */
	@Override
    public void onConfiguration( VideoPlayOps.View view,
                                boolean firstTimeIn) {
        final String time =
            firstTimeIn 
            ? "first time" 
            : "second+ time";
        
        Log.d(TAG,
              "onConfiguration() called the "
              + time
              + " with view = "
              + view);

        // (Re)set the mVideoView WeakReference.
        mVideoView =
            new WeakReference<>(view);
        
        if (firstTimeIn) {
            // Create VideoDataMediator that will mediate the
            // communication between Server and Android Storage.
            mVideoMediator =
                new VideoDataMediator();
           
        }
        
    }

    /**
     * Start a service that Downloads the Video of a given title name and Id.
     * 
     * @param videoTitle
     * @param videoId
     */
    public void downloadVideo( String videoTitle, long videoId){
    	Log.d(TAG,"Started DownloadVideoService");
        // Sends an Intent command to the DownloadVideoService.
        mVideoView.get().getApplicationContext().startService
            (DownloadVideoService.makeIntent 
                 (mVideoView.get().getApplicationContext(),
                  videoTitle, videoId));
    }

    /**
     * Play video of a given video title name.
     * 
     * @param videoTitle
     */
    
    public void playVideo( String videoTitle ) {
    	if ( null == mCurrentVideoUri ) {
    		mFileChecker.isVideoExist(videoTitle);
    	}

    	if ( null != mCurrentVideoUri ) {
    		mVideoView.get().playVideo( mCurrentVideoUri );
    	}
    }
    
    /**
     * update video rating without blocking the caller.
     */
    
    /**
     * 
     * @param videoID
     * @param rating
     * @param opMode  0 == get, 1 == post.
     */
    public void updateVideoRating( long videoID, float rating, int opMode ){
        mAsyncTask = new GenericAsyncTask<>(this);
        mAsyncTask.execute( videoID, rating, opMode );
    }
    
    /**
     * Retrieve the Video metadata by help of VideoDataMediator via a
     * synchronous two-way method call, which runs in a background
     * thread to avoid blocking the UI thread.
     */
    @Override
    public Video doInBackground( Object ... params) {
    	Video video = mVideoMediator.getVideoRatingInfo( (long) params[0]);	// params[0] is videoID
    	if ( null != video ) {
    		if ( RATING_OP_MODE_POST == (int) params[2] ) {					// params[2] is opMode
    			video.setSumrating( (float) params[1]);						// params[1] is rating by this client.
    			video = mVideoMediator.rateVideo( video );
    		}
    	}
    	
    	// if Video Server does not have Video data, use Video metadata from local device ContentProvider 
    	if ( null == video ) {
    		List< Video> videos = VideoContentResolverUtils.getVideos(
        			mVideoView.get().getApplicationContext() );
    		for ( Video v : videos) {
    			if ( v.getId() == (long) params[0] ) {
    				video = v;
    				break;
    			}
    		}
    		// local update has no average
    		video.setSumrating( (float) params[1] + video.getSumrating());
    		video.setNumrating( 1 + video.getNumrating());
    	}
    	
    	if ( null != video ) {
    		// save video metadata to local content provider
        	VideoContentResolverUtils.putValues( 
        			mVideoView.get().getApplicationContext(), video );    		
    	}
    	return video;
    }

    /**
     * Display average rating of RatingBar in the UI Thread.
     */
    @Override
    public void onPostExecute(Video video) {
    	if ( null != video ) {
        	long numrating = video.getNumrating();
        	float rating = 0.0f; 
        	if ( numrating > 0 ) {
        		rating = video.getSumrating() / ( float) numrating;
        	}
        	Log.d(TAG,  "numrating= "+ numrating + " sumrating= " + video.getSumrating() + " average rating= "+ rating ); 
        	mVideoView.get().updateRatingBar(rating);
    	}
    }

    // Object to see if local video file exist in device.
    public class LocalFileChecker implements GenericAsyncTaskOps<Void, Void, Uri> {

        /**
         * The GenericAsyncTask used to check video title exist in local device
         */
        private GenericAsyncTask<Void, Void, Uri, LocalFileChecker> mFileCheckingAsyncTask;

        String mVideoTitle;
        
        /**
         * update video rating without blocking the caller.
         */
        public void isVideoExist( String videoTitle ){
        	mVideoTitle = videoTitle;
        	mFileCheckingAsyncTask = new GenericAsyncTask<>(this);
        	mFileCheckingAsyncTask.execute();
        }

		@Override
		public Uri doInBackground(Void... params) {
			// Auto-generated method stub
			return VideoMediaStoreUtils.getVideoUri( mVideoView.get().getApplicationContext(),
					mVideoTitle);
		}

		@Override
		public void onPostExecute( Uri result ) {
			//  Auto-generated method stub
			mCurrentVideoUri = result;
			// if video title has no video data in local device, enabled download button
			if ( null == result ) 
				mVideoView.get().enabledDownloadButton( true );
			else  { // video title has video data in local device
		        Log.d(TAG,  "VideoTitle= "+ mVideoTitle + " " + result.toString()); 
				mVideoView.get().enabledDownloadButton( false );
			}
		}
    	
    }
    
}

