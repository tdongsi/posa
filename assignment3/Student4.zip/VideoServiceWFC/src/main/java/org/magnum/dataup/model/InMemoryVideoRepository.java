// Based on assignment2 solution video lecture from Dr. Jules White.
package org.magnum.dataup.model;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

// In memory Video metadata repository
public class InMemoryVideoRepository implements VideoRepository {

	// A thread safe long
	private static final AtomicLong mCurrentId =  new AtomicLong(0L); 
	
	private Map<Long, Video> mVideos = new ConcurrentHashMap();
	
	// save video metadata to repository
	@Override
	public Video save(Video v) {
		// Auto-generated method stub
		checkAndSetId( v );
		mVideos.put( v.getId(), v);
		return v;
	}

	@Override
	public Video findOne(long id) {
		//Auto-generated method stub
		return mVideos.get( id );
	}

	// return all videos meta data
	@Override
	public Iterable<Video> findAll() {
		//Auto-generated method stub
		return mVideos.values();
	}
	
	// Helper method to generated an Id for video object.
	private void checkAndSetId( Video v) {
		if( v.getId() == 0){
			v.setId( mCurrentId.incrementAndGet());
		}
	}

	@Override
	public Video update(Video v) {
		// Auto-generated method stub
		return mVideos.put( v.getId(), v);
	}
	
	

}
