/*
 * Video services controller.
 * @author WFC. 2015
 * 
 */
package org.magnum.dataup;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.magnum.dataup.model.Video;
import org.magnum.dataup.model.VideoRepository;
import org.magnum.dataup.model.VideoStatus;
import org.magnum.dataup.model.VideoStatus.VideoState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;

@Controller
public class VideoServicesController {
	// in memory HashMap for stored video meta data sent by clients.
	// HashMap<Long, Video> mVideos = new HashMap<>();
	// use atomic long to generate unique video ID.
	// private static final AtomicLong mCurrentId = new AtomicLong(0L);
	
	// video metadata repository
	@Autowired
	private VideoRepository mVideoRepository;
	
	// video data repository
	@Autowired
	private VideoFileManager mVideoDataRepository;
	
	// Receives POST requests to /video and converts the HTTP
	// request body, which should contain json, into a Video
	// object before adding it to the list. The @RequestBody
	// annotation on the Video parameter is what tells Spring
	// to interpret the HTTP request body as JSON and convert
	// it into a Video object to pass into the method. The
	// @ResponseBody annotation tells Spring to convert the
	// return value from the method back into JSON and put
	// it into the body of the HTTP response to the client.
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video v){
		// Video addedV = saveVideoMetaData(v);
		// return addedV;
		v = mVideoRepository.save( v );
		String url = getVideoUrl( v );
		v.setDataUrl( url );
		return v;
	}
	
	// Receives GET requests to /video and returns the current
	// list of videos in memory. Spring automatically converts
	// the list of videos to JSON because of the @ResponseBody
	// annotation.
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList(){
		// Collection<Video> c = mVideos.values();
		// return c;
		return Lists.newArrayList( mVideoRepository.findAll());
	}
	
	// Receives POST requests to /video/{id}/data. It save uploaded video data to file if
	// the id is a valid id that associated with existing video metadata.
	@RequestMapping(value = VideoSvcApi.VIDEO_DATA_PATH, method = RequestMethod.POST)
	public @ResponseBody VideoStatus setVideoData(
			@PathVariable("id") long id,
			@RequestPart(VideoSvcApi.DATA_PARAMETER) MultipartFile videoData,
			HttpServletResponse response)  throws IOException {
//			HttpServletResponse response)   {
//		VideoFileManager videoDataMgr = null;
//		VideoStatus vs = new VideoStatus( VideoState.PROCESSING);
//		Video v = mVideos.get(id);
//		
//		// if found valid id associated with existing video meta data,
//		// then save posted video data to file,else response with 404.
//		if ( null != v ) {
//		  try {
//			videoDataMgr = VideoFileManager.get();  
//			saveVideoData( videoDataMgr, v, videoData);
//			vs.setState(VideoState.READY);
//		  } catch (IOException e) {
//			e.printStackTrace();
//		  }
//		}
//		else {
//			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
//		}
//		return vs;
		
		VideoStatus vs = null;
		Video v = mVideoRepository.findOne(id);
		if ( null != v ) {
			mVideoDataRepository.saveVideoData( v, videoData.getInputStream());
			vs = new VideoStatus( VideoState.READY);
		}
		else {
			response.sendError( HttpServletResponse.SC_NOT_FOUND,
					"Video metadata not found");
		}
		return vs;
	}
	
	
	// Receives GET requests to /video/{id}/data. If it has a valid id that associated
	// with existing video metadata then stream video data (if any) back to client,
	// else it respond with 404.
	@RequestMapping(value = VideoSvcApi.VIDEO_DATA_PATH,  method = RequestMethod.GET)
	public void getVideoData( @PathVariable(VideoSvcApi.ID_PARAMETER) long id,
            HttpServletResponse response) throws IOException {

//	public HttpServletResponse getVideoData(
//	             @PathVariable("id") long id,
//	             HttpServletResponse response) throws IOException {
//					VideoFileManager videoDataMgr = null;
//		 			Video v = mVideos.get(id);
//		 			// if found valid id associated with existing video meta data,
//		 			// then stream video data back to client,else response with 404.
//					if( null == v) {
//	                  response.setStatus(HttpServletResponse.SC_NOT_FOUND);
//	                }
//					else {
//						try {
//							videoDataMgr = VideoFileManager.get();
//						} catch (IOException e1) {
//							e1.printStackTrace();
//						}
//						serveVideoData(videoDataMgr, v, response);
//	         }
//	        return response;

		Video v = mVideoRepository.findOne(id);
		if ( null != v ) {
			// set content type of output stream
			response.setContentType( v.getContentType());
			// copy video data to the outputstream stream back to client.
			mVideoDataRepository.copyVideoData( v, response.getOutputStream());
		}
		else {
			response.sendError( HttpServletResponse.SC_NOT_FOUND,
					"Video data not found");
		}
	}
	

	// Receives POST requests to /video/{id}/rate for update rating info of a video of a given id. 
	// It converts the HTTP request body, which should contain json, into a Video
	// object before update video metadata. The @RequestBody
	// annotation on the Video parameter is what tells Spring
	// to interpret the HTTP request body as JSON and convert
	// it into a Video object to pass into the method. The
	// @ResponseBody annotation tells Spring to convert the
	// return value from the method back into JSON and put
	// it into the body of the HTTP response to the client.
	//
    // Rate a video of a given Id. Video metadata contians
    // number of rating and sum of rating. This enabled client to
    //compute the average rating. This Id is the Id of
    // Video in Video Server. The Video Server only use sumrating
    // to update its sumrating. The Video Server auto increment 
    // numrating and keep tracks it.
	//
	// @author -WFC-
	
	@RequestMapping(value=VideoSvcApi.VIDEO_RATING_PATH, method=RequestMethod.POST)
	public @ResponseBody Video rateVideo( @PathVariable(VideoSvcApi.ID_PARAMETER) long id,
						@RequestBody Video newV ) {
		Video v = mVideoRepository.findOne(id);
		if ( null != v ) {
			float newRating = newV.getSumrating();
			if ( newRating < 1.0f )
				newRating = 1.0f;
			else if ( newRating > 5.0f )
				newRating = 5.0f;
			
			v.setSumrating( v.getSumrating() + newRating );
			v.setNumrating( v.getNumrating() + 1);
			mVideoRepository.update(v);
		}
		return v;

	}
	

	// Receives GET requests to /video/{id}/rate for retrieve rating info of a video of a given id. 
	// It converts the HTTP request body, which should contain json, into a Video
	// object before update video metadata. The @RequestBody
	// annotation on the Video parameter is what tells Spring
	// to interpret the HTTP request body as JSON and convert
	// it into a Video object to pass into the method. The
	// @ResponseBody annotation tells Spring to convert the
	// return value from the method back into JSON and put
	// it into the body of the HTTP response to the client.
	// @author -WFC-
	
	@RequestMapping(value=VideoSvcApi.VIDEO_RATING_PATH, method=RequestMethod.GET)
	public @ResponseBody Video getRatingInfo( @PathVariable(VideoSvcApi.ID_PARAMETER) long id ) {
		return mVideoRepository.findOne(id);
	}
	
	
	
	// Helper method to save video data to a file.
	private String getVideoUrl( Video v) {
		String base = getUrlBaseForLocalServer();
		return base +
				VideoSvcApi.VIDEO_DATA_PATH.replace("{" + VideoSvcApi.ID_PARAMETER + "}",
						"" + v.getId());
	}
	
//	// Helper method to save video data to a file.
//  	private void saveVideoData( VideoFileManager videoDataMgr,
//  			         Video v, MultipartFile videoData) throws IOException {
// 	     videoDataMgr.saveVideoData( v, videoData.getInputStream());
// 	}
//  	
//	// Helper method to stream video data to a client.
//  	private void serveVideoData( VideoFileManager videoDataMgr,
//  			         Video v, HttpServletResponse response) throws IOException {
// 	     videoDataMgr.copyVideoData(v, response.getOutputStream());
// 	}
  	
 // moved it to InMemoryVideoRepository.java file, implemented it as save() method.  	
//  	// Helper method to save posted video meta data to HashMap.
//  	public Video saveVideoMetaData( Video v) {
//		checkAndSetId( v );
//		v.setDataUrl(getDataUrl( v.getId()));
//		mVideos.put( v.getId(), v);
//		return v;
//	}

// moved it to InMemoryVideoRepository.java file  	
//  	// Helper method to generated an Id for video object.
//	private void checkAndSetId( Video v) {
//		if( v.getId() == 0){
//			v.setId( mCurrentId.incrementAndGet());
//		}
//	}
	
//	// Helper method to generated Data Url
//	private String getDataUrl(long videoId) {
//		String url = getUrlBaseForLocalServer() + "/video/" + videoId + "/data";
//		return url;
//	}

	// Helper method to get Url base
  	private String getUrlBaseForLocalServer() {
		HttpServletRequest request = 
		       ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		String base = "http://"+request.getServerName() 
				+ ((request.getServerPort() != 80) ? ":"+request.getServerPort() : "");
	   return base;
	}	
	
}
