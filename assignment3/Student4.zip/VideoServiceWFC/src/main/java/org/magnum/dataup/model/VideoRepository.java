// Based on assignment2 solution video lecture from Dr. Jules White.
package org.magnum.dataup.model;

public interface VideoRepository {
	public Video save( Video v );
	public Video findOne( long id);
	public Iterable<Video> findAll();
	public Video update( Video v);
}
