package vandy.mooc.view;

import java.io.File;
import java.text.DecimalFormat;

import vandy.mooc.R;
import vandy.mooc.common.Utils;
import vandy.mooc.model.mediator.VideoDataMediator;
import vandy.mooc.model.mediator.webdata.Video;
import vandy.mooc.provider.VideoContract.VideoEntry;
import vandy.mooc.utils.VideoMediaStoreUtils;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.VideoView;

public class VideoViewActivity extends Activity {

	VideoView mVideoView = null;
	VideoDataMediator mVideoMediator = new VideoDataMediator();
	Uri uri = null;
	double mAvgRating;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.video_view_activity);

		mVideoView = (VideoView) findViewById(R.id.videoViewer);
		TextView mTitle = (TextView) findViewById(R.id.title);
		Button downloadButton = (Button) findViewById(R.id.downloadButton);
		final TextView avgRating = (TextView) findViewById(R.id.avgRating);
		final RatingBar mRatingBar = (RatingBar) findViewById(R.id.ratingBar);

		// Add a Media controller to allow forward/reverse/pause/resume 
		final MediaController mMediaController = new MediaController(
				VideoViewActivity.this, true);
		
		mMediaController.setEnabled(false);

		mVideoView.setMediaController(mMediaController);
		
		Intent intent = getIntent();
		final Video mVideo = (Video) intent.getSerializableExtra(VideoListActivity.EXTRA_VIDEO);
		
		mTitle.setText(mVideo.getTitle());
		
		//video playing section
		//get data_url from VideoContentProvider. if found=>on device=>setVideoUri 
		//check data_url in the VideoProvider then check the existance of video data
		mVideoView.setEnabled(false);
		Cursor cursor = queryVideoProvider(mVideo);
        if (cursor.moveToFirst()) {
            Uri uri = null;
        	int index = cursor.getColumnIndex(VideoEntry.COLUMN_DATA_URL);
        	if (null != cursor.getString(index)) {
        		uri = Uri.parse(cursor.getString(index));
        		String filePath = VideoMediaStoreUtils.getPath(this, uri);
                if (null != filePath) {
                  	// video data available to be played
                    //File videoFile = new File(filePath);
        			mVideoView.setVideoURI(uri);
        			mVideoView.setEnabled(true);
        			downloadButton.setVisibility(View.INVISIBLE);
        			downloadButton.setEnabled(false);
               }
        	}
        }

		downloadButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				new Thread(new Runnable() {
					@Override 
					public void run() {//background thread
						uri = mVideoMediator.downloadVideo(VideoViewActivity.this, mVideo);
						mVideoView.post(new Runnable() {
							@Override
							public void run() {//UI thread
								mVideoView.setVideoURI(uri);
								mVideoView.setEnabled(true);
							}
						});
						//also under background thread
				    	ContentValues values = new ContentValues();
				    	values.put(VideoEntry.COLUMN_DATA_URL, uri.toString());
		    			updateVideoProvider(mVideo, values);
					}
				}).start();
    			// update data_url field in VideoProvider to download file
			}
		});
		
		mVideoView.setOnPreparedListener(new OnPreparedListener() {

			@Override
			public void onPrepared(MediaPlayer mp) {
				mMediaController.setEnabled(true);
			}
		});
		//rating section
		final DecimalFormat newFormat = new DecimalFormat("#.##");
		if (mVideo.getAvgRating() > 0) {
			double formatedAvgRating =  Double.valueOf(newFormat.format(mVideo.getAvgRating()));
			avgRating.setText(Double.toString(formatedAvgRating));
		}
		else
			avgRating.setText("Not Available!");
		

		Button rateButton = (Button) findViewById(R.id.rateButton);
		rateButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (mRatingBar.getRating() > 0) {
					new Thread(new Runnable() {
						@Override
						public void run() {//background thread
							mAvgRating = mVideoMediator.rateVideo(
								mVideo.getId(), mRatingBar.getRating());
							avgRating.post(new Runnable() {
								@Override
								public void run() {//UI thread
									double formatedAvgRating =  Double.valueOf(
											newFormat.format(mAvgRating));
									avgRating.setText(Double.toString(formatedAvgRating));
								}
							});
							mVideo.setAvgRating(mAvgRating);
		        			// update rating field in VideoProvider 
					    	ContentValues values = new ContentValues();
					    	values.put(VideoEntry.COLUMN_RATING, mAvgRating);
							updateVideoProvider(mVideo, values);
						}
					}).start();
				}
				else
					Utils.showToast(VideoViewActivity.this, 
							"Please rate at rating bar first!");
			}
		});
	}		
	
	private Cursor queryVideoProvider(Video v) {
        String[] selectionArgs = { Long.toString(v.getId()) };
        String[] projection = { VideoEntry.COLUMN_DATA_URL };
        
        // Cursor that is returned as a result of database query which
        // points to one or more rows.
        
        Cursor cursor =
             getContentResolver().query
             (VideoEntry.CONTENT_URI,
              projection,
              VideoEntry.SELECTION_VIDEO,
              selectionArgs,
              null);
		return cursor;
	}

	private void updateVideoProvider(Video v, ContentValues values) {
        String[] selectionArgs = { Long.toString(v.getId()) };
        
    	getContentResolver().update(VideoEntry.CONTENT_URI, 
    								values, 
    								VideoEntry.SELECTION_VIDEO,
    								selectionArgs);
	}
	
	// Clean up and release resources
	@Override
	protected void onPause() {

		if (mVideoView != null && mVideoView.isPlaying()) {
			mVideoView.stopPlayback();
			mVideoView = null;
		}
		super.onPause();
	}
}
