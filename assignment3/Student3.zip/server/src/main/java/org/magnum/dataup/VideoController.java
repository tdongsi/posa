/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.magnum.dataup;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.ServletOutputStream;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.magnum.dataup.model.Video;
import org.magnum.dataup.model.VideoStatus;
import org.magnum.dataup.model.VideoStatus.VideoState;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class VideoController {
	// URL Parameters
	public static final String DATA_PARAMETER = "data";
	public static final String ID_PARAMETER = "id";
	private static final String VIDEO_SVC_PATH = "/video";
	private static final String VIDEO_DATA_PATH = VIDEO_SVC_PATH + "/{"
			+ ID_PARAMETER + ":-?\\d+}/" + DATA_PARAMETER;
	// ID counter
	private static final AtomicLong currentId = new AtomicLong(0L);
	// Data Storage Objects
	private Map<Long, Video> videos = new HashMap<Long, Video>();
	private VideoFileManager vfm;

	/**
	 * Explicit constructor needed to instantiate VideoFileManager because
	 * VideoFile Manager throws exceptions.
	 */
	public VideoController() {
		try {
			vfm = VideoFileManager.get();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * POST /video
	 * 
	 * @param v
	 *            The video metadata is provided as an application/json request
	 *            body.
	 * @return Returns the JSON representation of the Video object that was
	 *         stored along with any updates to that object made by the server.
	 */
	@RequestMapping(value = VIDEO_SVC_PATH, method = RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video v) {
		v = save(v);
		return v;
	}

	/**
	 * POST /video/{id:-?\\d+}/data Upload and associate video with provided id.
	 * Throws execptions if id is invalid
	 * 
	 * @param id
	 *            String containing id of video we want to upload data for
	 * @param videoData
	 *            video data we want to upload
	 * @return VideoState.READY if the upload worked, 404 otherwise
	 */
	@RequestMapping(value = VIDEO_DATA_PATH, method = RequestMethod.POST)
	public @ResponseBody VideoStatus addVideoData(
			@PathVariable(ID_PARAMETER) String id,
			@RequestParam(DATA_PARAMETER) MultipartFile videoData) {
		// Lookup the video
		Video v = getVideoFromId(id);
		VideoState state = null; // The state we set and return
		try {
			vfm.saveVideoData(v, videoData.getInputStream());
			state = VideoState.READY;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new VideoStatus(state);
	}

	/**
	 * GET /video/id:-?\\d+}/data Get already uploaded video data. Throws
	 * exceptions if no metadata associated with given ID or if no video has
	 * been uploaded
	 * 
	 * @param id
	 *            String containing id of video we want to download
	 * @param response
	 *            ServletResponse so we can get an output stream to send the
	 *            video data with
	 */
	@RequestMapping(value = VIDEO_DATA_PATH, method = RequestMethod.GET)
	public @ResponseBody void getVideoData(
			@PathVariable(ID_PARAMETER) String id, ServletResponse response) {
		Video v = getVideoFromId(id);
		ServletOutputStream out = null;
		// send the video data
		try {
			out = response.getOutputStream();
			vfm.copyVideoData(v, out);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Receives GET requests to /video and returns the current
	// list of videos in memory. Spring automatically converts
	// the list of videos to JSON because of the @ResponseBody
	// annotation.
	/**
	 * GET /video
	 * 
	 * @return Returns the list of videos that have been added to the server as
	 *         JSON. The list of videos does not have to be persisted across
	 *         restarts of the server. The list of Video objects should be able
	 *         to be unmarshalled by the client into a Collection<Video>. The
	 *         return content-type should be application/json, which will be the
	 *         default if you use @ResponseBody
	 */
	@RequestMapping(value = VIDEO_SVC_PATH, method = RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList() {
		return videos.values();
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_RATING_PATH, method = RequestMethod.GET)
	public @ResponseBody double getRating(
			@PathVariable(VideoSvcApi.ID_PARAMETER) long id) {
		Video v = getVideoFromId(id);
		return v.getRating();
	}
	@RequestMapping(value = VideoSvcApi.VIDEO_RATING_PATH, method = RequestMethod.POST)
	public @ResponseBody void rateVideo(
			@PathVariable(VideoSvcApi.ID_PARAMETER) long id, @RequestBody int rating) {
		Video v = getVideoFromId(id);
		v.rate(rating);
	}
	/**
	 * @author thw Exception thrown when we don't know what video you're talking
	 *         about
	 */
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public final class ResourceNotFoundException extends RuntimeException {

		/**
         * 
         */
		private static final long serialVersionUID = -4098725131027861582L;

	}

	/**
	 * @param id
	 *            from URL
	 * @return parse id as base 10 long
	 */
	private Video getVideoFromId(String id) throws ResourceNotFoundException {
		// Lookup video in hash table
		Video v = videos.get(Long.parseLong(id));
		// If video metadata is not in hash table, throw an exception
		if (v == null) {
			throw new ResourceNotFoundException();
		}
		return v;
	}
	/**
	 * @param id
	 *            from URL
	 * @return parse id as base 10 long
	 */
	private Video getVideoFromId(long id) throws ResourceNotFoundException {
		// Lookup video in hash table
		Video v = videos.get(id);
		// If video metadata is not in hash table, throw an exception
		if (v == null) {
			throw new ResourceNotFoundException();
		}
		return v;
	}
	/**
	 * @param Video
	 *            to be added to videos list
	 * @return representation of same with unique id
	 */
	public Video save(Video entity) {
		checkAndSetId(entity);
		checkAndSetDataUrl(entity);
		videos.put(entity.getId(), entity);
		return entity;
	}

	/**
	 * @param entity
	 *            Video whose ID will be set
	 */
	private void checkAndSetId(Video entity) {
		if (entity.getId() == 0) {
			entity.setId(currentId.incrementAndGet());
		}
	}

	/**
	 * Check to see if video has a data URL, if not generate one and set it
	 * 
	 * @param entity
	 *            Video whose data url will be checked and set
	 */
	private void checkAndSetDataUrl(Video entity) {
		if (entity.getDataUrl() == null) {
			String url = getUrlBaseForLocalServer() + "/video/"
					+ entity.getId() + "/data";
			entity.setDataUrl(url);
		}
	}

	/**
	 * @return The base URL for the local server
	 */
	private String getUrlBaseForLocalServer() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder
				.getRequestAttributes()).getRequest();
		String base = "http://"
				+ request.getServerName()
				+ ((request.getServerPort() != 80) ? ":"
						+ request.getServerPort() : "");
		return base;
	}

}
